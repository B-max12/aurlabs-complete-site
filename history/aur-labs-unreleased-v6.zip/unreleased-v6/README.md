# Aur Labs 3.0

Monochrome React/TypeScript website and protected content studio on Vinext and Cloudflare Workers. Public pages use self-hosted Geist, accessible light/dark themes and an optional Auri guide. The volunteer journey has four steps including review.

**Deployment candidate, not a completed production migration.** Production remains on saved version 2 with D1/R2. This candidate implements a Supabase adapter behind `AUR_BACKEND=supabase`; the default is `d1`. Do not switch before the launch gates in [deployment readiness](docs/deployment-readiness.md) pass.

- [Release decision and evidence](release/release-go-no-go.md)
- [Implementation evidence](docs/aur-3.0-implementation.md)
- [Authentication/provider setup](docs/authentication-setup.md)
- [Migration and rollback operations](docs/migration-runbook.md)
- [Access architecture](docs/supabase-architecture.md)
- [Interaction registry](docs/interaction-registry.md)

Public routes: `/`, `/products`, `/products/:slug`, `/about`, `/journal`, `/journal/:slug`, `/research`, `/research/:slug`, `/join`, `/support`, `/contact`, `/privacy`, `/terms`. Administration: `/admin`, `/admin/recover`, and server-only `/api/auth/callback`.

## Local checks

Use Node 24 and the locked dependencies. Use Sites helpers for installation, source synchronization, builds and packaging.

```sh
node node_modules/typescript/bin/tsc --noEmit
node tests/integration.mjs
node tests/client.mjs
node tests/supabase-schema.mjs
node tests/supabase-http.mjs
node tests/migration.mjs
node tests/editorial.mjs
```

These checks run on SQLite, Happy DOM, PGlite and isolated network fixtures. They do not replace hosted Auth/Storage/RLS tests, browser/device QA, or Lighthouse measurements. `drizzle/` is the existing D1 schema; `supabase/migrations/` is the separate, unapplied Supabase schema.

## Existing D1 operating instructions

The following setup applies only while `AUR_BACKEND=d1`. Supabase uses verified email/OAuth identities and explicit role assignment, not this owner-unlock mechanism.

## Administrator setup

1. Keep the initial deployment private while setting up.
2. Set the secret `AUR_ADMIN_SETUP_TOKEN` to at least 32 random characters through the hosting environment settings. Never commit a value.
3. Open `/admin`, sign in with the ChatGPT account that should own the admin, and enter the private setup token.
4. Choose a username (3–40 letters, numbers, dots, hyphens, underscores) and password (12–128 characters).
5. Remove the setup secret from hosting after successful creation.
6. Subsequent unlocks require the same platform identity and admin username/password.

Passwords use PBKDF2-SHA-256 with 100,000 iterations, a random salt, and a 256-bit output. A 30-minute unlock is bound to the authenticated platform identity; its bearer token exists only in tab memory and its hash is stored in D1. Reloading locks the studio. A password change revokes existing unlocks. No default credentials are included.

## Content and assets

`lib/content.ts` defines typed seed content. D1 overrides it; drafts and deleted seed records are excluded from public reads. The three initial products are explicitly labelled design concepts, with no downloads. Articles are introductory copy and an explicitly labelled research direction, not fabricated study results. Confirm all public copy before opening access.

Admin supports products, versions, releases, screenshots, articles, research, team, core site copy, donation links, application availability, image upload, inbox management, audit activity, and a JSON export. Uploaded images are public assets; never upload confidential material. Supported images: PNG, JPEG, WebP, GIF, up to 5 MiB. Actual release binaries are hosted elsewhere and linked with HTTPS URLs.

Auri is deterministic help, not an AI chatbot. It provides button hints and validation examples without sending information to an AI provider.

## Donation behavior

No payment provider is configured initially. The support form prepares an email inquiry and never charges a visitor. Configure separate one-time and monthly HTTPS URLs in Site settings when ready. Suggested amounts are not passed automatically to the provider: donors confirm their amount, currency, and recurrence there. No payment webhooks, receipts, accounting ledger, or tax-deductible status are claimed.

## Design asset provenance

`public/assets/aur-sculpture.png` is an original image generated with the built-in image generation tool for this website. It is a chrome sculptural letter A embracing an orange sphere. CSS adds pointer parallax; it is not a WebGL mesh. Product concept illustrations, the brand mark, and editorial art are code-native CSS/SVG. Auri uses a procedurally built Three.js mesh, loaded on demand, with a code-native CSS fallback. No external model or texture requests are made.

The full project handoff guide is supplied separately as `Aur-Labs-Complete-Website-Guide.md`.

## October 13 update and migration status

This release adds the product workbench, separate desktop/mobile/CLI filtering, pagination, article topic filters, reference links, platform detection and release-version selection, contextual field guidance, optional tab-scoped drafts, 20-second submission timeouts with safe idempotent retry, private in-tab content preview, and editable Auri guidance under Site settings. Auri never reads passwords or sends field values to an AI service. Its hints use semantic field IDs and fall back to reserved inline slots when there is no collision-free desktop position. Reduced-motion and save-data preferences are respected. Hints, motion, position reset, and minimize are visitor controls.

The existing D1/R2 backend and ChatGPT-bound admin authorization remain active. The Supabase connector returned zero accessible projects on October 13; no Supabase schema, auth, storage, or data migration has been applied. Do not describe this deployment as a completed Supabase migration. A new project requires organization selection and the provider's project-cost confirmation before creation.

Before cutover: establish the project, back up and reconcile D1 records/R2 objects, create the normalized schema and RLS policies, migrate Auth securely without copying plaintext credentials, validate content/asset counts, test anonymous rejection for private data, verify public submissions and authorized CRUD against Supabase, and reconcile writes during the switch. Keep the old backend and previous saved Site version available for rollback. Do not run a second writer or delete D1/R2 while this is pending.

Validation uses isolated backend integration tests and Happy DOM client interaction tests. Happy DOM does not verify visual layout, native dialog focus trapping, mobile keyboards, WebGL rendering, or real-device performance. Managed browser QA was unavailable because the control-browser skill was not present. Real-browser journeys and visual/performance checks remain outstanding; the broad upgrade plan is not fully accepted solely by a successful build.
