-- Additive operations layer. Apply to staging first; production remains explicitly gated.
begin;
grant usage on schema private to service_role;
alter table public.admin_roles add column sessions_valid_after bigint not null default 0;
alter table public.product_media alter column asset_id drop not null;
alter table public.product_media add column external_url text check(external_url is null or external_url ~ '^https://');
alter table public.product_media add constraint media_source check(num_nonnulls(asset_id,external_url)=1);
alter table public.media_assets add column deleting boolean not null default false;
alter table public.content_revisions add column revision integer not null default 1;
alter table public.content_revisions add constraint unique_content_revision unique(kind,record_id,revision);
alter table public.products add column revision integer not null default 1 check(revision>0);
alter table public.articles add column revision integer not null default 1 check(revision>0);
alter table public.research_posts add column revision integer not null default 1 check(revision>0);
alter table public.team_members add column revision integer not null default 1 check(revision>0);
alter table public.site_settings add column revision integer not null default 1 check(revision>0);
alter table public.pages add column revision integer not null default 1 check(revision>0);
alter table public.auri_guides add column revision integer not null default 1 check(revision>0);
alter table public.auri_faqs add column revision integer not null default 1 check(revision>0);

create table private.submission_receipts (
 id uuid primary key, kind text not null check(kind in ('join','contact')), request_hash text not null,
 created_at timestamptz not null default now()
);
create table private.rate_limits (key text not null,bucket bigint not null,count integer not null,expires_at timestamptz not null,primary key(key,bucket));
create table private.revoked_sessions (id uuid primary key,expires_at timestamptz not null);
create table private.legacy_map (kind text not null,legacy_id text not null,target_id uuid not null unique,deleted boolean not null default false,primary key(kind,legacy_id));
alter table private.submission_receipts enable row level security;
revoke all on private.submission_receipts from public, anon, authenticated;
grant all on private.submission_receipts to service_role;
alter table private.rate_limits enable row level security;
revoke all on private.rate_limits from public, anon, authenticated;
grant all on private.rate_limits to service_role;
alter table private.revoked_sessions enable row level security;
revoke all on private.revoked_sessions from public, anon, authenticated;
grant all on private.revoked_sessions to service_role;
alter table private.legacy_map enable row level security;
revoke all on private.legacy_map from public, anon, authenticated;
grant all on private.legacy_map to service_role;

create function private.assert_actor(actor uuid,allowed text[]) returns void language plpgsql security invoker set search_path='' as $$
begin
 if actor is null or not exists(select 1 from public.admin_roles r where r.user_id=actor and r.enabled and r.role=any(allowed)) then
  raise exception 'Permission denied' using errcode='A0403';
 end if;
end $$;
revoke all on function private.assert_actor(uuid,text[]) from public;
grant execute on function private.assert_actor(uuid,text[]) to service_role;

create function public.consume_rate_limit(p_key text,p_limit integer,p_window_seconds integer) returns boolean language plpgsql security invoker set search_path='' as $$
declare current_bucket bigint; used integer;
begin
 if length(p_key)>200 or p_limit<1 or p_window_seconds<1 then raise exception 'Invalid limit';end if;
 current_bucket:=floor(extract(epoch from now())/p_window_seconds);
 insert into private.rate_limits(key,bucket,count,expires_at) values(p_key,current_bucket,1,now()+make_interval(secs=>p_window_seconds))
 on conflict(key,bucket) do update set count=private.rate_limits.count+1 returning count into used;
 delete from private.rate_limits where expires_at<now()-interval '1 day';
 return used<=p_limit;
end $$;

create function public.submit_form(p_id uuid,p_kind text,p_payload jsonb,p_hash text,p_ip_key text,p_email_key text) returns text language plpgsql security invoker set search_path='' as $$
declare prior private.submission_receipts; target text;
begin
 if p_kind not in ('join','contact') or not coalesce((p_payload->>'consent')::boolean,false) or (p_kind='join' and not coalesce((p_payload->>'volunteer')::boolean,false)) then raise exception 'Invalid consent' using errcode='A0403';end if;
 perform pg_advisory_xact_lock(hashtextextended(p_id::text,0));
 select * into prior from private.submission_receipts where id=p_id;
 if found then
  if prior.kind<>p_kind or prior.request_hash<>p_hash then raise exception 'Idempotency conflict' using errcode='A0409';end if;
  return left(p_id::text,8);
 end if;
 if p_kind='join' and not exists(select 1 from public.site_settings where published and coalesce((data->>'hiring')::boolean,false)) then raise exception 'Applications closed' using errcode='A0403';end if;
 if not public.consume_rate_limit(p_ip_key,8,3600) or not public.consume_rate_limit(p_email_key,5,3600) then raise exception 'Rate limit' using errcode='A0429';end if;
 target:=case when p_kind='join' then 'volunteer_applications' else 'contact_messages' end;
 execute format('insert into public.%I(id,idempotency_key,name,email,answers,consent_version,consent_at) values($1,$1,$2,$3,$4,$5,now())',target)
 using p_id,p_payload->>'name',lower(p_payload->>'email'),p_payload-'website'-'idempotencyKey','aur-privacy-v3';
 insert into private.submission_receipts(id,kind,request_hash) values(p_id,p_kind,p_hash);
 insert into public.submission_events(application_id,contact_id,event) values(case when p_kind='join' then p_id end,case when p_kind='contact' then p_id end,'received');
 return left(p_id::text,8);
end $$;

create function public.session_allowed(p_actor uuid,p_session uuid,p_iat bigint) returns boolean language sql stable security invoker set search_path='' as $$
 select exists(select 1 from public.admin_roles where user_id=p_actor and enabled and p_iat>sessions_valid_after)
 and not exists(select 1 from private.revoked_sessions where id=p_session and expires_at>now());
$$;
create function public.revoke_session(p_actor uuid,p_session uuid,p_all boolean default false) returns void language plpgsql security invoker set search_path='' as $$
begin
 perform private.assert_actor(p_actor,array['owner','admin','editor','inbox_reviewer']);
 if p_all then update public.admin_roles set sessions_valid_after=floor(extract(epoch from now())) where user_id=p_actor;
 else insert into private.revoked_sessions(id,expires_at) values(p_session,now()+interval '7 days') on conflict(id) do nothing;end if;
 delete from private.revoked_sessions where expires_at<now();
 insert into public.audit_logs(actor_id,action,target_type,target_id) values(p_actor,'auth.revoke','session',case when p_all then 'all' else p_session::text end);
end $$;

create function public.cms_save(p_actor uuid,p_kind text,p_record jsonb,p_releases jsonb,p_media jsonb,p_expected integer) returns jsonb language plpgsql security invoker set search_path='' as $$
declare target text; record_id uuid; old_row jsonb; new_row jsonb; version integer; columns_sql text; assignments text; snapshot jsonb;
begin
 perform private.assert_actor(p_actor,case when p_kind='settings' then array['owner'] else array['owner','admin','editor'] end);
 target:=case p_kind when 'products' then 'products' when 'journal' then 'articles' when 'research' then 'research_posts' when 'team' then 'team_members' when 'settings' then 'site_settings' else null end;
 if target is null then raise exception 'Invalid content type';end if;
 record_id:=(p_record->>'id')::uuid;
 perform pg_advisory_xact_lock(hashtextextended(target||record_id::text,0));
 execute format('select to_jsonb(t) from public.%I t where id=$1 for update',target) into old_row using record_id;
 version:=coalesce((old_row->>'revision')::integer,0);
 if p_expected is null or p_expected<>version then raise exception 'Revision conflict' using errcode='A0409';end if;
 new_row:=p_record||jsonb_build_object('revision',version+1,'updated_at',now());
 if old_row->>'legacy_id' is not null then new_row:=new_row||jsonb_build_object('legacy_id',old_row->>'legacy_id');end if;
 select string_agg(quote_ident(column_name),',' order by ordinal_position),string_agg(format('%I=excluded.%I',column_name,column_name),',' order by ordinal_position)
 into columns_sql,assignments from information_schema.columns where table_schema='public' and table_name=target;
 execute format('insert into public.%I(%s) select %s from jsonb_populate_record(null::public.%I,$1) on conflict(id) do update set %s',target,columns_sql,columns_sql,target,assignments) using new_row;
 if p_kind='products' then
  -- Keep release identities when editing the same platform/version variant.
  select coalesce(jsonb_agg(item||jsonb_build_object('id',coalesce((select r.id from public.product_releases r where r.product_id=record_id and r.platform=item->>'platform' and r.architecture=item->>'architecture' and r.version=item->>'version'),(item->>'id')::uuid))),'[]') into p_releases from jsonb_array_elements(p_releases) item;
  delete from public.product_releases where product_id=record_id;
  insert into public.product_releases select * from jsonb_populate_recordset(null::public.product_releases,p_releases);
  delete from public.product_media where product_id=record_id;
  insert into public.product_media select * from jsonb_populate_recordset(null::public.product_media,p_media);
  if new_row->>'status'='released' and not exists(select 1 from public.product_releases where product_id=record_id and verified) then raise exception 'A release is required';end if;
 end if;
 if coalesce((new_row->>'published')::boolean,false) then
  update public.media_assets a set published=true where a.id in (
   select asset_id from public.product_media where product_id=record_id union select (new_row->>'cover_asset_id')::uuid union select (new_row->>'portrait_asset_id')::uuid
  ) and not deleting;
 end if;
 if p_kind='settings' then
  delete from public.auri_guides;
  insert into public.auri_guides(target_id,label,help_text,published) select key,key,value,true from jsonb_each_text(coalesce(new_row->'data'->'auriGuides','{}')) where length(trim(value))>0;
  delete from public.auri_faqs;
  insert into public.auri_faqs(id,question,answer,destination,position,published)
   select (value->>'id')::uuid,value->>'question',value->>'answer',nullif(value->>'destination',''),(ordinality-1)::int,coalesce((value->>'published')::boolean,true)
   from jsonb_array_elements(coalesce(new_row->'data'->'auriFaqs','[]')) with ordinality;
 end if;
 snapshot:=jsonb_build_object('row',new_row,'releases',p_releases,'media',p_media);
 insert into public.content_revisions(kind,record_id,snapshot,actor_id,revision) values(p_kind,record_id,snapshot,p_actor,version+1);
 insert into public.audit_logs(actor_id,action,target_type,target_id) values(p_actor,'content.save',p_kind,record_id::text);
 return jsonb_build_object('id',record_id,'revision',version+1);
end $$;

create function public.cms_delete(p_actor uuid,p_kind text,p_id uuid,p_expected integer) returns void language plpgsql security invoker set search_path='' as $$
declare target text; current_revision integer;
begin
 perform private.assert_actor(p_actor,array['owner','admin','editor']);
 target:=case p_kind when 'products' then 'products' when 'journal' then 'articles' when 'research' then 'research_posts' when 'team' then 'team_members' else null end;
 if target is null then raise exception 'Invalid content type';end if;
 perform pg_advisory_xact_lock(hashtextextended(target||p_id::text,0));
 execute format('select revision from public.%I where id=$1 for update',target) into current_revision using p_id;
 if current_revision is null or current_revision<>p_expected then raise exception 'Revision conflict' using errcode='A0409';end if;
 execute format('delete from public.%I where id=$1',target) using p_id;
 update private.legacy_map set deleted=true where target_id=p_id;
 insert into public.audit_logs(actor_id,action,target_type,target_id) values(p_actor,'content.delete',p_kind,p_id::text);
end $$;

create function public.inbox_page(p_actor uuid,p_kind text,p_status text,p_query text,p_before_time timestamptz,p_before_id uuid,p_limit integer default 25) returns jsonb language plpgsql stable security invoker set search_path='' as $$
begin
 perform private.assert_actor(p_actor,array['owner','admin','inbox_reviewer']);
 return (select coalesce(jsonb_agg(to_jsonb(t)),'[]') from (
  select * from (
   select id,'join'::text kind,name,email,answers::text data,status,created_at from public.volunteer_applications
   union all select id,'contact'::text kind,name,email,answers::text data,status,created_at from public.contact_messages
  ) combined where (p_kind='all' or kind=p_kind) and (p_status='all' or status=p_status)
   and (p_query='' or position(lower(p_query) in lower(name||' '||email||' '||data))>0)
   and (p_before_time is null or (created_at,id)<(p_before_time,p_before_id))
  order by created_at desc,id desc limit least(greatest(p_limit,1),101)
 ) t);
end $$;

create function public.inbox_action(p_actor uuid,p_kind text,p_id uuid,p_status text) returns void language plpgsql security invoker set search_path='' as $$
declare target text;
begin
 perform private.assert_actor(p_actor,case when p_status='delete' then array['owner','admin'] else array['owner','admin','inbox_reviewer'] end);
 target:=case p_kind when 'join' then 'volunteer_applications' when 'contact' then 'contact_messages' else null end;
 if target is null or p_status not in ('new','reviewing','replied','archived','delete') then raise exception 'Invalid inbox action';end if;
 if p_status='delete' then execute format('delete from public.%I where id=$1',target) using p_id;
 else
  execute format('update public.%I set status=$1 where id=$2',target) using p_status,p_id;
  insert into public.submission_events(application_id,contact_id,event,actor_id) values(case when p_kind='join' then p_id end,case when p_kind='contact' then p_id end,'status.'||p_status,p_actor);
 end if;
 if p_status='delete' then update private.submission_receipts set request_hash='deleted' where id=p_id;end if;
 insert into public.audit_logs(actor_id,action,target_type,target_id) values(p_actor,'inbox.'||p_status,p_kind,p_id::text);
end $$;

create function public.set_admin_role(p_actor uuid,p_user uuid,p_role text,p_enabled boolean) returns void language plpgsql security invoker set search_path='' as $$
begin
 perform private.assert_actor(p_actor,array['owner']);
 if p_actor=p_user then raise exception 'Use another owner to change your access' using errcode='A0403';end if;
 if p_role not in ('owner','admin','editor','inbox_reviewer') then raise exception 'Invalid role';end if;
 insert into public.admin_roles(user_id,role,enabled,granted_by) values(p_user,p_role,p_enabled,p_actor)
 on conflict(user_id) do update set role=excluded.role,enabled=excluded.enabled,granted_by=p_actor;
 insert into public.audit_logs(actor_id,action,target_type,target_id) values(p_actor,'role.update','user',p_user::text);
end $$;

create function public.media_references(p_id uuid) returns jsonb language sql stable security invoker set search_path='' as $$
 select coalesce(jsonb_agg(x),'[]') from (
  select 'products' kind,p.id,p.name title from public.product_media m join public.products p on p.id=m.product_id where m.asset_id=p_id
  union all select 'journal',id,title from public.articles where cover_asset_id=p_id
  union all select 'research',id,title from public.research_posts where cover_asset_id=p_id
  union all select 'team',id,name from public.team_members where portrait_asset_id=p_id
 union all select 'revision',record_id,kind||' revision '||revision from public.content_revisions where snapshot::text like '%'||p_id::text||'%'
 ) x;
$$;
create function public.prepare_media_delete(p_actor uuid,p_id uuid) returns text language plpgsql security invoker set search_path='' as $$
declare path text;
begin
 perform private.assert_actor(p_actor,array['owner','admin','editor']);
 select object_path into path from public.media_assets where id=p_id for update;
 if path is null then raise exception 'Missing image';end if;
 if jsonb_array_length(public.media_references(p_id))>0 then raise exception 'Image is referenced' using errcode='A0409';end if;
 update public.media_assets set deleting=true,published=false where id=p_id;
 return path;
end $$;
create function public.finish_media_delete(p_actor uuid,p_id uuid) returns void language plpgsql security invoker set search_path='' as $$
begin
 perform private.assert_actor(p_actor,array['owner','admin','editor']);
 delete from public.media_assets where id=p_id and deleting;
 insert into public.audit_logs(actor_id,action,target_type,target_id) values(p_actor,'media.delete','media',p_id::text);
end $$;
-- A pending deletion cannot be attached during the storage/object-delete gap.
create function private.guard_asset() returns trigger language plpgsql security invoker set search_path='' as $$
declare asset uuid;
begin
 asset:=(to_jsonb(NEW)->>(case TG_TABLE_NAME when 'product_media' then 'asset_id' when 'team_members' then 'portrait_asset_id' else 'cover_asset_id' end))::uuid;
 if asset is not null then perform 1 from public.media_assets where id=asset and not deleting for key share;if not found then raise exception 'Image unavailable' using errcode='A0409';end if;end if;
 return NEW;
end $$;
create trigger check_asset before insert or update on public.product_media for each row execute function private.guard_asset();
create trigger check_asset before insert or update on public.team_members for each row execute function private.guard_asset();
create trigger check_asset before insert or update on public.articles for each row execute function private.guard_asset();
create trigger check_asset before insert or update on public.research_posts for each row execute function private.guard_asset();

drop policy public_read on public.media_assets;
create policy public_read on public.media_assets for select to anon,authenticated using(published and not deleting);
drop policy public_read on public.product_media;
create policy public_read on public.product_media for select to anon,authenticated using(published and exists(select 1 from public.products p where p.id=product_id and p.published) and (external_url is not null or exists(select 1 from public.media_assets a where a.id=asset_id and a.published and not a.deleting)));
revoke all on function public.consume_rate_limit(text,integer,integer) from public,anon,authenticated;
grant execute on function public.consume_rate_limit(text,integer,integer) to service_role;
revoke all on function public.submit_form(uuid,text,jsonb,text,text,text) from public,anon,authenticated;
grant execute on function public.submit_form(uuid,text,jsonb,text,text,text) to service_role;
revoke all on function public.session_allowed(uuid,uuid,bigint) from public,anon,authenticated;
grant execute on function public.session_allowed(uuid,uuid,bigint) to service_role;
revoke all on function public.revoke_session(uuid,uuid,boolean) from public,anon,authenticated;
grant execute on function public.revoke_session(uuid,uuid,boolean) to service_role;
revoke all on function public.cms_save(uuid,text,jsonb,jsonb,jsonb,integer) from public,anon,authenticated;
grant execute on function public.cms_save(uuid,text,jsonb,jsonb,jsonb,integer) to service_role;
revoke all on function public.cms_delete(uuid,text,uuid,integer) from public,anon,authenticated;
grant execute on function public.cms_delete(uuid,text,uuid,integer) to service_role;
revoke all on function public.inbox_page(uuid,text,text,text,timestamptz,uuid,integer) from public,anon,authenticated;
grant execute on function public.inbox_page(uuid,text,text,text,timestamptz,uuid,integer) to service_role;
revoke all on function public.inbox_action(uuid,text,uuid,text) from public,anon,authenticated;
grant execute on function public.inbox_action(uuid,text,uuid,text) to service_role;
revoke all on function public.set_admin_role(uuid,uuid,text,boolean) from public,anon,authenticated;
grant execute on function public.set_admin_role(uuid,uuid,text,boolean) to service_role;
revoke all on function public.media_references(uuid) from public,anon,authenticated;
grant execute on function public.media_references(uuid) to service_role;
revoke all on function public.prepare_media_delete(uuid,uuid) from public,anon,authenticated;
grant execute on function public.prepare_media_delete(uuid,uuid) to service_role;
revoke all on function public.finish_media_delete(uuid,uuid) from public,anon,authenticated;
grant execute on function public.finish_media_delete(uuid,uuid) to service_role;
revoke all on function private.guard_asset() from public;
grant execute on function private.guard_asset() to service_role;

create function public.register_media(p_actor uuid,p_record jsonb) returns void language plpgsql security invoker set search_path='' as $$
begin
 perform private.assert_actor(p_actor,array['owner','admin','editor']);
 insert into public.media_assets select * from jsonb_populate_record(null::public.media_assets,p_record);
 insert into public.audit_logs(actor_id,action,target_type,target_id) values(p_actor,'media.upload','media',p_record->>'id');
end $$;
create function public.media_alt(p_actor uuid,p_id uuid,p_alt text) returns void language plpgsql security invoker set search_path='' as $$
begin
 perform private.assert_actor(p_actor,array['owner','admin','editor']);
 if length(p_alt)>300 then raise exception 'Alt text too long';end if;
 update public.media_assets set alt=p_alt where id=p_id;
 insert into public.audit_logs(actor_id,action,target_type,target_id) values(p_actor,'media.alt','media',p_id::text);
end $$;
revoke all on function public.register_media(uuid,jsonb) from public,anon,authenticated;
grant execute on function public.register_media(uuid,jsonb) to service_role;
revoke all on function public.media_alt(uuid,uuid,text) from public,anon,authenticated;
grant execute on function public.media_alt(uuid,uuid,text) to service_role;
revoke insert,update,delete on public.products from authenticated;
revoke insert,update,delete on public.articles from authenticated;
revoke insert,update,delete on public.research_posts from authenticated;
revoke insert,update,delete on public.team_members from authenticated;
revoke insert,update,delete on public.site_settings from authenticated;
revoke insert,update,delete on public.pages from authenticated;
revoke insert,update,delete on public.auri_guides from authenticated;
revoke insert,update,delete on public.auri_faqs from authenticated;
revoke insert,update,delete on public.product_releases from authenticated;
revoke insert,update,delete on public.product_media from authenticated;
revoke insert,update,delete on public.media_assets from authenticated;
revoke insert,update,delete on public.volunteer_applications from authenticated;
revoke insert,update,delete on public.contact_messages from authenticated;
revoke update(status) on public.volunteer_applications from authenticated;
revoke update(status) on public.contact_messages from authenticated;
commit;
