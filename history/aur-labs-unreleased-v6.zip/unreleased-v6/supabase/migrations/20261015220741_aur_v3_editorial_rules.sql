begin;
alter table public.auri_faqs drop constraint auri_faqs_destination_check;
alter table public.auri_faqs add constraint auri_faqs_destination_check check(destination is null or destination in ('/','/products','/about','/journal','/research','/join','/support','/contact','/privacy','/terms','/admin'));

-- Rules have independent RLS. Private drafts never live in publicly readable settings JSON.
create table public.auri_rules (
 id uuid primary key,
 settings_id uuid not null references public.site_settings(id) on delete cascade deferrable initially deferred,
 rule jsonb not null check(jsonb_typeof(rule)='object'),
 published boolean not null default false,
 check(length(rule->>'text') between 5 and 350),
 check(rule->>'trigger' in ('focus','hover','manual','error')),
 check((rule->>'priority')::integer between 0 and 100)
);
create index auri_rules_settings on public.auri_rules(settings_id);
create index media_assets_cursor on public.media_assets(created_at desc,id desc);
alter table public.auri_rules enable row level security;
revoke all on public.auri_rules from public,anon,authenticated;
grant select on public.auri_rules to anon,authenticated;
grant all on public.auri_rules to service_role;
create policy public_read on public.auri_rules for select to anon,authenticated using(published and exists(select 1 from public.site_settings s where s.id=settings_id and s.published));
create policy editor_read on public.auri_rules for select to authenticated using((select private.has_role(array['owner','admin','editor'])));

create function private.extract_auri_rules() returns trigger language plpgsql security invoker set search_path='' as $$
begin
 if new.data ? 'auriRules' then
  if jsonb_typeof(new.data->'auriRules')<>'array' or jsonb_array_length(new.data->'auriRules')>80 then raise exception 'Invalid rule set';end if;
  delete from public.auri_rules where settings_id=new.id;
  insert into public.auri_rules(id,settings_id,rule,published)
   select (value->>'id')::uuid,new.id,value,coalesce((value->>'published')::boolean,false) from jsonb_array_elements(new.data->'auriRules');
  new.data:=new.data-'auriRules';
 end if;
 -- FAQ drafts are retained in the RLS-protected auri_faqs table and revision snapshots.
 if new.data ? 'auriFaqs' then
  new.data:=jsonb_set(new.data,'{auriFaqs}',coalesce((select jsonb_agg(value) from jsonb_array_elements(new.data->'auriFaqs') where coalesce((value->>'published')::boolean,false)),'[]'));
 end if;
 return new;
end $$;
revoke all on function private.extract_auri_rules() from public,anon,authenticated;
grant execute on function private.extract_auri_rules() to service_role;
create trigger extract_auri_rules before insert or update of data on public.site_settings for each row execute function private.extract_auri_rules();
update public.site_settings set data=data;
create or replace function public.auri_save(p_actor uuid,p_id uuid,p_data jsonb,p_expected integer) returns jsonb language plpgsql security invoker set search_path='' as $$
declare current_row public.site_settings; new_data jsonb; snapshot jsonb;
begin
 perform private.assert_actor(p_actor,array['owner','admin','editor']);
 perform pg_advisory_xact_lock(hashtextextended('site_settings'||p_id::text,0));
 select * into current_row from public.site_settings where id=p_id for update;
 if current_row.id is null or current_row.revision<>p_expected then raise exception 'Revision conflict' using errcode='A0409';end if;
 -- Allow-list fields so an editor cannot change site identity or payment destinations.
 select coalesce(jsonb_object_agg(key,value),'{}') into new_data from jsonb_each(p_data) where key in ('auriGuides','auriFaqs','auriEnabled','auriPages','auriRules');
 update public.site_settings set data=data||new_data,revision=revision+1,updated_at=now() where id=p_id returning * into current_row;
 delete from public.auri_guides;
 insert into public.auri_guides(target_id,label,help_text,published) select key,key,value,true from jsonb_each_text(coalesce(p_data->'auriGuides','{}')) where length(trim(value))>0;
 delete from public.auri_faqs;
 insert into public.auri_faqs(id,question,answer,destination,position,published)
 select (value->>'id')::uuid,value->>'question',value->>'answer',nullif(value->>'destination',''),(ordinality-1)::int,coalesce((value->>'published')::boolean,true)
 from jsonb_array_elements(coalesce(p_data->'auriFaqs','[]')) with ordinality;
 snapshot:=jsonb_build_object('row',jsonb_set(to_jsonb(current_row),'{data}',current_row.data||new_data),'releases','[]'::jsonb,'media','[]'::jsonb);
 insert into public.content_revisions(kind,record_id,snapshot,actor_id,revision) values('settings',p_id,snapshot,p_actor,current_row.revision);
 insert into public.audit_logs(actor_id,action,target_type,target_id) values(p_actor,'auri.save','settings',p_id::text);
 return jsonb_build_object('id',p_id,'revision',current_row.revision);
end $$;
revoke all on function public.auri_save(uuid,uuid,jsonb,integer) from public,anon,authenticated;
grant execute on function public.auri_save(uuid,uuid,jsonb,integer) to service_role;

commit;
