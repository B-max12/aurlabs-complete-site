begin;
alter table public.media_assets add column width integer check(width between 1 and 12000);
alter table public.media_assets add column height integer check(height between 1 and 12000);
create function private.sync_asset_publication() returns trigger language plpgsql security invoker set search_path='' as $$
begin
 update public.media_assets a set published=not a.deleting and (
  exists(select 1 from public.product_media m join public.products p on p.id=m.product_id where m.asset_id=a.id and m.published and p.published)
  or exists(select 1 from public.articles t where t.cover_asset_id=a.id and t.published)
  or exists(select 1 from public.research_posts t where t.cover_asset_id=a.id and t.published)
  or exists(select 1 from public.team_members t where t.portrait_asset_id=a.id and t.published)
 );
 return null;
end $$;
revoke all on function private.sync_asset_publication() from public,anon,authenticated;
grant execute on function private.sync_asset_publication() to service_role;
create trigger media_visibility after insert or update or delete on public.product_media for each statement execute function private.sync_asset_publication();
create trigger product_media_visibility after insert or update or delete on public.products for each statement execute function private.sync_asset_publication();
create trigger article_media_visibility after insert or update or delete on public.articles for each statement execute function private.sync_asset_publication();
create trigger research_media_visibility after insert or update or delete on public.research_posts for each statement execute function private.sync_asset_publication();
create trigger team_media_visibility after insert or update or delete on public.team_members for each statement execute function private.sync_asset_publication();
grant select on private.revoked_sessions to authenticated;
create policy own_session_revocation on private.revoked_sessions for select to authenticated using(id=(select (auth.jwt()->>'session_id')::uuid));
create or replace function private.has_role(allowed text[]) returns boolean language sql stable security invoker set search_path='' as $$
 select (select auth.uid()) is not null and (select auth.jwt()->>'aal')='aal2'
 and exists(select 1 from public.admin_roles r where r.user_id=(select auth.uid()) and r.enabled and r.role=any(allowed) and r.sessions_valid_after<(select (auth.jwt()->>'iat')::bigint))
 and not exists(select 1 from private.revoked_sessions where id=(select (auth.jwt()->>'session_id')::uuid) and expires_at>now());
$$;
alter table private.legacy_map add column source_hash text;
alter table private.legacy_map add column last_revision integer;
create function public.migration_record(p_actor uuid,p_kind text,p_legacy text,p_id uuid,p_record jsonb,p_releases jsonb,p_media jsonb,p_deleted boolean,p_hash text) returns jsonb language plpgsql security invoker set search_path='' as $$
declare mapping private.legacy_map; target text; current_revision integer; result jsonb;
begin
 perform private.assert_actor(p_actor,array['owner']);
 if p_kind not in ('products','journal','research','team','settings','media','join','contact') or length(p_hash)<>64 then raise exception 'Invalid migration record';end if;
 perform pg_advisory_xact_lock(hashtextextended('migration:'||p_kind||':'||p_legacy,0));
 select * into mapping from private.legacy_map where kind=p_kind and legacy_id=p_legacy;
 if mapping.target_id is not null and mapping.target_id<>p_id then raise exception 'Identity mapping changed' using errcode='A0409';end if;
 if mapping.source_hash=p_hash and mapping.deleted=p_deleted then return jsonb_build_object('unchanged',true);end if;
 if p_kind in ('products','journal','research','team','settings') then
  target:=case p_kind when 'products' then 'products' when 'journal' then 'articles' when 'research' then 'research_posts' when 'team' then 'team_members' else 'site_settings' end;
  execute format('select revision from public.%I where id=$1',target) into current_revision using p_id;
  if coalesce(current_revision,0)<>coalesce(mapping.last_revision,0) then raise exception 'Target edited after import; reconcile manually' using errcode='A0409';end if;
  if p_deleted then
   if current_revision is not null then perform public.cms_delete(p_actor,p_kind,p_id,current_revision);end if;
   current_revision:=null;
  else
   result:=public.cms_save(p_actor,p_kind,p_record,p_releases,p_media,coalesce(current_revision,0));current_revision:=(result->>'revision')::integer;
  end if;
 elsif p_kind='media' then
  if mapping.target_id is not null then raise exception 'Changed media must be copied under a new immutable key' using errcode='A0409';end if;
  perform public.register_media(p_actor,p_record);
 else
  -- Historical consent keeps its source timestamp/version; it is never presented as fresh consent.
  target:=case p_kind when 'join' then 'volunteer_applications' else 'contact_messages' end;
  if mapping.target_id is not null then raise exception 'Imported submission changed; reconcile manually' using errcode='A0409';end if;
  execute format('insert into public.%I select * from jsonb_populate_record(null::public.%I,$1)',target,target) using p_record;
  insert into private.submission_receipts(id,kind,request_hash) values(p_id,p_kind,'legacy-import');
 end if;
 insert into private.legacy_map(kind,legacy_id,target_id,deleted,source_hash,last_revision) values(p_kind,p_legacy,p_id,p_deleted,p_hash,current_revision)
 on conflict(kind,legacy_id) do update set deleted=excluded.deleted,source_hash=excluded.source_hash,last_revision=excluded.last_revision;
 insert into public.audit_logs(actor_id,action,target_type,target_id) values(p_actor,'migration.import',p_kind,p_id::text);
 return jsonb_build_object('unchanged',false,'revision',current_revision);
end $$;
revoke all on function public.migration_record(uuid,text,text,uuid,jsonb,jsonb,jsonb,boolean,text) from public,anon,authenticated;
grant execute on function public.migration_record(uuid,text,text,uuid,jsonb,jsonb,jsonb,boolean,text) to service_role;

grant select(id,email_confirmed_at) on auth.users to service_role;
create function public.bootstrap_owner(p_user uuid) returns void language plpgsql security invoker set search_path='' as $$
begin
 perform pg_advisory_xact_lock(hashtextextended('aur-bootstrap-owner',0));
 if exists(select 1 from public.admin_roles where role='owner' and enabled) then raise exception 'An active owner already exists';end if;
 if not exists(select 1 from auth.users where id=p_user and email_confirmed_at is not null) then raise exception 'Enroll and verify the exact Auth user first';end if;
 insert into public.admin_roles(user_id,role,enabled) values(p_user,'owner',true);
 insert into public.audit_logs(actor_id,action,target_type,target_id) values(p_user,'owner.bootstrap','admin_roles',p_user::text);
end $$;
revoke all on function public.bootstrap_owner(uuid) from public,anon,authenticated;
grant execute on function public.bootstrap_owner(uuid) to service_role;
commit;
