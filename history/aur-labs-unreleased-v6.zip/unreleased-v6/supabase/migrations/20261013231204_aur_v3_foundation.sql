-- Aur Labs 3.0 foundation. UNAPPLIED; staging and release gates are documented in docs/.
-- Never apply this migration as an implicit production cutover.
begin;
create schema if not exists private;
revoke all on schema private from public;
grant usage on schema private to authenticated;

create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text not null check (length(display_name) between 1 and 120),
 created_at timestamptz not null default now()
);
create table public.admin_roles (
 user_id uuid primary key references auth.users(id) on delete cascade,
 role text not null check (role in ('owner','admin','editor','inbox_reviewer')),
 enabled boolean not null default true,
 granted_by uuid references auth.users(id) on delete set null,
 created_at timestamptz not null default now()
);
-- The invoker can see only their own role row. No elevated lookup or signup bootstrap.
create function private.has_role(allowed text[]) returns boolean
language sql stable security invoker set search_path = '' as $$
 select (select auth.uid()) is not null and exists (
  select 1 from public.admin_roles r where r.user_id=(select auth.uid()) and r.enabled and r.role=any(allowed)
 );
$$;
revoke all on function private.has_role(text[]) from public;
grant execute on function private.has_role(text[]) to authenticated;

create table public.site_settings (
 id uuid primary key default gen_random_uuid(), singleton boolean not null default true unique check(singleton),
 data jsonb not null check(jsonb_typeof(data)='object'), published boolean not null default false,
 updated_at timestamptz not null default now()
);
create table public.pages (
 id uuid primary key default gen_random_uuid(), slug text not null unique check(slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
 title text not null, body text not null default '', published boolean not null default false,
 updated_at timestamptz not null default now()
);
create table public.products (
 id uuid primary key default gen_random_uuid(), legacy_id text unique,
 slug text not null unique check(slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'), name text not null,
 tagline text not null, description text not null, category text not null check(category in ('software','app','cli')),
 platforms text[] not null check(cardinality(platforms)>0),
 status text not null default 'concept' check(status in ('concept','development','released')),
 featured boolean not null default false, features text[] not null default '{}',
 repository text check(repository is null or repository ~ '^https://'), license text not null,
 visual text not null default 'notes' check(visual in ('notes','mobile','terminal')),
 published boolean not null default false, updated_at timestamptz not null default now()
);
create table public.product_releases (
 id uuid primary key default gen_random_uuid(), product_id uuid not null references public.products(id) on delete cascade,
 platform text not null, version text not null, architecture text not null, requirements text not null,
 download_url text not null check(download_url ~ '^https://'),
 checksum_sha256 text check(checksum_sha256 is null or checksum_sha256 ~ '^[a-fA-F0-9]{64}$'),
 notes text not null default '', released_on date not null, verified boolean not null default false,
 published boolean not null default false,
 unique(product_id,platform,architecture,version)
);
create table public.media_assets (
 id uuid primary key default gen_random_uuid(), legacy_id text unique,
 bucket text not null, object_path text not null, original_name text not null,
 mime text not null check(mime in ('image/png','image/jpeg','image/webp','image/gif')),
 size_bytes bigint not null check(size_bytes between 1 and 5242880),
 sha256 text check(sha256 is null or sha256 ~ '^[a-fA-F0-9]{64}$'),
 alt text not null default '', published boolean not null default false,
 created_at timestamptz not null default now(), unique(bucket,object_path)
);
create table public.product_media (
 id uuid primary key default gen_random_uuid(), product_id uuid not null references public.products(id) on delete cascade,
 asset_id uuid not null references public.media_assets(id) on delete restrict,
 position integer not null default 0 check(position>=0), published boolean not null default false,
 unique(product_id,position)
);
create table public.articles (
 id uuid primary key default gen_random_uuid(), legacy_id text unique,
 slug text not null unique check(slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
 title text not null, summary text not null, body text not null, tag text not null, author text not null,
 published_on date not null, cover_asset_id uuid references public.media_assets(id) on delete restrict,
 external_cover_url text check(external_cover_url is null or external_cover_url ~ '^https://'),
 references_json jsonb not null default '[]' check(jsonb_typeof(references_json)='array'),
 published boolean not null default false, updated_at timestamptz not null default now()
);
create table public.research_posts (like public.articles including all);
alter table public.research_posts add foreign key (cover_asset_id) references public.media_assets(id) on delete restrict;
create table public.team_members (
 id uuid primary key default gen_random_uuid(), legacy_id text unique,
 name text not null, role text not null, bio text not null, initials text not null check(length(initials) between 1 and 4),
 portrait_asset_id uuid references public.media_assets(id) on delete restrict,
 external_portrait_url text check(external_portrait_url is null or external_portrait_url ~ '^https://'),
 profile_url text check(profile_url is null or profile_url ~ '^https://'),
 published boolean not null default false, updated_at timestamptz not null default now()
);
create table public.volunteer_applications (
 id uuid primary key default gen_random_uuid(), legacy_id text unique,
 idempotency_key uuid not null unique, name text not null, email text not null,
 answers jsonb not null check(jsonb_typeof(answers)='object'),
 consent_version text not null, consent_at timestamptz not null,
 status text not null default 'new' check(status in ('new','reviewing','replied','archived')),
 created_at timestamptz not null default now()
);
create table public.contact_messages (like public.volunteer_applications including all);
create table public.submission_events (
 id uuid primary key default gen_random_uuid(),
 application_id uuid references public.volunteer_applications(id) on delete cascade,
 contact_id uuid references public.contact_messages(id) on delete cascade,
 event text not null, actor_id uuid references auth.users(id) on delete set null,
 created_at timestamptz not null default now(), check(num_nonnulls(application_id,contact_id)=1)
);
create table public.auri_guides (
 id uuid primary key default gen_random_uuid(), target_id text not null unique check(target_id ~ '^[a-z][a-z0-9-]{0,79}$'),
 label text not null, help_text text not null check(length(help_text) between 1 and 350),
 published boolean not null default false, updated_at timestamptz not null default now()
);
create table public.auri_faqs (
 id uuid primary key default gen_random_uuid(), question text not null, answer text not null,
 destination text check(destination is null or destination ~ '^/[^/]'), position integer not null default 0,
 published boolean not null default false, updated_at timestamptz not null default now()
);
create table public.content_revisions (
 id uuid primary key default gen_random_uuid(), kind text not null, record_id uuid not null,
 snapshot jsonb not null check(jsonb_typeof(snapshot)='object'), actor_id uuid references auth.users(id) on delete set null,
 created_at timestamptz not null default now()
);
create table public.audit_logs (
 id uuid primary key default gen_random_uuid(), actor_id uuid references auth.users(id) on delete set null,
 action text not null, target_type text not null, target_id text not null,
 created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
revoke all on public.profiles from anon, authenticated;
grant all on public.profiles to service_role;

alter table public.admin_roles enable row level security;
revoke all on public.admin_roles from anon, authenticated;
grant all on public.admin_roles to service_role;

alter table public.site_settings enable row level security;
revoke all on public.site_settings from anon, authenticated;
grant all on public.site_settings to service_role;

alter table public.pages enable row level security;
revoke all on public.pages from anon, authenticated;
grant all on public.pages to service_role;

alter table public.products enable row level security;
revoke all on public.products from anon, authenticated;
grant all on public.products to service_role;

alter table public.articles enable row level security;
revoke all on public.articles from anon, authenticated;
grant all on public.articles to service_role;

alter table public.research_posts enable row level security;
revoke all on public.research_posts from anon, authenticated;
grant all on public.research_posts to service_role;

alter table public.team_members enable row level security;
revoke all on public.team_members from anon, authenticated;
grant all on public.team_members to service_role;

alter table public.auri_guides enable row level security;
revoke all on public.auri_guides from anon, authenticated;
grant all on public.auri_guides to service_role;

alter table public.auri_faqs enable row level security;
revoke all on public.auri_faqs from anon, authenticated;
grant all on public.auri_faqs to service_role;

alter table public.media_assets enable row level security;
revoke all on public.media_assets from anon, authenticated;
grant all on public.media_assets to service_role;

alter table public.product_releases enable row level security;
revoke all on public.product_releases from anon, authenticated;
grant all on public.product_releases to service_role;

alter table public.product_media enable row level security;
revoke all on public.product_media from anon, authenticated;
grant all on public.product_media to service_role;

alter table public.volunteer_applications enable row level security;
revoke all on public.volunteer_applications from anon, authenticated;
grant all on public.volunteer_applications to service_role;

alter table public.contact_messages enable row level security;
revoke all on public.contact_messages from anon, authenticated;
grant all on public.contact_messages to service_role;

alter table public.submission_events enable row level security;
revoke all on public.submission_events from anon, authenticated;
grant all on public.submission_events to service_role;

alter table public.content_revisions enable row level security;
revoke all on public.content_revisions from anon, authenticated;
grant all on public.content_revisions to service_role;

alter table public.audit_logs enable row level security;
revoke all on public.audit_logs from anon, authenticated;
grant all on public.audit_logs to service_role;

grant select on public.admin_roles to authenticated;
create policy own_role on public.admin_roles for select to authenticated using(user_id=(select auth.uid()));
grant select on public.profiles to authenticated;
grant update(display_name) on public.profiles to authenticated;
create policy own_profile on public.profiles for select to authenticated using(id=(select auth.uid()));
create policy update_own_profile on public.profiles for update to authenticated using(id=(select auth.uid())) with check(id=(select auth.uid()));

grant select on public.site_settings to anon, authenticated;
grant insert, update, delete on public.site_settings to authenticated;
create policy public_read on public.site_settings for select to anon, authenticated using(published);
create policy editor_read on public.site_settings for select to authenticated using((select private.has_role(array['owner','admin'])));
create policy editor_insert on public.site_settings for insert to authenticated with check((select private.has_role(array['owner','admin'])));
create policy editor_update on public.site_settings for update to authenticated using((select private.has_role(array['owner','admin']))) with check((select private.has_role(array['owner','admin'])));
create policy editor_delete on public.site_settings for delete to authenticated using((select private.has_role(array['owner','admin'])));

grant select on public.pages to anon, authenticated;
grant insert, update, delete on public.pages to authenticated;
create policy public_read on public.pages for select to anon, authenticated using(published);
create policy editor_read on public.pages for select to authenticated using((select private.has_role(array['owner','admin','editor'])));
create policy editor_insert on public.pages for insert to authenticated with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_update on public.pages for update to authenticated using((select private.has_role(array['owner','admin','editor']))) with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_delete on public.pages for delete to authenticated using((select private.has_role(array['owner','admin','editor'])));

grant select on public.products to anon, authenticated;
grant insert, update, delete on public.products to authenticated;
create policy public_read on public.products for select to anon, authenticated using(published);
create policy editor_read on public.products for select to authenticated using((select private.has_role(array['owner','admin','editor'])));
create policy editor_insert on public.products for insert to authenticated with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_update on public.products for update to authenticated using((select private.has_role(array['owner','admin','editor']))) with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_delete on public.products for delete to authenticated using((select private.has_role(array['owner','admin','editor'])));

grant select on public.articles to anon, authenticated;
grant insert, update, delete on public.articles to authenticated;
create policy public_read on public.articles for select to anon, authenticated using(published);
create policy editor_read on public.articles for select to authenticated using((select private.has_role(array['owner','admin','editor'])));
create policy editor_insert on public.articles for insert to authenticated with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_update on public.articles for update to authenticated using((select private.has_role(array['owner','admin','editor']))) with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_delete on public.articles for delete to authenticated using((select private.has_role(array['owner','admin','editor'])));

grant select on public.research_posts to anon, authenticated;
grant insert, update, delete on public.research_posts to authenticated;
create policy public_read on public.research_posts for select to anon, authenticated using(published);
create policy editor_read on public.research_posts for select to authenticated using((select private.has_role(array['owner','admin','editor'])));
create policy editor_insert on public.research_posts for insert to authenticated with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_update on public.research_posts for update to authenticated using((select private.has_role(array['owner','admin','editor']))) with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_delete on public.research_posts for delete to authenticated using((select private.has_role(array['owner','admin','editor'])));

grant select on public.team_members to anon, authenticated;
grant insert, update, delete on public.team_members to authenticated;
create policy public_read on public.team_members for select to anon, authenticated using(published);
create policy editor_read on public.team_members for select to authenticated using((select private.has_role(array['owner','admin','editor'])));
create policy editor_insert on public.team_members for insert to authenticated with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_update on public.team_members for update to authenticated using((select private.has_role(array['owner','admin','editor']))) with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_delete on public.team_members for delete to authenticated using((select private.has_role(array['owner','admin','editor'])));

grant select on public.auri_guides to anon, authenticated;
grant insert, update, delete on public.auri_guides to authenticated;
create policy public_read on public.auri_guides for select to anon, authenticated using(published);
create policy editor_read on public.auri_guides for select to authenticated using((select private.has_role(array['owner','admin','editor'])));
create policy editor_insert on public.auri_guides for insert to authenticated with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_update on public.auri_guides for update to authenticated using((select private.has_role(array['owner','admin','editor']))) with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_delete on public.auri_guides for delete to authenticated using((select private.has_role(array['owner','admin','editor'])));

grant select on public.auri_faqs to anon, authenticated;
grant insert, update, delete on public.auri_faqs to authenticated;
create policy public_read on public.auri_faqs for select to anon, authenticated using(published);
create policy editor_read on public.auri_faqs for select to authenticated using((select private.has_role(array['owner','admin','editor'])));
create policy editor_insert on public.auri_faqs for insert to authenticated with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_update on public.auri_faqs for update to authenticated using((select private.has_role(array['owner','admin','editor']))) with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_delete on public.auri_faqs for delete to authenticated using((select private.has_role(array['owner','admin','editor'])));

grant select on public.media_assets to anon, authenticated;
grant insert, update, delete on public.media_assets to authenticated;
create policy public_read on public.media_assets for select to anon, authenticated using(published);
create policy editor_read on public.media_assets for select to authenticated using((select private.has_role(array['owner','admin','editor'])));
create policy editor_insert on public.media_assets for insert to authenticated with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_update on public.media_assets for update to authenticated using((select private.has_role(array['owner','admin','editor']))) with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_delete on public.media_assets for delete to authenticated using((select private.has_role(array['owner','admin','editor'])));

grant select on public.product_releases to anon, authenticated;
grant insert, update, delete on public.product_releases to authenticated;
create policy public_read on public.product_releases for select to anon, authenticated using(published and verified and exists(select 1 from public.products p where p.id=product_id and p.published));
create policy editor_read on public.product_releases for select to authenticated using((select private.has_role(array['owner','admin','editor'])));
create policy editor_insert on public.product_releases for insert to authenticated with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_update on public.product_releases for update to authenticated using((select private.has_role(array['owner','admin','editor']))) with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_delete on public.product_releases for delete to authenticated using((select private.has_role(array['owner','admin','editor'])));

grant select on public.product_media to anon, authenticated;
grant insert, update, delete on public.product_media to authenticated;
create policy public_read on public.product_media for select to anon, authenticated using(published and exists(select 1 from public.products p where p.id=product_id and p.published) and exists(select 1 from public.media_assets a where a.id=asset_id and a.published));
create policy editor_read on public.product_media for select to authenticated using((select private.has_role(array['owner','admin','editor'])));
create policy editor_insert on public.product_media for insert to authenticated with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_update on public.product_media for update to authenticated using((select private.has_role(array['owner','admin','editor']))) with check((select private.has_role(array['owner','admin','editor'])));
create policy editor_delete on public.product_media for delete to authenticated using((select private.has_role(array['owner','admin','editor'])));

grant select, delete on public.volunteer_applications to authenticated;
grant update(status) on public.volunteer_applications to authenticated;
create policy reviewer_read on public.volunteer_applications for select to authenticated using((select private.has_role(array['owner','admin','inbox_reviewer'])));
create policy reviewer_update on public.volunteer_applications for update to authenticated using((select private.has_role(array['owner','admin','inbox_reviewer']))) with check((select private.has_role(array['owner','admin','inbox_reviewer'])));
create policy administrator_delete on public.volunteer_applications for delete to authenticated using((select private.has_role(array['owner','admin'])));
create index volunteer_applications_inbox_idx on public.volunteer_applications(status,created_at desc,id desc);

grant select, delete on public.contact_messages to authenticated;
grant update(status) on public.contact_messages to authenticated;
create policy reviewer_read on public.contact_messages for select to authenticated using((select private.has_role(array['owner','admin','inbox_reviewer'])));
create policy reviewer_update on public.contact_messages for update to authenticated using((select private.has_role(array['owner','admin','inbox_reviewer']))) with check((select private.has_role(array['owner','admin','inbox_reviewer'])));
create policy administrator_delete on public.contact_messages for delete to authenticated using((select private.has_role(array['owner','admin'])));
create index contact_messages_inbox_idx on public.contact_messages(status,created_at desc,id desc);

grant select on public.submission_events to authenticated;
create policy staff_read on public.submission_events for select to authenticated using((select private.has_role(array['owner','admin','inbox_reviewer'])));

grant select on public.content_revisions to authenticated;
create policy staff_read on public.content_revisions for select to authenticated using((select private.has_role(array['owner','admin','editor'])));

grant select on public.audit_logs to authenticated;
create policy staff_read on public.audit_logs for select to authenticated using((select private.has_role(array['owner','admin'])));

create index releases_product_idx on public.product_releases(product_id,released_on desc);
create index product_media_asset_idx on public.product_media(asset_id);
create index products_catalogue_idx on public.products(featured desc,name) where published;
create index articles_date_idx on public.articles(published_on desc) where published;
create index research_date_idx on public.research_posts(published_on desc) where published;
create index articles_cover_idx on public.articles(cover_asset_id);
create index research_cover_idx on public.research_posts(cover_asset_id);
create index team_portrait_idx on public.team_members(portrait_asset_id);
create index events_application_idx on public.submission_events(application_id);
create index events_contact_idx on public.submission_events(contact_id);
create index events_actor_idx on public.submission_events(actor_id);
create index revisions_record_idx on public.content_revisions(kind,record_id,created_at desc);
create index revisions_actor_idx on public.content_revisions(actor_id);
create index audit_created_idx on public.audit_logs(created_at desc,id desc);
create index audit_actor_idx on public.audit_logs(actor_id);
create index role_grantor_idx on public.admin_roles(granted_by);
commit;
