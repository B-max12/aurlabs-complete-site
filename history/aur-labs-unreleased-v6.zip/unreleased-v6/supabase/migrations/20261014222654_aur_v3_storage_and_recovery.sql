begin;
alter table public.auri_faqs drop constraint auri_faqs_destination_check;
alter table public.auri_faqs add constraint auri_faqs_destination_check check(destination is null or destination='/' or destination ~ '^/[^/]');
-- Storage objects are served through the checked media route, never a public bucket.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('aur-assets-v3','aur-assets-v3',false,5242880,array['image/png','image/jpeg','image/webp','image/gif'])
on conflict(id) do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;

create function public.auri_save(p_actor uuid,p_id uuid,p_data jsonb,p_expected integer) returns jsonb language plpgsql security invoker set search_path='' as $$
declare current_row public.site_settings; new_data jsonb; snapshot jsonb;
begin
 perform private.assert_actor(p_actor,array['owner','admin','editor']);
 perform pg_advisory_xact_lock(hashtextextended('site_settings'||p_id::text,0));
 select * into current_row from public.site_settings where id=p_id for update;
 if current_row.id is null or current_row.revision<>p_expected then raise exception 'Revision conflict' using errcode='A0409';end if;
 -- Allow-list fields so an editor cannot change site identity or payment destinations.
 select coalesce(jsonb_object_agg(key,value),'{}') into new_data from jsonb_each(p_data) where key in ('auriGuides','auriFaqs','auriEnabled','auriPages');
 update public.site_settings set data=data||new_data,revision=revision+1,updated_at=now() where id=p_id returning * into current_row;
 delete from public.auri_guides;
 insert into public.auri_guides(target_id,label,help_text,published) select key,key,value,true from jsonb_each_text(coalesce(current_row.data->'auriGuides','{}')) where length(trim(value))>0;
 delete from public.auri_faqs;
 insert into public.auri_faqs(id,question,answer,destination,position,published)
 select (value->>'id')::uuid,value->>'question',value->>'answer',nullif(value->>'destination',''),(ordinality-1)::int,coalesce((value->>'published')::boolean,true)
 from jsonb_array_elements(coalesce(current_row.data->'auriFaqs','[]')) with ordinality;
 snapshot:=jsonb_build_object('row',to_jsonb(current_row),'releases','[]'::jsonb,'media','[]'::jsonb);
 insert into public.content_revisions(kind,record_id,snapshot,actor_id,revision) values('settings',p_id,snapshot,p_actor,current_row.revision);
 insert into public.audit_logs(actor_id,action,target_type,target_id) values(p_actor,'auri.save','settings',p_id::text);
 return jsonb_build_object('id',p_id,'revision',current_row.revision);
end $$;
revoke all on function public.auri_save(uuid,uuid,jsonb,integer) from public,anon,authenticated;
grant execute on function public.auri_save(uuid,uuid,jsonb,integer) to service_role;

create table private.recovery_sessions(session_id uuid primary key,user_id uuid not null references auth.users(id) on delete cascade,expires_at timestamptz not null);
alter table private.recovery_sessions enable row level security;
grant all on private.recovery_sessions to service_role;
create function public.recovery_ticket(p_actor uuid,p_session uuid,p_consume boolean) returns boolean language plpgsql security invoker set search_path='' as $$
declare used uuid;
begin
 perform private.assert_actor(p_actor,array['owner','admin','editor','inbox_reviewer']);
 delete from private.recovery_sessions where expires_at<now();
 if p_consume then
  delete from private.recovery_sessions where session_id=p_session and user_id=p_actor and expires_at>now() returning session_id into used;
  return used is not null;
 end if;
 insert into private.recovery_sessions values(p_session,p_actor,now()+interval '15 minutes') on conflict(session_id) do update set expires_at=excluded.expires_at;
 return true;
end $$;
revoke all on function public.recovery_ticket(uuid,uuid,boolean) from public,anon,authenticated;
grant execute on function public.recovery_ticket(uuid,uuid,boolean) to service_role;
commit;
