import {DatabaseSync} from 'node:sqlite';
import {readFileSync,realpathSync,statSync,writeFileSync} from 'node:fs';
import {resolve,sep} from 'node:path';
import {createHash} from 'node:crypto';
export const siteId='appgprj_6acb04e29d2081918548275da19f51e4';
export const tables=['content','submissions','administrators','admin_unlocks','rate_limits','audit_log','media'];
export const sha=value=>createHash('sha256').update(value).digest('hex');
export const json=path=>JSON.parse(readFileSync(path,'utf8'));
export function secureWrite(path,value){writeFileSync(path,JSON.stringify(value,null,2)+'\n',{mode:0o600,flag:'wx'})}
export function backupFile(root,path){const base=realpathSync(root),file=realpathSync(resolve(base,path));if(!file.startsWith(base+sep)||!statSync(file).isFile())throw new Error('Backup path leaves its directory');return file}
export function verifyBackup(root){
 const manifest=json(resolve(root,'manifest.json'));
 if(manifest.format!=='aur-backup-v1'||manifest.siteId!==siteId||manifest.r2InventoryComplete!==true||!/^[a-f0-9]{40}$/.test(manifest.sourceCommit)||!Number.isFinite(Date.parse(manifest.exportedAt)))throw new Error('A complete, identified D1/R2 backup is required');
 if(!Array.isArray(manifest.files)||!Array.isArray(manifest.objects))throw new Error('Missing backup inventory');
 const entries=new Map();
 for(const item of manifest.files){if(entries.has(item.path))throw new Error('Duplicate backup file');const bytes=readFileSync(backupFile(root,item.path));if(bytes.length!==item.bytes||sha(bytes)!==item.sha256)throw new Error('Backup checksum mismatch');entries.set(item.path,item)}
 if(!entries.has('d1.sql'))throw new Error('Missing verified D1 SQL export');
 const sql=readFileSync(backupFile(root,'d1.sql'),'utf8');
 // D1 exports use ordinary tables/inserts. Reject filesystem escapes before isolated restore.
 if(/\b(attach|detach|load_extension|virtual\s+table)\b|vacuum\s+into/i.test(sql))throw new Error('SQL export contains unsupported operations');
 const db=new DatabaseSync(':memory:',{allowExtension:false});
 try{
  db.exec(sql);if(db.prepare('pragma integrity_check').get().integrity_check!=='ok')throw new Error('Restored database failed integrity check');
  if(db.prepare('pragma foreign_key_check').all().length)throw new Error('Restored foreign keys are inconsistent');
  const counts={};for(const table of tables){counts[table]=db.prepare('select count(*) n from '+table).get().n;if(counts[table]!==manifest.tables?.[table])throw new Error('Table count mismatch: '+table)}
  const snapshot={format:'aur-d1-backup-v1',projectId:siteId,complete:true,exportedAt:manifest.exportedAt,counts:{content:counts.content,media:counts.media,submissions:counts.submissions},content:db.prepare('select * from content').all(),media:db.prepare('select * from media').all(),submissions:db.prepare('select * from submissions').all()};
  const keys=new Set();for(const object of manifest.objects){if(!/^[a-f0-9-]+\.(png|jpg|webp|gif)$/.test(object.key)||keys.has(object.key))throw new Error('Unsupported or duplicate R2 object key');const entry=entries.get(object.file);if(!entry||entry.bytes!==object.size||entry.sha256!==object.sha256)throw new Error('Incomplete R2 byte backup');keys.add(object.key)}
  for(const media of snapshot.media){const object=manifest.objects.find(o=>o.key===media.id);if(!object||object.size!==media.size||object.mime!==media.mime)throw new Error('Media metadata differs from restored object inventory')}
  return {manifest,snapshot,report:{siteId,sourceCommit:manifest.sourceCommit,exportedAt:manifest.exportedAt,verifiedAt:new Date().toISOString(),counts,objects:keys.size,orphanObjects:keys.size-counts.media,manifestSha256:sha(readFileSync(resolve(root,'manifest.json'))),sqliteRestore:'passed',objectChecksums:'passed',providerInventory:'operator attestation; verify export completeness at source'}};
 }finally{db.close()}
}
