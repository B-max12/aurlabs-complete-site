import {registerHooks} from 'node:module';
import {existsSync,readFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import ts from 'typescript';
const rootDir=resolve(dirname(fileURLToPath(import.meta.url)),'../..');
registerHooks({resolve(specifier,context,next){if(specifier.startsWith('@/'))specifier=pathToFileURL(resolve(rootDir,specifier.slice(2))).href;try{return next(specifier,context)}catch(error){if(specifier.startsWith('.')||specifier.startsWith('file:'))for(const ext of ['.ts','.tsx']){const url=new URL(specifier,context.parentURL).href+ext;if(existsSync(fileURLToPath(url)))return {url,shortCircuit:true}}throw error}},load(url,context,next){if(/\.tsx?$/.test(url))return {format:'module',source:ts.transpileModule(readFileSync(fileURLToPath(url),'utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}}).outputText,shortCircuit:true};return next(url,context)}});
