import './typescript-loader.mjs';
import {resolve} from 'node:path';
import {readFileSync} from 'node:fs';
import {createClient} from '@supabase/supabase-js';
import {verifyBackup,secureWrite,json,sha,backupFile} from './backup.mjs';
const {prepareMigrationPlan}=await import('../../lib/migration-plan.ts');
const {toRecord}=await import('../../lib/content-record.ts');
const production='opbgjmoztvqjsmxexptv';
const canonical=value=>JSON.stringify(value&&typeof value==='object'?Array.isArray(value)?value.map(v=>JSON.parse(canonical(v))):Object.fromEntries(Object.keys(value).sort().map(k=>[k,JSON.parse(canonical(value[k]))])):value);
export function mappedId(kind,legacy){const h=sha('aur-labs-v3:'+kind+':'+legacy).slice(0,32).split('');h[12]='5';h[16]='8';const s=h.join('');return s.slice(0,8)+'-'+s.slice(8,12)+'-'+s.slice(12,16)+'-'+s.slice(16,20)+'-'+s.slice(20)}
export async function buildImport(root){
 const {manifest,snapshot,report}=verifyBackup(root),plan=prepareMigrationPlan(snapshot),records=[];
 const map=(kind,id)=>mappedId(kind,id);
 const iso=value=>new Date(typeof value==='number'?value:Number.isFinite(Number(value))?Number(value):value).toISOString();
 const add=(kind,legacy,id,record,releases=[],media=[],deleted=false)=>records.push({kind,legacy,id,record,releases,media,deleted,hash:sha(JSON.stringify({record,releases,media,deleted}))});
 for(const object of manifest.objects){const legacy=snapshot.media.find(m=>m.id===object.key);add('media',object.key,map('media',object.key),{id:map('media',object.key),legacy_id:object.key,bucket:'aur-assets-v3',object_path:object.key,original_name:legacy?.name||object.key,mime:object.mime,size_bytes:object.size,sha256:object.sha256,alt:'',published:false,created_at:iso(legacy?.created_at||manifest.exportedAt),deleting:false})}
 const asset=async url=>url.startsWith('/api/media/')?{asset_id:map('media',url.slice(11)),external_url:null}:{asset_id:null,external_url:url||null};
 for(const kind of ['settings','products','journal','research','team']){
  for(const data of kind==='settings'?[plan.content.settings]:plan.content[kind]){
   const legacy=kind==='settings'?'singleton':data.id,id=map(kind,legacy),converted=await toRecord(kind,{...data,legacy_id:legacy},id,asset);
   converted.releases.forEach((r,i)=>r.id=map('release',legacy+':'+[r.platform,r.version,r.architecture].join(':')));
   converted.media.forEach((r,i)=>r.id=map('product-media',legacy+':'+i));
   add(kind,legacy,id,converted.row,converted.releases,converted.media);
  }
 }
 for(const tombstone of plan.tombstones)add(tombstone.kind,tombstone.id,map(tombstone.kind,tombstone.id),{},[],[],true);
 for(const source of snapshot.submissions){const answers=JSON.parse(source.data);if(answers.consent!==true||(source.kind==='join'&&answers.volunteer!==true))throw new Error('Historical consent is missing; reconcile before import');add(source.kind,source.id,source.id,{id:source.id,legacy_id:source.id,idempotency_key:source.id,name:source.name,email:source.email,answers,consent_version:'legacy-v2-recorded',consent_at:iso(source.created_at),status:source.status,created_at:iso(source.created_at)})}
 if(new Set(records.map(r=>r.id)).size!==records.length)throw new Error('ID collision');
 return {format:'aur-import-v1',report,records};
}
export function stagingClient(file){
 const target=json(file);if(target.environment!=='staging'||!/^[a-z0-9]{15,30}$/.test(target.projectRef)||target.projectRef===production)throw new Error('This command is restricted to an explicitly identified separate staging project');
 const secret=process.env.SUPABASE_SECRET_KEY;if(!secret?.startsWith('sb_secret_'))throw new Error('Set the staging SUPABASE_SECRET_KEY through secure operator environment');
 return {target,client:createClient('https://'+target.projectRef+'.supabase.co',secret,{auth:{persistSession:false,autoRefreshToken:false},global:{fetch:(input,init)=>fetch(input,{...init,signal:AbortSignal.timeout(30000)})}})};
}
const check=result=>{if(result.error)throw new Error('Supabase operation failed ('+(result.error.code||result.error.status||'unknown')+'). Review staging; retry is safe.');return result.data};
async function main(){
 const [command,directory,targetFile]=process.argv.slice(2);if(!directory)throw new Error('Usage: node scripts/operations/migrate.mjs verify|plan|apply-staging|reconcile <backup-directory> [target.json]');
 const root=resolve(directory),plan=await buildImport(root);
 if(command==='verify'){console.log(JSON.stringify(plan.report,null,2));return}
 if(command==='plan'){secureWrite(resolve(root,'import-plan.json'),plan);secureWrite(resolve(root,'id-map.json'),plan.records.map(({kind,legacy,id})=>({kind,legacy,id})));console.log('Validated plan and durable ID map written with owner-only file permissions. Records: '+plan.records.length);return}
 if(!['apply-staging','reconcile'].includes(command)||!targetFile)throw new Error('An explicit staging target is required');
 const saved=json(resolve(root,'import-plan.json'));if(JSON.stringify(saved.records)!==JSON.stringify(plan.records)||saved.report.manifestSha256!==plan.report.manifestSha256)throw new Error('Backup changed after plan review');
 const {target,client}=stagingClient(targetFile);if(!target.ownerId)throw new Error('Set the explicitly enrolled owner UUID in target.json');
 check(await client.from('admin_roles').select('user_id').eq('user_id',target.ownerId).eq('role','owner').eq('enabled',true).single());
 if(command==='apply-staging'){
  for(const object of verifyBackup(root).manifest.objects){const bytes=readFileSync(backupFile(root,object.file));const existing=await client.storage.from('aur-assets-v3').download(object.key);if(!existing.error){if(sha(Buffer.from(await existing.data.arrayBuffer()))!==object.sha256)throw new Error('Immutable Storage object differs; stopped')}else{if(![400,404].includes(Number(existing.error.statusCode||existing.error.status)))throw new Error('Cannot inspect destination Storage object');check(await client.storage.from('aur-assets-v3').upload(object.key,bytes,{contentType:object.mime,upsert:false}))}const copied=check(await client.storage.from('aur-assets-v3').download(object.key));if(sha(Buffer.from(await copied.arrayBuffer()))!==object.sha256)throw new Error('Copied object checksum mismatch')}
  for(const r of plan.records)check(await client.rpc('migration_record',{p_actor:target.ownerId,p_kind:r.kind,p_legacy:r.legacy,p_id:r.id,p_record:r.record,p_releases:r.releases,p_media:r.media,p_deleted:r.deleted,p_hash:r.hash}));
 }
 if(command==='reconcile')for(const object of verifyBackup(root).manifest.objects){const copied=check(await client.storage.from('aur-assets-v3').download(object.key));const bytes=Buffer.from(await copied.arrayBuffer());if(bytes.length!==object.size||sha(bytes)!==object.sha256)throw new Error('Storage reconciliation mismatch');}
 const startedAt=new Date().toISOString(),counts={};
 const names={products:'products',journal:'articles',research:'research_posts',team:'team_members',settings:'site_settings',media:'media_assets',join:'volunteer_applications',contact:'contact_messages'};
 for(const r of plan.records){const row=check(await client.from(names[r.kind]).select('*').eq('id',r.id).maybeSingle());if(r.deleted?!!row:!row)throw new Error('Reconciliation found missing or resurrected record');if(row&&r.kind==='settings'){const rules=check(await client.from('auri_rules').select('rule').eq('settings_id',r.id));const faqs=check(await client.from('auri_faqs').select('*').order('position'));row.data={...row.data,auriRules:rules.map(x=>x.rule).sort((a,b)=>a.id.localeCompare(b.id)),auriFaqs:faqs.map(f=>({id:f.id,question:f.question,answer:f.answer,destination:f.destination||'',published:f.published}))};r.record.data={...r.record.data,auriRules:[...(r.record.data.auriRules||[])].sort((a,b)=>a.id.localeCompare(b.id))};}if(row)for(const key of Object.keys(r.record)){if(['published','deleting'].includes(key)&&r.kind==='media')continue;if(canonical(row[key])!==canonical(r.record[key])&&!(key.endsWith('_at')&&Date.parse(row[key])===Date.parse(r.record[key])))throw new Error('Reconciliation differs: '+r.kind+' / '+key)}}
 for(const [kind,table] of Object.entries(names)){const expected=plan.records.filter(r=>r.kind===kind&&!r.deleted).length;const result=await client.from(table).select('id',{head:true,count:'exact'});check(result);counts[kind]={source:expected,target:result.count};if(result.count!==expected)throw new Error('Unexpected target count: '+kind)}
 for(const r of plan.records.filter(r=>r.kind==='products'&&!r.deleted)){for(const [table,expected] of [['product_releases',r.releases],['product_media',r.media]]){const rows=check(await client.from(table).select('*').eq('product_id',r.id));if(rows.length!==expected.length)throw new Error('Child record count differs');for(const value of expected){const row=rows.find(x=>x.id===value.id);if(!row)throw new Error('Child identity differs');for(const key of Object.keys(value))if(canonical(row[key])!==canonical(value[key]))throw new Error('Child data differs')}}}
 secureWrite(resolve(root,'reconciliation-'+Date.now()+'.json'),{format:'aur-reconciliation-v1',environment:'staging',projectRef:target.projectRef,startedAt,completedAt:new Date().toISOString(),counts,recordsChecked:plan.records.length,objectHashesVerified:verifyBackup(root).manifest.objects.length,unexplainedDifferences:0,hostedRoleAndAuthTests:'pending'});
 console.log('Staging record counts and fields reconciled. Confirm published RLS views, Auth and browser journeys before cutover.');
}
if(process.argv[1]&&resolve(process.argv[1])===resolve(new URL(import.meta.url).pathname))main().catch(()=>{console.error('Operation stopped. Validate the backup, target and permissions; no credentials or record payloads were logged.');process.exitCode=1});
