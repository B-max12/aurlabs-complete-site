import {stagingClient} from './migrate.mjs';
const [file,userId]=process.argv.slice(2);
try{
 if(!file||!/^[a-f0-9-]{36}$/.test(userId||''))throw new Error('Explicit target and verified Auth user UUID required');
 const {client}=stagingClient(file),result=await client.auth.admin.getUserById(userId);
 if(result.error||!result.data.user.email_confirmed_at)throw new Error('Auth user must already exist with verified email');
 const bootstrap=await client.rpc('bootstrap_owner',{p_user:userId});if(bootstrap.error)throw new Error('Owner bootstrap refused');
 console.log('The explicitly selected verified account is now the staging owner.');
}catch{console.error('Enrollment stopped. Check the staging target and verified user; an existing active owner is never replaced.');process.exitCode=1}
