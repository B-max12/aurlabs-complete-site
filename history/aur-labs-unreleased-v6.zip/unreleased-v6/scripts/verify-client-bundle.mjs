import {readdirSync,readFileSync} from 'node:fs';
import {join} from 'node:path';
import {gzipSync} from 'node:zlib';
const root='dist/client/_next/static/chunks';
const chunks=readdirSync(root).filter(name=>name.endsWith('.js')).map(name=>{
 const bytes=readFileSync(join(root,name));
 if(bytes.includes('sb_secret_')||bytes.includes('SUPABASE_SECRET_KEY'))throw new Error('Server credential configuration reached a client chunk');
 return {name,bytes:bytes.length,gzip:gzipSync(bytes).length};
});
if(!chunks.length)throw new Error('No browser chunks found; bundle inspection did not run');
console.log(JSON.stringify({browserChunks:chunks.length,serverCredentialConfigurationAbsent:true,largest:chunks.sort((a,b)=>b.bytes-a.bytes).slice(0,5)},null,2));
