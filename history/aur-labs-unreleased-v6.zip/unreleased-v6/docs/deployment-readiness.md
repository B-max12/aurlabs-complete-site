# Aur Labs 3.0 — deployment readiness

Updated October 16, 2026 UTC. **Saved candidate only; production cutover is not approved or performed.**

The owner confirmed rotation of the exposed Supabase privileged keys in this conversation. This is owner confirmation, not an independent inspection of the revoked key IDs. No credential was copied into source or browser code.

The fresh [release evidence package](../release/README.md) records the exact v5 source and all required report paths. Production HTTP checks from this environment returned Cloudflare 1010; no live-browser smoke pass is claimed. Overall G0 and launch remain blocked.

## Current evidence

- Production baseline: version 2, commit `4847db8e2e23a9acb1083b4c60b3d272514265d4`, website `https://aurlabs.online`.
- Supabase project `opbgjmoztvqjsmxexptv` remains empty: read-only checks found **0 Auth users and 0 public tables**. No migrations have been applied there.
- Hosting runtime configuration is revision 2 with **no entries**. Supabase runtime keys are not configured.
- No staging branch was returned by the available branch inventory. An empty production schema is not a staging environment.
- Complete reads of D1 content/media/submissions found 0 override/media/submission rows. This is not a seven-table backup or R2 inventory.
- Source implements both backends. `AUR_BACKEND` defaults to `d1`; adding a key alone cannot switch production.

## Before staging can work

1. Identify a separate Supabase staging project/branch and its matching private website origin. A new paid branch requires organization selection and the provider's cost approval.
2. Export all seven D1 tables and enumerate/copy **every** R2 object, including orphans. Run the restore verifier on the actual backup; retain the encrypted backup outside source control.
3. Apply all five migrations to staging. Run hosted database/security/performance advisors and resolve findings.
4. Enroll and email-verify the intended Auth account, then bootstrap its owner role explicitly. Enable authenticator MFA; no public signup becomes an administrator.
5. Configure the staging runtime URL, publishable key and server-only secret key through hosting settings. Set `AUR_REQUIRE_MFA=true`, exact `AUR_PUBLIC_URL`, and `AUR_BACKEND=supabase` only on staging.
6. Configure email delivery/recovery template and only the OAuth providers the owner intends to support. Complete each provider's real round trip before exposing its button.
7. Generate database types from the applied staging schema and check them against the repository adapter. Import and reconcile the actual data and asset hashes.

## Required release evidence

| Gate | Evidence needed | Current status |
| --- | --- | --- |
| Code checks | TypeScript, production build, isolated suites | Run with this candidate; see implementation report |
| Database and Storage | Hosted anon/editor/reviewer/admin/owner tests, advisors, private object denial, upload/read/delete | Pending staging |
| Auth | Actual email/password, configured OAuth, MFA, expired session, logout/revocation and recovery emails | Pending staging/account configuration |
| Migration | Actual full backup restore, exact reconciliation, incremental retry, rollback rehearsal | Tooling implemented; actual run pending |
| Browser/device | Desktop/tablet/mobile, keyboard and screen reader, native dialog focus, gallery, Auri placement, slow network, reduced motion and disabled WebGL | Not run; browser-control capability unavailable |
| Performance | Measured Lighthouse/Core Web Vitals and bundle review | Build sizes can be reported; no Lighthouse score measured |
| Legal/content | Owner-reviewed privacy/terms, donation destinations, release URLs and compatibility | Pending owner review |
| Launch | Written signoff specifying candidate, env revision and cutover time | Not given |

## Implementation added in this candidate

- Auri context rules: stable registered target, focus/hover/manual/error trigger, browser locale, bounded priority, exact route or trailing wildcard, draft/publish state, deterministic preview and conflict-safe revision history.
- RLS-protected rule storage; draft FAQ/rule content removed from publicly readable settings. D1 public responses filter drafts too.
- Owner settings: navigation order/labels/destinations, hero text/buttons, identity and legal Markdown overrides. Private home/privacy/terms preview never saves.
- Media: SQL cursor pages of 24 on both backends, explicit alt-text save, reference checks and protected deletion. Optional still-image resizing/encoding runs in the browser before the existing server validation.
- Explicit provider linking from the authenticated Security page with MFA, an enabled-provider allow-list, PKCE and a signed ten-minute account binding.
- Interactive design examples, text-token contrast checks, expanded Auri targets, modal suppression and measured hint sizing.
- Migration reconciliation now reads back remote object bytes and produces a private JSON success report.

All these changes are implemented and tested locally. None has been tested in hosted staging or deployed. The media encoder itself needs a real browser to verify output appearance and browser support. Responsive image variant delivery is not enabled. The examples cover the shared controls/content/feedback states; exhaustive native-browser component acceptance remains pending. Scheduled publication is explicitly unavailable; install commands remain absent until reviewed real commands exist. No owner has accepted a post-launch backlog yet.

## Current local verification

548 assertions: D1/SSR 94, DOM/geometry 273, PostgreSQL/RLS 89, SDK/HTTP 53, migration tools 10, editorial/contrast/image sizing 29. TypeScript and production build pass. Browser bundle scanning found no server-secret configuration. The optional Three.js chunk remains approximately 132.7 KB gzip and loads only after animation opt-in. These are not Lighthouse scores or hosted acceptance.

See `release-evidence.json` for machine-readable gate status and `completion-status.md` for the remaining owner/operator handoff.

## How the hosted website and admin fit together

One domain serves both: visitors use `https://aurlabs.online`; authorized staff use `https://aurlabs.online/admin`. The admin path requires authentication and live role checks. It is not a second purchased domain.

After the Supabase cutover, a confirmed **Publish/Save** changes database content and appears on public requests without a source redeployment. Drafts remain private. Auri/settings publication follows the same rule. Code/layout changes require saving and deploying a new website version. Local edits or a saved-only version do not change the live website.

See `migration-runbook.md` for exact operator commands and rollback requirements. Do not remove D1/R2 or the known-good deployment during the acceptance window.
