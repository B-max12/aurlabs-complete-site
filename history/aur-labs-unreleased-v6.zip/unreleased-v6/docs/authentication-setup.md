# Aur Labs sign-in setup

The website code supports email/password and configured Google, GitHub, Apple, Microsoft, GitLab and custom Vercel sign-in. These are **administrator sign-in methods**, not permission grants. Every account still needs an explicit active role. The owner reports Google, GitHub, Microsoft/Azure, email/password and SMTP configured in the dashboards. Their target environment and real sign-in tests are still unverified; no OAuth client secret has been created or stored by this implementation.

## Two different callback addresses

For the existing production Supabase project, the provider-to-Supabase callback is:

`https://opbgjmoztvqjsmxexptv.supabase.co/auth/v1/callback`

Use that in the provider's OAuth application's callback/redirect setting **when the Supabase dashboard displays that exact callback**. For staging, copy the staging project's callback instead. A custom provider can show a provider-specific callback: copy it exactly rather than assuming it matches a built-in provider.

The second address is Supabase-to-your-website: `https://aurlabs.online/api/auth/callback`. Put this in Supabase Auth's **Redirect URLs** allow-list. Set the production **Site URL** to `https://aurlabs.online`. Add `/admin/recover` as a permitted recovery destination. Staging gets its own exact origin and allow-list. Do not use production-wide wildcards.

The website starts PKCE on the server, keeps its verifier in an HttpOnly Secure cookie, exchanges the callback code and checks the live role. Redirect destinations are fixed. An OAuth account without a role cannot open the studio.

## Email/password and first owner

1. In the staging Auth settings, disable public account signup. Enable email/password and require email confirmation. Set a suitable password policy and configure SMTP with a verified sending identity; test delivery.
2. Enroll the intended operator explicitly through Supabase Auth. Complete its email verification. A username such as `Awab.Founder` is not an email login. Use the actual verified account; never copy an old chat password.
3. Record that user's UUID. After migrations, run the controlled `enroll-owner.mjs` command in the migration runbook. It refuses an unverified user or an existing active owner. There is no first-signup bootstrap.
4. Sign in at the staging `/admin`, scan an authenticator QR code and verify a code. Keep `AUR_REQUIRE_MFA=true` for deployed studio access. Existing verified MFA is still required during recovery; losing both factors needs a separately verified operator recovery procedure.
5. For additional staff, enroll/verify their account first. The owner can grant editor, reviewer or admin access in Security. Admin can edit content and process inbox; only owner can change site settings or roles.

## Recovery email template

In Supabase's **Reset password** email template, use a confirmation link with the token hash:

```html
<a href="{{ .SiteURL }}/admin/recover?token_hash={{ .TokenHash }}">Recover your Aur Labs account</a>
```

The page removes the token from browser history and waits for an explicit confirmation click before consuming it. The server verifies it with `type: 'recovery'`, creates a 15-minute single-use recovery authorization, requires MFA when configured, updates the password and revokes existing studio sessions. A regular signed-in session cannot invoke a reset without that recovery authorization. Test the actual email template, expired/used link, other-device flow and MFA in staging before launch. No recovery emails were sent during local tests.

## Provider setup

| Method | Set up at provider | Configure in Supabase |
| --- | --- | --- |
| Google | Create a Web OAuth client in Google Cloud, configure branding/consent and test users if in testing mode; register the exact callback shown in Supabase | Enable Google and enter its Client ID and Client Secret |
| GitHub | Developer settings → OAuth Apps → create an OAuth app; website is Aur Labs, authorization callback is the Supabase callback | Enable GitHub with the OAuth app ID/secret |
| GitLab | Create an OAuth application, register the Supabase redirect URI and requested identity scopes according to the linked guide | Enable GitLab with the application ID/secret |
| Microsoft | Microsoft Entra → App registrations; choose supported account types, add a Web redirect URI and create a client secret | Enable Azure using the application ID and **secret value**, with a tenant URL matching the selected account type; the app requests the required email scope |
| Apple | Apple Developer account; configure Sign in with Apple, a Services ID for the website, approved domains/return URLs and signing key | Enable Apple with the web Services ID and generated client secret; renew the web client secret before its six-month limit |
| Vercel | Create a **Sign in with Vercel** application, enable identity scopes and register the callback displayed for the custom Supabase provider | Create a custom OIDC provider named `custom:vercel`, issuer `https://vercel.com`, its client ID/secret and `openid email profile`; keep PKCE enabled |

“iOS login” means **Sign in with Apple** for this website. Native iOS app setup is separate. Vercel sign-in does not move website hosting to Vercel. Provider-to-Supabase credentials belong in Supabase provider settings, never in the repository or public browser environment.

The Vercel configuration combines Supabase's documented custom OIDC support with Vercel's published issuer/discovery endpoint; this integration must still pass a real staging round trip. Do not confuse Sign in with Vercel with deployment workload OIDC or Vercel Passport.

## Show only tested buttons

After a provider works in staging, add its identifier to the staging hosting setting, for example:

```dotenv
AUR_OAUTH_PROVIDERS=google,github
```

Other supported identifiers are `apple`, `azure`, `gitlab`, `custom:vercel`. An empty value shows email/password only. Never enable every identifier just to display buttons. The server rejects providers outside this list.

Test success, denial/cancellation, wrong account, account with no role, existing linked account and logout. Check that a different provider does not accidentally create a second identity with no role. Email matching is not a replacement for verifying the correct Auth UUID.

## Official references checked

- [Supabase redirect URLs](https://supabase.com/docs/guides/auth/redirect-urls)
- [Google](https://supabase.com/docs/guides/auth/social-login/auth-google), [GitHub](https://supabase.com/docs/guides/auth/social-login/auth-github), [GitLab](https://supabase.com/docs/guides/auth/social-login/auth-gitlab)
- [Microsoft/Azure](https://supabase.com/docs/guides/auth/social-login/auth-azure), [Apple](https://supabase.com/docs/guides/auth/social-login/auth-apple)
- [Supabase custom OAuth/OIDC](https://supabase.com/docs/guides/auth/custom-oauth-providers)
- [Vercel authorization endpoints and discovery](https://vercel.com/docs/sign-in-with-vercel/authorization-server-api)
- [Supabase server-side authentication](https://supabase.com/docs/guides/auth/server-side)

## Explicit identity linking

After signing in with MFA, use **Security → Linked sign-in methods** to link a tested provider to the current account. Enable manual identity linking in the staging Auth configuration before testing this flow. The server calls Supabase `linkIdentity` using the current user's session, never the administrative API. A signed HttpOnly cookie binds the callback to that Auth UUID for ten minutes; mismatch, tampering or expiry fails closed. The callback remains `/api/auth/callback`. Provider cancellation may require signing in again. No unlink action is offered until its account-recovery implications are separately tested.

Test existing-linked identity, wrong account, conflicting identity, denied consent, expired binding and MFA loss in staging. Supabase may perform its documented automatic verified-email linking independently; a provider email alone never grants an Aur role. Verify the resulting UUID and identity list.

## Loss of both password and authenticator

This is an operator-assisted recovery gate, not a hidden website bypass. Before launch designate two recovery operators and record the owner's verified Auth UUID and approved identity-verification process outside source control. Verify a request through the pre-established owner contact and a second independent operator; record approval without recovery tokens, MFA seeds or document images in application logs. Freeze the affected role and revoke sessions through the authorized control plane, then perform provider-supported recovery under that approval. Require fresh email verification and MFA enrollment, verify identity/role, and test old-session denial before restoring access. Rehearse with a designated staging account and record timings. No production factor, role or account was changed by this implementation.

Reference: https://supabase.com/docs/guides/auth/auth-identity-linking and https://supabase.com/docs/reference/javascript/auth-linkidentity (checked during this implementation).
