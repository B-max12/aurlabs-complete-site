# Supabase architecture and access contract

Production uses D1/R2 until `AUR_BACKEND=supabase` is explicitly configured after staging acceptance. Unknown backend values and incomplete Supabase configuration fail closed. All privileged operations stay on the server. SSR Auth uses HttpOnly, Secure, SameSite=Lax cookies and no-store responses. Mutations require the same Origin.

The server verifies `auth.getUser()`, the live enabled role, signed claims and session revocation. MFA defaults to required. RLS independently requires AAL2 for staff reads, an enabled role, an issued-at timestamp newer than global revocation, and a non-revoked session. User metadata never grants permissions. RPC actor IDs come from the verified server session; these RPCs cannot be called with anon/authenticated credentials.

| Action | Owner | Admin | Editor | Inbox reviewer | Visitor |
| --- | --- | --- | --- | --- | --- |
| Published content | Yes | Yes | Yes | Yes | Yes |
| Draft content, CMS, media, Auri | Yes | Yes | Yes | No | No |
| Site settings and role grants | Yes | No | No | No | No |
| Inbox read/status | Yes | Yes | No | Yes | No |
| Inbox deletion | Yes | Yes | No | No | No |
| Audit metadata | Yes | Yes | No | No | No |
| Own password and MFA | Yes | Yes | Yes | Yes | No |

Direct authenticated mutations are revoked. API-authorized writes use SECURITY INVOKER RPCs, empty search paths, allow-lists, transaction locks and audit events. Own-role lookup is self-only. The operator bootstrap requires a verified Auth UUID and refuses when an active owner exists. No first-signup administrator or default password exists.

## Content and forms

The public repository reads published records and verified releases, including parent visibility. It follows complete, deterministic 500-row pages rather than silently truncating PostgREST responses; a 100,000-row guard fails explicitly. A large catalogue needs a route-specific paginated adapter before approaching that guard. Missing Supabase settings never resurrect source-seed products.

Saving content increments its revision and writes snapshot/audit atomically. Stale expected revisions return 409. Restore creates a new revision. Existing journal/research drafts have opt-in autosave; publication is explicit. Download verification is an operator assertion, not a claim that binaries were automatically audited.

Forms validate size, schema, Origin, honeypot, consent and rate limits. Transactions use a globally unique submission UUID and request hash. Identical retries return the same reference; a changed body/kind or deleted submission cannot create a duplicate. Hiring closure is checked in SQL. Inbox filters and cursor pagination run in SQL; exact counts supply new-message totals. Exports explicitly cover loaded data/page, not a full backup.

## Storage

`aur-assets-v3` is private, limits uploads to 5 MiB and allows PNG/JPEG/WebP/GIF. Server checks inspect signatures and raster header dimensions (12,000 maximum per side / 40 MP), assign immutable UUID paths and record SHA-256. Header validation is not a full decode or malware scan. Upload failure compensates by removing the newly uploaded object.

Public bytes require current published references. Draft/unattached objects require staff access. Previously public bytes may remain cached for 60 seconds after unpublishing. Delete checks current and historical references, marks the asset deleting to prevent racing attachments, removes bytes, then metadata. A partial deletion can be retried. Historical references conservatively prevent deletion; no automated revision purge is enabled.

## Migration and verification

Five CLI-created, unapplied files cover foundation/RLS, transactional operations, Storage/recovery migration/owner operations, and editorial rule isolation. Public tables cover profiles, roles, settings/pages, products/releases/media, articles/research, team, applications/contact, submission events, Auri guides/FAQs, assets, revisions and audit. Private tables hold rate buckets, receipts, revocations, recovery tickets and import mappings.

Mappings preserve submission UUID/reference, slugs, historical consent and tombstones. Password hashes, unlock tokens and legacy login sessions are not imported. See the runbook for checksum verification, deterministic identities, explicit staging targets and reconciliation.

PGlite tests execute all migrations with Auth/Storage schema stubs. HTTP tests run the pinned SDK against isolated network fixtures. Neither proves hosted Auth/Storage, SMTP, OAuth or RLS configuration. Hosted migrations/advisors, generated types and actual account/browser tests remain required.

Dependencies: `@supabase/supabase-js` 2.117.3 and `@supabase/ssr` 0.12.7. The official changelog was read, including announced legacy TLS and Postgres extension changes. This schema uses none of ltree, legacy pgcrypto calls, btree_gist or custom operators; modern Worker HTTPS is the transport. Verify actual staging compatibility before launch.

## Editorial additions

`auri_rules` is the nineteenth public table, with public reads limited to published rows and live editor access for drafts. Its settings foreign key is deferred so the existing transactional upsert can extract rules without storing drafts in public JSON. The settings trigger also removes draft FAQ copies from public JSON. The existing normalized FAQ table and private revision snapshots preserve them for editors and restore. The fifth migration extends the allow-listed Auri RPC without granting editors site-setting permissions. Authenticated direct writes remain revoked.

Media cursor ordering uses creation time plus ID to handle tied timestamps. Supabase has a matching composite index. Public content loading remains bounded by the repository's existing total-row guard; route-specific large-catalogue querying should be profiled against actual staging volume.

Signed identity-link state is HMAC-protected using the server-only secret, has a ten-minute lifetime, and binds the callback to the initiating Auth UUID. Linking requires a current role and configured MFA. Changing the server key invalidates any outstanding linking state, which can be restarted.
