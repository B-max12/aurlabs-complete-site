# Interaction registry — deployment candidate

`lib/auri-guides.ts` defines the shared label/help registry. Each public field exposes a stable `data-auri-id`, uses a real label, links its error/help descriptions and reserves an inline help slot. Compatibility `data-auri` attributes remain while admin coverage grows.

| Surface | Target IDs / control | Behavior and fallback |
| --- | --- | --- |
| Profile | name, email, timezone, portfolio | Inline validation; explicit help button; password fields excluded |
| Skills | role, stack, experience, hours, availability | Deterministic role descriptions; no telemetry |
| Perspective | motivation, problem, collaboration | Text remains local until confirmed submission |
| Review | Edit 1/2/3; volunteer, consent | Back to section; fresh consent after restore; confirmed-save reference only |
| Contact | topic, subject, product, platform, message, expected, actual, reproduction | Product URL context; optional structured problem report |
| Publishing | admin-publish, admin-save | Explains current save/publish semantics; server authorizes mutation |
| Auri controls | launcher, search, hint toggle, animation toggle, minimize/reset | Explicit dialog; session preferences; CSS default and inline fallback |
| Theme | Color theme | System/light/dark; local preference; prepaint script |
| Navigation | Open navigation / Close menu | Modal dialog, Escape, focus return, body scroll lock |
| Catalogue | category, platform, query, sort, page | URL state; debounced query; browser back/forward |
| Articles | HTTPS source links and Markdown links | External tab with noopener; raw HTML escaped |

State contract: DORMANT → AVAILABLE → TARGETING → MOVING → EXPLAINING → IDLE. ERROR_HELP, SUCCESS, DISMISSED and FALLBACK are explicit branches in `lib/auri-machine.ts`. Measurement selects a collision-free candidate or an inline slot. Motion phases are UI states, not promises of physics-based movement. Public default hints remain quiet. The optional 3D scene is loaded only after the animation choice and is skipped for reduced-motion/data-saving/no-WebGL conditions.

Still pending: native-browser component/focus/collision acceptance. Advanced per-rule editing and an interactive Design system section are implemented and tested locally. FAQ editing and page/global enablement are implemented. No form value, password, private message or applicant answer is sent to an AI service.


| Studio control | Permission / effect | Verification |
| --- | --- | --- |
| Email sign-in / configured OAuth | Verified Auth identity plus live role; PKCE cookies; no role from provider metadata | SDK boundary fixtures; real provider test pending |
| MFA enroll/verify/remove | Own identity; last required factor cannot be removed | API guards; real Auth test pending |
| Password change/recovery | Current password or single-use verified email authorization; revoke sessions | SDK/SQL fixtures; real email test pending |
| CMS save/publish | Content writer; owner for settings; expected revision | SQL atomicity/conflicts; D1 regression |
| Draft autosave | Opt-in, existing unpublished journal/research; same conflict checks | Source/server checks; browser acceptance pending |
| Revision restore | Authorized content writer; new revision; confirmation | SQL contract; browser acceptance pending |
| Inbox search/type/status/pages | Reviewer/admin/owner; SQL filters and cursor, full selected details | SQL/HTTP/DOM fixtures |
| Inbox status/delete/export | Role checked; deletion confirmation; page export labelled | SQL denial/retry tests; DOM role controls |
| Media upload/alt/references/delete | Writer; validated signature/dimensions, reference lock and deletion retry | Header and SQL fixtures; hosted Storage test pending |
| Role grant/disable | Owner, verified Auth UUID; no self-removal | HTTP/SQL denial tests |
| Auri FAQ/order/publish/page toggles | Writer; allow-listed Auri fields; preserves site identity | SQL/HTTP/DOM checks |
| Settings and approved payment links | Owner; validation and unsaved-edit guard | API authorization and schema tests |

All success messages follow confirmed API responses. No application mail notification, scheduled publication or automatic download completion is claimed. Admin exports are not complete backups.

## Candidate 5 traceable additions

Every row below is **implemented / locally tested / hosted staging pending / not deployed**.

| Route / control | Action | Permission and validation | Success / failure | Automated evidence | Manual evidence |
| --- | --- | --- | --- | --- | --- |
| `/admin` Auri / Add context rule, publish, remove, preview | CRUD and deterministic matching | Writer; known target, enum trigger, locale syntax, priority 0–100, bounded path; optimistic revision | Confirmed publication / inline API error or conflict | `editorial.mjs`, `client.mjs`, `supabase-schema.mjs`, `supabase-http.mjs` | Pending browser and locale/device checks |
| Public forms and catalogue / `data-auri-id` | Focus, pointer or explicit guidance | Opt-in automatic hints; no field-value access; password exclusion | Measured overlay or inline fallback; suppression while dialogs own focus | `client.mjs`, `editorial.mjs` | Pending actual mobile keyboard and screen reader |
| `/admin` Settings / navigation and hero fields | Owner publishes safe known-page links | Owner; unique destinations and bounded labels | Saved changes appear on subsequent public requests / validation error | `editorial.mjs`, `client.mjs`, existing HTTP owner guard | Pending hosted save and public readback |
| `/admin` Settings / privacy and terms | Owner publishes Markdown overrides | Owner; bounded text, escaped HTML, HTTPS links only | Confirmed save / errors preserve draft | `client.mjs`, existing Markdown and settings tests | Owner legal review pending |
| `/admin` Settings / Preview settings | Home/privacy/terms dialog with unsaved draft | Local only; no mutation; preview links suppressed | Close/return to editing | `client.mjs` | Native focus and responsive review pending |
| `/admin` Media / Next, Previous, reload | Server cursor pagination | Writer; validated opaque cursor, 24 rows | New page / error with reload | `integration.mjs`, `supabase-http.mjs`, `client.mjs` | Hosted large-library round trip pending |
| `/admin` Media / upload and optimize | Optional bounded still-image encode then server upload | Writer; source dimensions/size bounded; server repeats MIME/size checks | Persisted URL / explicit encode or upload error | `editorial.mjs` sizing, existing upload tests | Browser encoding fidelity and Storage pending |
| `/admin` Media / description, references, delete | Explicit save and reference-aware removal | Writer; validated alt text; confirm delete | Saved/deleted confirmation / protected-reference error | Existing SDK/SQL tests; new page tests | Hosted Storage pending |
| `/admin` Security / Link provider | Current-user PKCE identity linking | MFA; enabled provider; same Origin; signed account binding | Fixed callback / fail-closed signout | `supabase-http.mjs` | Provider success/cancel/conflict/mismatch pending |
| `/admin` Design system / categories, validate, reset, dialog | Local examples and state reference | No remote mutation | Error/status announcements and focus return | `client.mjs`, `editorial.mjs` token contrast | Native-browser/AT inspection pending |

Rule matching uses the visitor's browser language, highest priority, then locale and route specificity, then stable ID. Route syntax allows an exact path or terminal `/*`, never arbitrary regular expressions. Published matches only are returned publicly.
