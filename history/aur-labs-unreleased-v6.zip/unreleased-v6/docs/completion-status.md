# Aur Labs 3.0 — current completion status

This is a saved implementation candidate. It is not a launched Supabase site, and the complete plan is not yet finished.

The October 16 audit reverified exact v5 source: 548 local assertions, TypeScript and production build pass. All 15 required release reports are now prepared with measured or explicitly blocked results. [The release decision](../release/release-go-no-go.md) remains **NO-GO**: G0 operator/key-audit/browser evidence and the full backup/staging requirements are incomplete.

| Work | Implemented | Tested locally | Hosted staging | Deployed |
| --- | --- | --- | --- | --- |
| Public site, forms, product catalogue and admin CMS | Yes | Yes | Pending | Production still uses v2 |
| Auth, MFA, recovery, explicit provider linking | Yes | Isolated fixtures | Pending real accounts/providers/email | No |
| Role permissions, RLS, Storage and five migrations | Yes | PostgreSQL/SDK fixtures | Pending actual project/advisors/generated types | No |
| Advanced Auri rules and private draft storage | Yes | Yes | Pending | No |
| Navigation, hero and legal editing with private previews | Yes | Yes | Pending; legal approval also needed | No |
| Media pagination, descriptions, reference protection | Yes | Yes | Pending real Storage | No |
| Optional still-image optimization | Yes | Sizing/validation only | Browser encoding appearance pending | No |
| Design examples, contrast and responsive foundations | Yes | DOM and semantic color checks | Native browser/device/AT/performance pending | No |
| Full data/object migration and rollback | Tooling | Fixtures | Actual backup/rehearsal pending | No |

## What is needed to proceed

1. **Staging Supabase project ID and protected website origin.** The connected account currently exposes only the production project and no branches. The attached plan explicitly requires separate staging before backend operations. If a new paid project/branch is needed, the owner must select its organization so the provider can return a cost quote for approval.
2. **Complete D1 SQL export and R2 inventory plus object bytes**, from provider/operator access, with a designated backup owner. The available table reader cannot produce the required full export or enumerate R2. Search did not find a suitable additional provider integration. The existing backup verifier can restore and validate the supplied backup.
3. Confirm whether the configured Google/GitHub/Microsoft/email/SMTP settings are on production, staging or both. Keep provider buttons hidden until staging round trips pass. An actual email-verified Auth UUID and designated test accounts are needed for owner enrollment, MFA and mail/provider acceptance. Do not share passwords, MFA codes or secret keys in chat.
4. Browser/device acceptance using the required browser capability and real owner-assisted login. DOM fixtures cannot certify native focus, screen readers, virtual keyboards, WebGL failure appearance, image encoding or Lighthouse.
5. Owner legal/content review and written approval naming the exact saved candidate, runtime revision, cutover time and rollback operator. This is the attached plan's final release gate.

Responsive variant delivery is not enabled. Scheduled publishing is visibly unavailable. Install commands remain absent until real reviewed commands exist. These items have not silently been declared an accepted post-launch backlog.

## One domain, two areas

Visitors use `https://aurlabs.online`. Staff use `https://aurlabs.online/admin`. A second purchased domain is not required. After the accepted Supabase cutover, a confirmed admin publication updates database-backed content for subsequent public page requests. Drafts stay private. Changes to source code or layout require a new deployment. Saving this candidate alone does not change the live site.
