# Aur Labs 3.0 — implementation evidence

Updated October 16, 2026 UTC. **Saved implementation candidate, not a completed production 3.0 launch.** The current verified implementation is v5, with 548 local assertions and five Supabase migrations. Earlier v4 references to 471 assertions, four migrations and unfinished advanced editorial controls are historical and superseded here. Production remains v2 with D1/R2.

## Implemented source

- Monochrome light/dark design, self-hosted Geist, responsive foundations, native navigation, URL catalogue state, product galleries, verified release links and safe Markdown.
- Four-step volunteer flow, review, linked validation, explicit 24-hour tab drafts, fresh consent, contextual contact forms and idempotent confirmed submissions.
- Auri opt-in guidance/3D, fallback placement, state machine, advanced target/trigger/locale/priority/route rules, private drafts, FAQ/order/publish controls and deterministic preview.
- Owner navigation/hero/brand/legal editing and private unsaved previews; role-aware CMS, draft autosave, revision restore/conflicts, cursor inbox and live permission checks.
- Supabase Auth/MFA/recovery, explicit provider linking with signed account binding, server session revocation, verified-UUID owner enrollment and five ordered migrations behind an explicit backend flag.
- Private Storage, validated upload, media cursor pagination, description editing, reference-protected deletion and optional still-image optimization.
- Interactive design examples and semantic contrast checks. Backup/restore/import/reconciliation tools preserve identities, consent/tombstones, object hashes and reject production as a staging target.

## Fresh local verification

| Suite | Assertions | Scope |
| --- | --- | --- |
| `tests/integration.mjs` | 94 | D1 authorization, CMS, forms, inbox, media and SSR |
| `tests/client.mjs` | 273 | Happy DOM journeys, filters, drafts, Auri geometry and previews |
| `tests/supabase-schema.mjs` | 89 | Local PostgreSQL schema/RLS, conflicts, recovery and import guards |
| `tests/supabase-http.mjs` | 53 | Actual SDK with isolated fetch fixtures, cookies, roles/MFA and identity linking |
| `tests/migration.mjs` | 10 | Synthetic seven-table restore, count/hash/inventory checks and target rejection |
| `tests/editorial.mjs` | 29 | Rules, safe settings, image sizing and selected semantic contrast pairs |

Total **548**, plus TypeScript, production build and client credential-marker scan passed. Exact timestamps, source/lockfile checksums, command output and limits are in [the baseline audit](../release/baseline-audit.md). Fixtures contain no real applicant data or credentials. Client scanning checks known secret markers; it is not independent provider key-revocation verification.

## Outstanding acceptance

Actual complete D1/R2 backups and restore, protected separate staging, hosted migrations/types/advisors, Auth/SMTP/Storage/RLS round trips, migration/reconciliation/rollback, native browsers/devices/assistive technology, image encoder appearance and measured performance remain unexecuted. Owner content/legal approval and exact launch authorization are absent.

Responsive image variant delivery is disabled; scheduled publication has no scheduler; install commands require real reviewed releases. Their deferral is not accepted by the owner. The optional Three.js chunk remains approximately 132.7 kB gzip and triggers a raw-size warning; this is not a Lighthouse score.

The read-only live HTTP attempt was blocked by Cloudflare 1010, so application health was not established. No production Auth/backend change, remote migration or deployment was performed. See [the release decision](../release/release-go-no-go.md) and [current completion status](completion-status.md).
