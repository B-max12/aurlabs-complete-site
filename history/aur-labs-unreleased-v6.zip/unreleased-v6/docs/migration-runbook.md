# Migration and rollback runbook

The owner confirmed privileged-key rotation in this conversation. Do not request or copy old keys. Store current secrets only through secure operator/hosting configuration. No migration was applied remotely during implementation.

## 1. Obtain an actual complete backup

Export the entire D1 database as SQL, covering `content`, `submissions`, `administrators`, `admin_unlocks`, `rate_limits`, `audit_log`, `media`. Independently enumerate every R2 object and copy its bytes, including orphan objects. Use the provider's export/inventory access; the available Sites table reader and admin JSON export are not sufficient backup mechanisms. Keep exports encrypted and access restricted outside the repository. Legacy credential material stays only in this recovery backup, never in the Supabase import.

Prepare a backup directory with `d1.sql`, object files and `manifest.json`:

```json
{
  "format": "aur-backup-v1",
  "siteId": "appgprj_6acb04e29d2081918548275da19f51e4",
  "sourceCommit": "REPLACE_WITH_EXACT_40_CHARACTER_SEED_COMMIT",
  "exportedAt": "REPLACE_WITH_ACTUAL_ISO_TIMESTAMP",
  "r2InventoryComplete": true,
  "tables": {"content": 0, "submissions": 0, "administrators": 0, "admin_unlocks": 0, "rate_limits": 0, "audit_log": 0, "media": 0},
  "files": [{"path": "d1.sql", "bytes": 0, "sha256": "REPLACE_WITH_SHA256"}],
  "objects": []
}
```

This is a format example, **not an assertion that tables/buckets are empty**. Replace every count/hash/time with measured values. Each object adds a `files` entry and an object entry with `key`, `file`, `mime`, `size`, `sha256`. Keys preserve existing `/api/media/<uuid>.<ext>` URLs. Unsupported orphan files require a documented decision; do not omit them. Keep original provider inventory evidence alongside the manifest. Its completeness marker is an operator attestation, not an independent provider check.

## 2. Verify and review offline

```sh
node scripts/operations/migrate.mjs verify /secure/aur-backup
node scripts/operations/migrate.mjs plan /secure/aur-backup
```

The verifier restores SQL into isolated SQLite, checks all seven counts, integrity, foreign keys, file hashes, safe paths and media inventory. The plan merges the reviewed source seeds/overrides, preserves tombstones, validates content and historical consent, normalizes records and creates deterministic IDs. Review the seed commit: the CLI uses this checkout's current seeds, so reconcile any difference from the manifest's baseline before approval. Missing consent causes a stop; it is never invented.

`import-plan.json` and `id-map.json` are created once with owner-only permissions; existing files are not overwritten. Keep them private with the backup. Never commit a plan containing applicant details. Changed source snapshots require a new reviewed plan/directory. Identity mappings remain deterministic across retries.

## 3. Stage schema and owner

Identify a separate Supabase staging project/branch. Do not use empty production as staging. Review/apply the five SQL migrations using Supabase's supported migration workflow and run security/performance advisors. Generate database types from the applied schema and check repository contracts.

Create a private `target.json` outside source:

```json
{"environment":"staging","projectRef":"YOUR_STAGING_REFERENCE","ownerId":"VERIFIED_AUTH_USER_UUID"}
```

The operator environment supplies `SUPABASE_SECRET_KEY` for that exact staging project. Do not put it in shell command arguments, logs or the target file. Enroll and email-verify the operator through Auth, then:

```sh
node scripts/operations/enroll-owner.mjs /secure/target.json VERIFIED_AUTH_USER_UUID
```

The bootstrap refuses unverified users and any existing active owner. It never imports password hashes or unlocks. Configure SMTP/recovery, MFA and optional providers using `authentication-setup.md`.

## 4. Import and reconcile

```sh
node scripts/operations/migrate.mjs apply-staging /secure/aur-backup /secure/target.json
node scripts/operations/migrate.mjs reconcile /secure/aur-backup /secure/target.json
```

Both commands explicitly reject production reference `opbgjmoztvqjsmxexptv`. Files are uploaded under immutable original keys, re-downloaded and hashed. Records import in bounded per-record transactions with an audit and durable source hash/revision mapping. An interrupted run can be retried. An unchanged record does not create another revision. A changed source conflicts if someone edited its target after import. Changed imported submissions require manual reconciliation; they are not silently overwritten. Full table counts and record/child fields must reconcile.

This is not a single global transaction across Storage and SQL. Partial staging imports remain private and are safely retryable. Do not expose them before reconciliation. Run actual anonymous/staff REST tests, Auth/MFA recovery, published/draft pages, submission retries, role denial and media round trips. Local tests are not this evidence.

## 5. Cutover and rollback

After staging, device/accessibility/performance acceptance, content/legal review and written signoff, record a short write freeze. Export the delta since baseline, review conflicts, apply the approved production migration/import through an operator-controlled process and reconcile. The provided importer intentionally has no production override flag; production execution requires a separately reviewed release operation.

Record the exact saved source version, migrations, runtime env revision, backend flag and cutover time. Deploy that version, verify forms/login/public content, then resume writes. Keep D1/R2 intact and read-only through the acceptance window. Do not use unverified two-way live dual writes.

Rollback begins with another write freeze. Export every Supabase write since cutover and reconcile it into D1/R2 while preserving submission UUIDs/references, content and object URLs. Then restore baseline version 2 (`4847db8e2e23a9acb1083b4c60b3d272514265d4`) and the original D1/R2/Auth runtime configuration. Test login, forms and public content before resuming. A source-only rollback would lose post-cutover submissions and is unacceptable. Rehearse this against staging before launch.

## Candidate 5 reconciliation output

The fifth migration extracts Auri rules and unpublished FAQ data from public settings JSON. Reconciliation reconstructs the logical settings from the protected normalized rows before comparing them to the import plan. It checks remote object byte lengths and SHA-256 values, including when invoked separately with `reconcile`, and writes `reconciliation-<timestamp>.json` in the private backup directory with mode 0600. The success report contains table counts, checked record/object totals and zero unexplained differences. On a mismatch the command stops without a success report. A successful report does not certify Auth, RLS, SMTP, device QA or production acceptance.
