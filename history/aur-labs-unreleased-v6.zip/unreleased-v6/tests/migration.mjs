import assert from 'node:assert/strict';
import {mkdtempSync,readFileSync,writeFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {verifyBackup,sha,siteId,tables} from '../scripts/operations/backup.mjs';
import {buildImport,stagingClient} from '../scripts/operations/migrate.mjs';
const root=mkdtempSync(join(tmpdir(),'aur-restore-fixture-'));let checks=0;
const ok=(x,m)=>{assert.ok(x,m);checks++};
try{
 const sql=readFileSync(new URL('../drizzle/0000_huge_azazel.sql',import.meta.url),'utf8')+"\nINSERT INTO content(id,kind,data,published,deleted,updated_at) VALUES ('aur-notes','products','{}',0,1,1);";
 writeFileSync(join(root,'d1.sql'),sql,{mode:0o600});
 const manifest={format:'aur-backup-v1',siteId,sourceCommit:'a'.repeat(40),exportedAt:'2026-10-14T12:00:00Z',r2InventoryComplete:true,tables:Object.fromEntries(tables.map(t=>[t,t==='content'?1:0])),files:[{path:'d1.sql',sha256:sha(sql),bytes:Buffer.byteLength(sql)}],objects:[]};
 const save=()=>writeFileSync(join(root,'manifest.json'),JSON.stringify(manifest),{mode:0o600});save();
 ok(verifyBackup(root).report.sqliteRestore==='passed','Full seven-table fixture restores');
 const a=await buildImport(root),b=await buildImport(root);assert.deepEqual(a.records,b.records);checks++;
 ok(a.records.some(r=>r.legacy==='aur-notes'&&r.deleted),'Deleted seed remains a tombstone');
 ok(!a.records.some(r=>r.kind==='administrators'||r.kind==='admin_unlocks'),'Credentials and sessions never migrate');
 ok(a.records.some(r=>r.kind==='team'),'Team IDs receive durable mapping');
 manifest.tables.submissions=1;save();assert.throws(()=>verifyBackup(root));checks++;manifest.tables.submissions=0;
 manifest.files[0].sha256='0'.repeat(64);save();assert.throws(()=>verifyBackup(root));checks++;manifest.files[0].sha256=sha(sql);
 manifest.r2InventoryComplete=false;save();assert.throws(()=>verifyBackup(root));checks++;manifest.r2InventoryComplete=true;
 manifest.files.push({path:'../outside',sha256:'',bytes:0});save();assert.throws(()=>verifyBackup(root));checks++;
 writeFileSync(join(root,'target.json'),JSON.stringify({environment:'staging',projectRef:'opbgjmoztvqjsmxexptv'}));assert.throws(()=>stagingClient(join(root,'target.json')));checks++;
 console.log(`PASS: ${checks} migration/restore tooling assertions. Fixtures are not a production backup.`);
}finally{rmSync(root,{recursive:true,force:true})}
