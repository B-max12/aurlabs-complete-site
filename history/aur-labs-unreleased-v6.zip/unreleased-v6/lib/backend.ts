import {env} from 'cloudflare:workers';
export const runtime=()=>env as unknown as Record<string,string|undefined>;
export function supabaseEnabled(){const value=runtime().AUR_BACKEND||'d1';if(!['d1','supabase'].includes(value))throw new Error('Unknown storage backend');return value==='supabase'}
export function supabaseConfig(privileged=false){
 const e=runtime(),url=e.SUPABASE_URL||e.NEXT_PUBLIC_SUPABASE_URL||'',publishable=e.SUPABASE_PUBLISHABLE_KEY||e.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY||'';
 if(!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(url)||!publishable.startsWith('sb_publishable_'))throw new Error('Supabase runtime configuration is incomplete');
 const key=privileged?e.SUPABASE_SECRET_KEY:publishable;
 if(!key||(privileged&&!key.startsWith('sb_secret_')))throw new Error('Supabase server credential is not configured');
 return {url,key,publishable,requireMfa:e.AUR_REQUIRE_MFA!=='false'};
}

export const authProviders={google:'Google',github:'GitHub',apple:'Apple',azure:'Microsoft',gitlab:'GitLab','custom:vercel':'Vercel'} as const;
export function enabledProviders(){return (runtime().AUR_OAUTH_PROVIDERS||'').split(',').map(x=>x.trim()).filter((x):x is keyof typeof authProviders=>Object.hasOwn(authProviders,x))}
