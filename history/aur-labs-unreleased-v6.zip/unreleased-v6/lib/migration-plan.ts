import {defaultContent,type ContentKind,type SiteContent} from './content';
import {productSchema,articleSchema,teamSchema,settingsSchema} from './validation';

export type LegacyRow={id:string;kind:ContentKind;data:string;published:number;deleted:number;updated_at:string|number};
export type LegacyMedia={id:string;name:string;mime:string;size:number;created_at:string|number};
export type LegacySubmission={id:string;kind:'join'|'contact';name:string;email:string;data:string;status:string;created_at:string|number};
export type MigrationSnapshot={format:'aur-d1-backup-v1';projectId:string;complete:true;exportedAt:string;counts:{content:number;media:number;submissions:number};content:LegacyRow[];media:LegacyMedia[];submissions:LegacySubmission[]};
const schemas={products:productSchema,journal:articleSchema,research:articleSchema,team:teamSchema,settings:settingsSchema};
const projectId='appgprj_6acb04e29d2081918548275da19f51e4';
const unique=(ids:string[],label:string)=>{if(new Set(ids).size!==ids.length)throw new Error(`Duplicate ${label} in snapshot`)};
/** An offline preflight, not an importer or evidence that a backup restores. */
export function prepareMigrationPlan(snapshot:MigrationSnapshot,seeds:SiteContent=defaultContent){
 if(snapshot.format!=='aur-d1-backup-v1'||snapshot.projectId!==projectId||snapshot.complete!==true)throw new Error('A complete backup of the expected Site is required');
 if(!Number.isFinite(Date.parse(snapshot.exportedAt)))throw new Error('Backup timestamp is invalid');
 for(const key of ['content','media','submissions'] as const){if(!Array.isArray(snapshot[key])||snapshot.counts[key]!==snapshot[key].length)throw new Error(`Incomplete ${key} export`);unique(snapshot[key].map(r=>r.id),`${key} IDs`)}
 const content=structuredClone(seeds),tombstones:{kind:ContentKind;id:string}[]=[];
 for(const row of snapshot.content){
  if(!row.id||![0,1].includes(row.published)||![0,1].includes(row.deleted))throw new Error('Invalid legacy record flags or ID');
  if(!Object.hasOwn(schemas,row.kind))throw new Error('Unknown content kind');
  if(row.deleted){tombstones.push({kind:row.kind,id:row.id});if(row.kind==='settings')throw new Error('Deleted settings require manual reconciliation');content[row.kind]=content[row.kind].filter(r=>r.id!==row.id) as never;continue}
  const raw=JSON.parse(row.data);if(row.kind!=='settings'&&raw.id!==row.id)throw new Error('Content row ID does not match its payload');
  const data=schemas[row.kind].parse(row.kind==='settings'?raw:{...raw,published:!!row.published});
  if(row.kind==='settings')content.settings=data as SiteContent['settings'];
  else{const list=content[row.kind] as {id:string}[];const index=list.findIndex(r=>r.id===row.id);if(index<0)list.push(data as {id:string});else list[index]=data as {id:string}}
 }
 for(const kind of ['products','journal','research'] as const)unique(content[kind].map(r=>r.slug),`${kind} slugs`);
 for(const m of snapshot.media){if(!/^[a-zA-Z0-9._-]+$/.test(m.id)||!['image/png','image/jpeg','image/webp','image/gif'].includes(m.mime)||!Number.isSafeInteger(m.size)||m.size<1||m.size>5242880)throw new Error('Invalid legacy media metadata')}
 const mediaIds=new Set(snapshot.media.map(m=>m.id));const assetReferences=new Map<string,string[]>();
 const reference=(url:string,record:string)=>{if(!url.startsWith('/api/media/'))return;const id=url.slice('/api/media/'.length);if(!mediaIds.has(id))throw new Error(`Missing media metadata for ${record}`);assetReferences.set(id,[...(assetReferences.get(id)||[]),record])};
 for(const product of content.products){product.screenshots.forEach(url=>reference(url,'product:'+product.id));unique(product.releases.map(r=>[r.platform,r.architecture,r.version].join('|')),'product release variants')}
 for(const article of [...content.journal,...content.research])reference(article.cover,'article:'+article.id);
 for(const member of content.team)reference(member.image,'team:'+member.id);
 for(const row of snapshot.submissions){if(!['join','contact'].includes(row.kind)||!['new','reviewing','replied','archived'].includes(row.status))throw new Error('Unknown submission kind or status');if(!/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(row.id))throw new Error('Submission ID must be preserved as a UUID');const data=JSON.parse(row.data);if(!data||typeof data!=='object'||Array.isArray(data))throw new Error('Submission payload is invalid')}
 return {
  destination:{projectRef:'opbgjmoztvqjsmxexptv',region:'ap-southeast-1'},
  content,tombstones,
  media:snapshot.media.map(m=>({...m,source:'/api/media/'+m.id,referencedBy:assetReferences.get(m.id)||[],copyVerified:false})),
  submissionCounts:{applications:snapshot.submissions.filter(r=>r.kind==='join').length,contacts:snapshot.submissions.filter(r=>r.kind==='contact').length},
  mapping:content.products.flatMap(p=>[{kind:'products',legacyId:p.id,slug:p.slug}]).concat((['journal','research'] as const).flatMap(kind=>content[kind].map(a=>({kind,legacyId:a.id,slug:a.slug})))),
  blockers:['Restore-test a complete database and R2 backup','Enroll and verify the Supabase owner explicitly','Apply and test schema/RLS in staging','Copy and verify every R2 object, including orphan inventory','Reconcile counts, IDs, slugs, tombstones and foreign keys','Verify staging browser journeys and obtain written launch signoff'],
 };
}
