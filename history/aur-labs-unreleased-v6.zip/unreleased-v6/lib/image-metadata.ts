/** Read bounded raster headers; never execute SVG or decode an unbounded bitmap. */
export function imageMetadata(b:Uint8Array){
 const v=new DataView(b.buffer,b.byteOffset,b.byteLength),ascii=(at:number,n:number)=>String.fromCharCode(...b.slice(at,at+n));
 let width=0,height=0,mime='',ext='';
 if(b.length>=24&&[137,80,78,71,13,10,26,10].every((x,i)=>b[i]===x)&&ascii(12,4)==='IHDR'){width=v.getUint32(16);height=v.getUint32(20);mime='image/png';ext='png'}
 else if(b.length>=10&&['GIF87a','GIF89a'].includes(ascii(0,6))){width=v.getUint16(6,true);height=v.getUint16(8,true);mime='image/gif';ext='gif'}
 else if(b.length>=30&&ascii(0,4)==='RIFF'&&ascii(8,4)==='WEBP'){
  mime='image/webp';ext='webp';const type=ascii(12,4);
  if(type==='VP8X'){width=1+b[24]+(b[25]<<8)+(b[26]<<16);height=1+b[27]+(b[28]<<8)+(b[29]<<16)}
  else if(type==='VP8L'&&b[20]===0x2f){width=1+b[21]+((b[22]&63)<<8);height=1+(b[22]>>6)+(b[23]<<2)+((b[24]&15)<<10)}
  else if(type==='VP8 '&&b[23]===0x9d&&b[24]===1&&b[25]===0x2a){width=v.getUint16(26,true)&0x3fff;height=v.getUint16(28,true)&0x3fff}
 }else if(b.length>10&&b[0]===255&&b[1]===216){
  mime='image/jpeg';ext='jpg';let offset=2;
  while(offset+4<b.length){if(b[offset]!==255)break;const marker=b[offset+1];if(marker===0xda||marker===0xd9)break;const size=v.getUint16(offset+2);if(size<2||offset+size+2>b.length)break;if([0xc0,0xc1,0xc2,0xc3,0xc5,0xc6,0xc7,0xc9,0xca,0xcb,0xcd,0xce,0xcf].includes(marker)&&size>=8){height=v.getUint16(offset+5);width=v.getUint16(offset+7);break}offset+=size+2}
 }
 if(!mime||width<1||height<1||width>12000||height>12000||width*height>40000000)throw new Error('Use a valid PNG, JPEG, WebP or GIF under 12,000 pixels per side and 40 megapixels.');
 return {mime,ext,width,height};
}
