import {guideFor} from './auri-guides';
export const AURI_TRIGGERS=['focus','hover','manual','error'] as const;
export type AuriTrigger=typeof AURI_TRIGGERS[number];
export type AuriRule={id:string;target:string;text:string;trigger:AuriTrigger;locale:string;priority:number;route:string;published:boolean};
/** Exact paths or a terminal /* only. No executable expressions or selectors. */
export function routeMatches(pattern:string,path:string){return pattern==='/*'||(pattern.endsWith('/*')?(path===pattern.slice(0,-2)||path.startsWith(pattern.slice(0,-1))):path===pattern)}
export function resolveGuide(target:string,trigger:AuriTrigger,path:string,locale:string,rules:AuriRule[]=[],overrides:Record<string,string>={}){
 const language=locale.toLowerCase();
 const matches=rules.filter(r=>r.published&&r.target===target&&r.trigger===trigger&&routeMatches(r.route,path)&&(r.locale==='*'||language===r.locale.toLowerCase()||language.startsWith(r.locale.toLowerCase()+'-')));
 matches.sort((a,b)=>b.priority-a.priority||Number(b.locale!=='*')-Number(a.locale!=='*')||b.route.length-a.route.length||a.id.localeCompare(b.id));
 return matches[0]?.text||guideFor(target,overrides);
}
