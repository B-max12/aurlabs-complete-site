// Server-only: imported only by server routes and repositories. No credentials enter a Client Component.
import {createClient,type SupabaseClient} from '@supabase/supabase-js';
import {createServerClient,parseCookieHeader,serializeCookieHeader} from '@supabase/ssr';
import {supabaseConfig} from '../backend';
import {may,type AdminRole,type Permission} from '../access-contract';
export class ServiceError extends Error{constructor(message:string,public status=500,public code='REQUEST_FAILED'){super(message)}}
export function checked<R extends {data?:unknown;error:{code?:string;message?:string}|null}>({data,error}:R):NonNullable<R['data']>{
 if(error){const code=error.code||'';throw new ServiceError(code==='A0409'?'This record changed. Refresh before saving.':code==='A0429'?'Too many requests. Please try again later.':code==='A0403'?'This action is not permitted.':code==='23505'?'That identifier or URL slug is already in use.':'The server could not complete this operation.',code==='A0409'||code==='23505'?409:code==='A0429'?429:code==='A0403'?403:500,code)}
 return data as NonNullable<R['data']>;
}
const network={fetch:(input:RequestInfo|URL,init?:RequestInit)=>fetch(input,{...init,signal:init?.signal||AbortSignal.timeout(15000)})};
export function publicClient(){const c=supabaseConfig();return createClient(c.url,c.publishable,{auth:{persistSession:false,autoRefreshToken:false},global:network})}
export function serviceClient(){const c=supabaseConfig(true);return createClient(c.url,c.key,{auth:{persistSession:false,autoRefreshToken:false},global:network})}
export function requestClient(req:Request){
 const c=supabaseConfig(),headers=new Headers({'Cache-Control':'private, no-store, max-age=0','Pragma':'no-cache','Expires':'0','Vary':'Cookie'});
 const jar=new Map(parseCookieHeader(req.headers.get('cookie')||'').map(c=>[c.name,c.value]));
 const client=createServerClient(c.url,c.publishable,{global:network,cookieOptions:{httpOnly:true,secure:true,sameSite:'lax',path:'/'},cookies:{getAll:()=>[...jar].map(([name,value])=>({name,value})),setAll:(cookies,cache)=>{for(const cookie of cookies){jar.set(cookie.name,cookie.value);headers.append('Set-Cookie',serializeCookieHeader(cookie.name,cookie.value,{...cookie.options,httpOnly:true,secure:true,sameSite:'lax',path:'/'}))}for(const [key,value] of Object.entries(cache||{}))headers.set(key,String(value))}}});
 const respond=(body:unknown,status=200)=>{headers.set('Content-Type','application/json');headers.set('X-Content-Type-Options','nosniff');return new Response(JSON.stringify(body),{status,headers})};
 return {client,headers,respond};
}
export async function staff(client:SupabaseClient,permission?:Permission,allowMfaSetup=false){
 const {data,error}=await client.auth.getUser();if(error||!data.user)throw new ServiceError('Sign in to continue.',401,'SIGN_IN_REQUIRED');
 const roleRow=checked(await client.from('admin_roles').select('role,enabled').eq('user_id',data.user.id).maybeSingle());
 if(!roleRow?.enabled||!['owner','admin','editor','inbox_reviewer'].includes(roleRow.role))throw new ServiceError('This account has no active studio access.',403,'ACCESS_DENIED');
 const role=roleRow.role as AdminRole;
 const claims=checked(await client.auth.getClaims());const sessionId=claims.claims.session_id,issuedAt=claims.claims.iat;
 if(typeof sessionId!=='string'||typeof issuedAt!=='number'||!checked(await serviceClient().rpc('session_allowed',{p_actor:data.user.id,p_session:sessionId,p_iat:issuedAt})))throw new ServiceError('This session was revoked. Sign in again.',401,'SIGN_IN_REQUIRED');
 if(permission&&!may(role,permission))throw new ServiceError('Your role cannot perform this action.',403,'ACCESS_DENIED');
 if(supabaseConfig().requireMfa&&!allowMfaSetup){const assurance=checked(await client.auth.mfa.getAuthenticatorAssuranceLevel());if(assurance.currentLevel!=='aal2')throw new ServiceError('Verify your authenticator code to continue.',403,'MFA_REQUIRED')}
 return {id:data.user.id,email:data.user.email||'',role};
}
