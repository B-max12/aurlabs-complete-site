import {supabaseConfig} from '../backend';
const encoder=new TextEncoder();
export const LINK_COOKIE='__Host-aur-link';
const hex=(bytes:ArrayBuffer)=>Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('');
async function key(){return crypto.subtle.importKey('raw',encoder.encode(supabaseConfig(true).key),{name:'HMAC',hash:'SHA-256'},false,['sign','verify'])}
export async function linkState(userId:string){const payload=btoa(JSON.stringify({id:userId,until:Date.now()+600000}));return payload+'.'+hex(await crypto.subtle.sign('HMAC',await key(),encoder.encode('aur-link:'+payload)))}
export async function verifyLinkState(value:string){const [payload,mac,...rest]=value.split('.');if(rest.length||!payload||!/^[a-f0-9]{64}$/.test(mac||''))throw new Error('Invalid link state');const signature=Uint8Array.from(mac.match(/../g)!,b=>parseInt(b,16));if(!await crypto.subtle.verify('HMAC',await key(),signature,encoder.encode('aur-link:'+payload)))throw new Error('Invalid link state');const state=JSON.parse(atob(payload));if(typeof state.id!=='string'||typeof state.until!=='number'||state.until<Date.now())throw new Error('Expired link state');return state.id as string}
export function linkCookie(value='',age=0){return `${LINK_COOKIE}=${value}; Path=/; Max-Age=${age}; HttpOnly; Secure; SameSite=Lax`}
