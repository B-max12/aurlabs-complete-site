import {z} from 'zod';
import {linkState,linkCookie} from './link-state';
import {supabaseConfig,runtime,enabledProviders,authProviders} from '../backend';
import {requestClient,serviceClient,staff,checked,ServiceError,publicClient} from './client';
import {readSupabaseContent,toRow,fromRow,type Row} from './content';
import {productSchema,articleSchema,teamSchema,settingsSchema} from '../validation';
import {sameOrigin,parseBody,sha} from '../server';
import {may,permissions,type AdminRole} from '../access-contract';
import type {ContentKind} from '../content';
const uuid=z.string().uuid(),schemas={products:productSchema,journal:articleSchema,research:articleSchema,team:teamSchema,settings:settingsSchema};
const kind=(value:unknown)=>z.enum(['products','journal','research','team','settings']).parse(value);
const cursorSchema=z.object({time:z.string().datetime({offset:true}),id:z.string().uuid()});
function decodeCursor(value:string|null){if(!value)return null;try{return cursorSchema.parse(JSON.parse(atob(value)))}catch{throw new ServiceError('Invalid page cursor.',400)}}
function encodeCursor(row:Row){return btoa(JSON.stringify({time:row.created_at,id:row.id}))}
async function inbox(actor:string,url:URL){
 const before=decodeCursor(url.searchParams.get('cursor'));
 const type=z.enum(['all','join','contact']).parse(url.searchParams.get('kind')||'all');
 const status=z.enum(['all','new','reviewing','replied','archived']).parse(url.searchParams.get('status')||'all');
 const rows=checked(await serviceClient().rpc('inbox_page',{p_actor:actor,p_kind:type,p_status:status,p_query:(url.searchParams.get('q')||'').slice(0,120),p_before_time:before?.time||null,p_before_id:before?.id||null,p_limit:26})) as Row[];
 return {items:rows.slice(0,25),nextCursor:rows.length>25?encodeCursor(rows[24]):null};
}
async function mediaPage(url:URL){
 const before=decodeCursor(url.searchParams.get('cursor'));
 let q=serviceClient().from('media_assets').select('*').order('created_at',{ascending:false}).order('id',{ascending:false}).limit(25);
 if(before)q=q.or(`created_at.lt.${before.time},and(created_at.eq.${before.time},id.lt.${before.id})`);
 const rows=checked(await q) as Row[];
 return {items:rows.slice(0,24).map(a=>({...a,name:a.original_name,size:a.size_bytes,url:'/api/media/'+a.object_path})),nextCursor:rows.length>24?encodeCursor(rows[23]):null};
}
function errorResponse(error:unknown,respond:(b:unknown,s?:number)=>Response){return error instanceof z.ZodError?respond({error:error.issues.map(i=>i.path.join('.')+': '+i.message).join(' · ')},400):error instanceof ServiceError?respond({error:error.message,code:error.code},error.status):respond({error:'The service is temporarily unavailable. Please try again.'},503)}
async function throttle(req:Request,subject:string){const ip=req.headers.get('cf-connecting-ip')||'unknown';const allowed=checked(await serviceClient().rpc('consume_rate_limit',{p_key:await sha('auth:'+ip+':'+subject),p_limit:10,p_window_seconds:900}));if(!allowed)throw new ServiceError('Too many sign-in attempts. Please wait 15 minutes.',429)}
export async function supabaseAdminGet(req:Request){
 let session:ReturnType<typeof requestClient>;try{session=requestClient(req)}catch{return Response.json({error:'Supabase is not configured.'},{status:503,headers:{'Cache-Control':'no-store'}})}
 const {client,respond,headers}=session;
 try{
  const url=new URL(req.url),view=url.searchParams.get('view');
  if(view==='status'){
   const {data}=await client.auth.getUser();let account;try{account=await staff(client,undefined,true)}catch{}
   const factors=account?checked(await client.auth.mfa.listFactors()):null;const assurance=account?checked(await client.auth.mfa.getAuthenticatorAssuranceLevel()):null;
   return respond({providers:enabledProviders().map(id=>({id,label:authProviders[id]})),mfaRequired:!!account&&supabaseConfig().requireMfa&&assurance?.currentLevel!=='aal2',mfaFactorId:factors?.totp.find(f=>f.status==='verified')?.id||null,backend:'supabase',signedIn:!!data.user,configured:true,canSetup:false,isOwner:account?.role==='owner',authorized:!!account,role:account?.role||null});
  }
  const actor=await staff(client),server=serviceClient();
  if(view==='media'){if(!may(actor.role,'content:read'))throw new ServiceError('Media access is not permitted.',403);return respond(await mediaPage(url))}
  if(view==='identities'){const result=checked(await client.auth.getUserIdentities());return respond({items:result.identities.map(i=>({provider:i.provider})),providers:enabledProviders().map(id=>({id,label:authProviders[id]}))})}
  if(view==='inbox'){if(!may(actor.role,'inbox:read'))throw new ServiceError('Inbox access is not permitted.',403);return respond(await inbox(actor.id,url))}
  if(view==='revisions'){
   if(!may(actor.role,'content:read'))throw new ServiceError('Content access is not permitted.',403);
   return respond({items:checked(await server.from('content_revisions').select('id,revision,created_at,kind,record_id').eq('kind',kind(url.searchParams.get('kind'))).eq('record_id',uuid.parse(url.searchParams.get('id'))).order('revision',{ascending:false}).limit(30))});
  }
  if(view==='media-references'){if(!may(actor.role,'content:read'))throw new ServiceError('Media access is not permitted.',403);return respond({items:checked(await server.rpc('media_references',{p_id:uuid.parse(url.searchParams.get('id'))}))})}
  if(view==='roles'){if(actor.role!=='owner')throw new ServiceError('Only an owner can manage roles.',403);return respond({items:checked(await server.from('admin_roles').select('user_id,role,enabled,created_at').order('created_at').limit(100))})}
  if(view==='mfa'){const factors=checked(await client.auth.mfa.listFactors());return respond({items:factors.totp.map(f=>({id:f.id,name:f.friendly_name,status:f.status}))})}
  const edit=may(actor.role,'content:read'),review=may(actor.role,'inbox:read');
  const [content,messages,assets,events,counts]=await Promise.all([
   readSupabaseContent(edit?client:publicClient(),edit),review?inbox(actor.id,new URL(req.url)):Promise.resolve({items:[],nextCursor:null}),
   edit?server.from('media_assets').select('*').order('created_at',{ascending:false}).limit(24).then(checked):Promise.resolve([]),
   may(actor.role,'audit:read')?server.from('audit_logs').select('action,target_type,target_id,created_at').order('created_at',{ascending:false}).limit(50).then(checked):Promise.resolve([]),
   review?Promise.all(['volunteer_applications','contact_messages'].map(async table=>{const result=await server.from(table).select('id',{head:true,count:'exact'}).eq('status','new');checked(result);return result.count||0})):Promise.resolve([0,0])
  ]);
  return respond({stats:{newMessages:counts.reduce((a,b)=>a+b,0)},backend:'supabase',content,inbox:messages.items,inboxCursor:messages.nextCursor,assets:assets.map((a:Row)=>({...a,name:a.original_name,size:a.size_bytes,url:'/api/media/'+a.object_path})),events:events.map((e:Row)=>({...e,target:e.target_type+':'+e.target_id})),username:actor.email,role:actor.role,permissions:permissions[actor.role]});
 }catch(error){return errorResponse(error,respond)}
}
export async function supabaseAdminPost(req:Request){
 if(!sameOrigin(req))return Response.json({error:'This action must come from the website.'},{status:403});
 let session:ReturnType<typeof requestClient>;try{session=requestClient(req)}catch{return Response.json({error:'Supabase is not configured.'},{status:503})}
 const {client,respond,headers}=session;
 try{
  const b=await parseBody(req),server=serviceClient();
  if(b.action==='oauth'){
   headers.append('Set-Cookie',linkCookie());
   const provider=z.enum(['google','github','apple','azure','gitlab','custom:vercel']).parse(b.provider);
   if(!enabledProviders().includes(provider))throw new ServiceError('This sign-in provider is not configured.',400);
   const origin=runtime().AUR_PUBLIC_URL;if(!origin||origin!==new URL(req.url).origin)throw new ServiceError('Sign-in callback is not configured.',503);
   await throttle(req,'oauth');const data=checked(await client.auth.signInWithOAuth({provider,options:{redirectTo:origin+'/api/auth/callback',skipBrowserRedirect:true,scopes:provider==='azure'?'email':undefined}}));return respond({url:data.url});
  }
  if(b.action==='recovery-request'){

   const email=z.string().email().max(254).parse(b.email).toLowerCase();await throttle(req,'recovery:'+email);
   const origin=runtime().AUR_PUBLIC_URL;if(!origin||new URL(origin).origin!==new URL(req.url).origin)throw new ServiceError('Password recovery is not configured for this website.',503);
   const result=await client.auth.resetPasswordForEmail(email,{redirectTo:origin+'/admin/recover'});
   if(result.error)throw new ServiceError('The email service is unavailable. Please try later.',503);
   return respond({ok:true,message:'If this email has an account, a recovery link will arrive shortly.'});
  }
  if(b.action==='recovery-verify'){
   await throttle(req,'recovery-verify');
   const token_hash=z.string().regex(/^[a-fA-F0-9]{32,128}$/).parse(b.tokenHash);
   const result=await client.auth.verifyOtp({token_hash,type:'recovery'});if(result.error)throw new ServiceError('This recovery link expired or was already used. Request another.',400);
   const actor=await staff(client,undefined,true),claims=checked(await client.auth.getClaims());
   checked(await server.rpc('recovery_ticket',{p_actor:actor.id,p_session:claims.claims.session_id,p_consume:false}));
   const factors=checked(await client.auth.mfa.listFactors());
   return respond({ok:true,requiresMfa:supabaseConfig().requireMfa,factorId:factors.totp.find(f=>f.status==='verified')?.id||null});
  }
  if(b.action==='unlock'){
   const email=z.string().email().max(254).parse(b.username),password=z.string().min(1).max(128).parse(b.password);await throttle(req,email.toLowerCase());
   const login=await client.auth.signInWithPassword({email,password});if(login.error)throw new ServiceError('The email or password is incorrect.',403);
   try{const actor=await staff(client);return respond({ok:true,authenticated:true,role:actor.role})}catch(error){if(error instanceof ServiceError&&error.code==='MFA_REQUIRED'){const factors=checked(await client.auth.mfa.listFactors());return respond({requiresMfa:true,factorId:factors.totp.find(f=>f.status==='verified')?.id||null})}await client.auth.signOut({scope:'local'});throw error}
  }
  if(b.action==='mfa-verify'){
   await staff(client,undefined,true);await throttle(req,'mfa');
   checked(await client.auth.mfa.challengeAndVerify({factorId:uuid.parse(b.factorId),code:z.string().regex(/^\d{6}$/).parse(b.code)}));
   const actor=await staff(client);return respond({ok:true,authenticated:true,role:actor.role});
  }
  if(b.action==='lock'){
   try{const account=await staff(client,undefined,true),claims=checked(await client.auth.getClaims());checked(await server.rpc('revoke_session',{p_actor:account.id,p_session:claims.claims.session_id,p_all:false}))}catch(error){if(!(error instanceof ServiceError)||![401,403].includes(error.status))throw error}
   checked(await client.auth.signOut({scope:'local'}));return respond({ok:true});
  }
  const mfaSetup=['mfa-enroll','mfa-activate','lock'].includes(b.action);
  const actor=await staff(client,undefined,mfaSetup);
  if(b.action==='link-identity'){
   const provider=z.enum(['google','github','apple','azure','gitlab','custom:vercel']).parse(b.provider);
   if(!enabledProviders().includes(provider))throw new ServiceError('This sign-in provider is not configured.',400);
   const origin=runtime().AUR_PUBLIC_URL;if(!origin||origin!==new URL(req.url).origin)throw new ServiceError('Sign-in callback is not configured.',503);
   await throttle(req,'link:'+actor.id);
   const linked=checked(await client.auth.linkIdentity({provider,options:{redirectTo:origin+'/api/auth/callback',skipBrowserRedirect:true,scopes:provider==='azure'?'email':undefined}}));
   headers.append('Set-Cookie',linkCookie(await linkState(actor.id),600));return respond({url:linked.url});
  }
  if(b.action==='mfa-enroll'){const existing=checked(await client.auth.mfa.listFactors());for(const f of existing.all.filter(f=>f.factor_type==='totp'&&f.status==='unverified'))checked(await client.auth.mfa.unenroll({factorId:f.id}));const factor=checked(await client.auth.mfa.enroll({factorType:'totp',friendlyName:'Aur Labs studio'}));return respond({id:factor.id,qr:factor.totp.qr_code,secret:factor.totp.secret})}
  if(b.action==='mfa-activate'){checked(await client.auth.mfa.challengeAndVerify({factorId:uuid.parse(b.factorId),code:z.string().regex(/^\d{6}$/).parse(b.code)}));return respond({ok:true})}
  if(b.action==='mfa-remove'){const factors=checked(await client.auth.mfa.listFactors());if(supabaseConfig().requireMfa&&factors.totp.filter(f=>f.status==='verified'&&f.id!==b.factorId).length===0)throw new ServiceError('Add and verify another authenticator before removing this one.',400);checked(await client.auth.mfa.unenroll({factorId:uuid.parse(b.factorId)}));return respond({ok:true})}
  if(b.action==='recovery-reset'){
   const password=z.string().min(12).max(128).parse(b.password),claims=checked(await client.auth.getClaims());
   if(!checked(await server.rpc('recovery_ticket',{p_actor:actor.id,p_session:claims.claims.session_id,p_consume:true})))throw new ServiceError('Verify a fresh recovery email before resetting your password.',403);
   checked(await client.auth.updateUser({password}));checked(await server.rpc('revoke_session',{p_actor:actor.id,p_session:null,p_all:true}));checked(await client.auth.signOut({scope:'global'}));return respond({ok:true});
  }
  if(b.action==='password'){
   const password=z.string().min(12).max(128).parse(b.password),currentPassword=z.string().max(128).parse(b.currentPassword);
   await throttle(req,actor.id);const verifier=publicClient();const login=await verifier.auth.signInWithPassword({email:actor.email,password:currentPassword});if(login.error||login.data.user?.id!==actor.id)throw new ServiceError('Your current password is incorrect.',403);await verifier.auth.signOut({scope:'local'});
   checked(await client.auth.updateUser({password}));checked(await server.rpc('revoke_session',{p_actor:actor.id,p_session:null,p_all:true}));checked(await client.auth.signOut({scope:'global'}));return respond({ok:true,reauthenticate:true});
  }
  if(b.action==='auri-save'){
   if(!may(actor.role,'content:write'))throw new ServiceError('Your role cannot edit Auri.',403);
   const data=settingsSchema.parse(b.data),p_data={auriEnabled:data.auriEnabled,auriPages:data.auriPages,auriGuides:data.auriGuides,auriFaqs:data.auriFaqs,auriRules:data.auriRules};
   const saved=checked(await server.rpc('auri_save',{p_actor:actor.id,p_id:uuid.parse(b.data._id),p_data,p_expected:z.number().int().min(1).parse(b.data._version)}));return respond({ok:true,...saved});
  }
  if(b.action==='save'){
   const k=kind(b.kind);if(!may(actor.role,k==='settings'?'settings:write':'content:write'))throw new ServiceError('Your role cannot edit this content.',403);
   const data=schemas[k].parse(b.data) as Row,id=k==='settings'?uuid.parse(b.data._id):uuid.parse(data.id),expected=z.number().int().min(0).parse(b.data._version??0);
   const record=await toRow(server,k,data,id);
   const saved=checked(await server.rpc('cms_save',{p_actor:actor.id,p_kind:k,p_record:record.row,p_releases:record.releases,p_media:record.media,p_expected:expected}));return respond({ok:true,...saved});
  }
  if(b.action==='restore'){
   const k=kind(b.kind);if(!may(actor.role,k==='settings'?'settings:write':'content:write'))throw new ServiceError('Your role cannot restore this content.',403);
   const old=checked(await server.from('content_revisions').select('*').eq('id',uuid.parse(b.revisionId)).eq('kind',k).eq('record_id',uuid.parse(b.id)).single());
   const snapshot=old.snapshot;checked(await server.rpc('cms_save',{p_actor:actor.id,p_kind:k,p_record:snapshot.row,p_releases:snapshot.releases||[],p_media:snapshot.media||[],p_expected:z.number().int().min(1).parse(b.expectedVersion)}));return respond({ok:true});
  }
  if(b.action==='delete'){if(!may(actor.role,'content:write'))throw new ServiceError('Your role cannot delete content.',403);checked(await server.rpc('cms_delete',{p_actor:actor.id,p_kind:kind(b.kind),p_id:uuid.parse(b.id),p_expected:z.number().int().min(1).parse(b.expectedVersion)}));return respond({ok:true})}
  if(b.action==='submission'){if(!may(actor.role,b.status==='delete'?'inbox:delete':'inbox:update'))throw new ServiceError('Your role cannot change this submission.',403);checked(await server.rpc('inbox_action',{p_actor:actor.id,p_kind:z.enum(['join','contact']).parse(b.kind),p_id:uuid.parse(b.id),p_status:z.enum(['new','reviewing','replied','archived','delete']).parse(b.status)}));return respond({ok:true})}
  if(b.action==='role'){if(actor.role!=='owner')throw new ServiceError('Only an owner can manage roles.',403);const target=checked(await server.auth.admin.getUserById(uuid.parse(b.userId)));if(!target.user?.email_confirmed_at)throw new ServiceError('Verify this account’s email before granting access.',400);if(actor.role!=='owner')throw new ServiceError('Only an owner can manage roles.',403);checked(await server.rpc('set_admin_role',{p_actor:actor.id,p_user:uuid.parse(b.userId),p_role:z.enum(['owner','admin','editor','inbox_reviewer']).parse(b.role),p_enabled:z.boolean().parse(b.enabled)}));return respond({ok:true})}
  if(b.action==='media-delete'){
   if(!may(actor.role,'content:write'))throw new ServiceError('Your role cannot delete media.',403);
   const id=uuid.parse(b.id),path=checked(await server.rpc('prepare_media_delete',{p_actor:actor.id,p_id:id}));
   checked(await server.storage.from('aur-assets-v3').remove([path]));checked(await server.rpc('finish_media_delete',{p_actor:actor.id,p_id:id}));return respond({ok:true});
  }
  if(b.action==='media-alt'){if(!may(actor.role,'content:write'))throw new ServiceError('Your role cannot edit media.',403);checked(await server.rpc('media_alt',{p_actor:actor.id,p_id:uuid.parse(b.id),p_alt:z.string().trim().max(300).parse(b.alt)}));return respond({ok:true})}
  throw new ServiceError('Unknown studio action.',400);
 }catch(error){return errorResponse(error,respond)}
}
