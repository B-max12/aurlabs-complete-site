import {toRecord} from '../content-record';
import type {SupabaseClient} from '@supabase/supabase-js';
import {defaultContent,type SiteContent,type Product,type Article,type TeamMember,type ContentKind} from '../content';
import {checked,ServiceError} from './client';
export const contentTables={products:'products',journal:'articles',research:'research_posts',team:'team_members',settings:'site_settings'} as const;
export type Row=Record<string,any>;
const image=(asset:Row|undefined,external?:string)=>asset?'/api/media/'+asset.object_path:external||'';
export function fromRow(kind:ContentKind,row:Row,assets:Row[]=[],releases:Row[]=[],media:Row[]=[]):any{
 const base={id:row.id,published:row.published,_version:row.revision};
 if(kind==='settings')return {...row.data,_id:row.id,_version:row.revision};
 if(kind==='products')return {...base,slug:row.slug,name:row.name,tagline:row.tagline,description:row.description,category:row.category,platforms:row.platforms,status:row.status,featured:row.featured,features:row.features,repository:row.repository||'',license:row.license,visual:row.visual,accent:'lavender',screenshots:media.filter(m=>m.product_id===row.id).sort((a,b)=>a.position-b.position).map(m=>image(assets.find(a=>a.id===m.asset_id),m.external_url)),releases:releases.filter(r=>r.product_id===row.id).map(r=>({verified:r.verified,platform:r.platform,version:r.version,url:r.download_url,architecture:r.architecture,requirements:r.requirements,checksum:r.checksum_sha256||'',notes:r.notes,date:r.released_on}))} satisfies Product&{_version:number};
 if(kind==='team')return {...base,name:row.name,role:row.role,bio:row.bio,initials:row.initials,image:image(assets.find(a=>a.id===row.portrait_asset_id),row.external_portrait_url),url:row.profile_url||''} satisfies TeamMember&{_version:number};
 return {...base,slug:row.slug,title:row.title,summary:row.summary,body:row.body,tag:row.tag,author:row.author,date:row.published_on,cover:image(assets.find(a=>a.id===row.cover_asset_id),row.external_cover_url),references:row.references_json} satisfies Article&{_version:number};
}
export async function readSupabaseContent(client:SupabaseClient,includeDrafts=false):Promise<SiteContent>{
 const names=['products','articles','research_posts','team_members','site_settings','product_releases','product_media','media_assets','auri_guides','auri_faqs','auri_rules'] as const;
 const values=await Promise.all(names.map(async table=>{const rows:Row[]=[];for(let offset=0;offset<100000;offset+=500){let q=client.from(table).select('*').order('id').range(offset,offset+499);if(!includeDrafts)q=q.eq('published',true);if(table==='product_releases'&&!includeDrafts)q=q.eq('verified',true);const page=checked(await q) as Row[];rows.push(...page);if(page.length<500)return rows;}throw new ServiceError('Content needs a paginated catalogue adapter before exceeding 100,000 records.',503)}));
 const rows=Object.fromEntries(names.map((n,i)=>[n,values[i]]));
 if(!rows.site_settings[0])throw new ServiceError('Published website settings are unavailable.',503);
 const settings=fromRow('settings',rows.site_settings[0]);
 settings.auriRules=rows.auri_rules.filter(r=>r.settings_id===rows.site_settings[0].id).map(r=>r.rule);
 settings.auriGuides=Object.fromEntries(rows.auri_guides.map(g=>[g.target_id,g.help_text]));
 settings.auriFaqs=rows.auri_faqs.sort((a,b)=>a.position-b.position).map(f=>({id:f.id,question:f.question,answer:f.answer,destination:f.destination||'',published:f.published}));
 return {backend:'supabase',settings,products:rows.products.map(r=>fromRow('products',r,rows.media_assets,rows.product_releases,rows.product_media)),journal:rows.articles.map(r=>fromRow('journal',r,rows.media_assets)).sort((a,b)=>b.date.localeCompare(a.date)),research:rows.research_posts.map(r=>fromRow('research',r,rows.media_assets)).sort((a,b)=>b.date.localeCompare(a.date)),team:rows.team_members.map(r=>fromRow('team',r,rows.media_assets))};
}
export async function toRow(client:SupabaseClient,kind:ContentKind,data:Row,id:string){return toRecord(kind,data,id,async(url:string)=>{if(!url)return {asset_id:null,external_url:null};if(url.startsWith('/api/media/')){const found=checked(await client.from('media_assets').select('id').eq('object_path',url.slice(11)).maybeSingle());if(!found)throw new ServiceError('A selected image no longer exists.',400);return {asset_id:found.id,external_url:null}}return {asset_id:null,external_url:url}})}
export function emptyPublicContent():SiteContent{return {...structuredClone(defaultContent),products:[],journal:[],research:[],team:[]}}
