import {imageMetadata} from '../image-metadata';
import {requestClient,serviceClient,staff,checked,ServiceError} from './client';
import {sameOrigin,readBytes,sha} from '../server';
export async function supabaseUpload(req:Request){
 if(!sameOrigin(req))return Response.json({error:'Upload from the website.'},{status:403});
 let session:ReturnType<typeof requestClient>,server:ReturnType<typeof serviceClient>;try{session=requestClient(req);server=serviceClient()}catch{return Response.json({error:'Media service is not configured.'},{status:503})}let path:string|undefined;
 try{
  const actor=await staff(session.client,'content:write'),raw=await readBytes(req,Math.floor(5.2*1024*1024));
  const form=await new Response(raw,{headers:{'Content-Type':req.headers.get('content-type')||''}}).formData(),file=form.get('file');
  if(!(file instanceof File)||file.size<12||file.size>5242880)throw new ServiceError('Choose an image under 5 MB.',400);
  const buffer=await file.arrayBuffer(),bytes=new Uint8Array(buffer),type=imageMetadata(bytes),id=crypto.randomUUID();path=id+'.'+type.ext;
  const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',buffer))).map(v=>v.toString(16).padStart(2,'0')).join('');
  checked(await server.storage.from('aur-assets-v3').upload(path,bytes,{contentType:type.mime,upsert:false}));
  checked(await server.rpc('register_media',{p_actor:actor.id,p_record:{id,legacy_id:null,bucket:'aur-assets-v3',object_path:path,original_name:file.name.slice(0,200),mime:type.mime,width:type.width,height:type.height,size_bytes:file.size,sha256:digest,alt:'',published:false,created_at:new Date().toISOString(),deleting:false}}));
  return session.respond({ok:true,id,url:'/api/media/'+path,name:file.name},201);
 }catch(error){if(path)await server.storage.from('aur-assets-v3').remove([path]);return session.respond({error:error instanceof ServiceError?error.message:error instanceof Error&&error.message.startsWith('Use a valid')?error.message:'The image could not be saved.'},error instanceof ServiceError?error.status:error instanceof Error&&error.message.startsWith('Use a valid')?400:503)}
}
export async function supabaseMedia(req:Request,key:string){
 if(!/^[a-f0-9-]+\.(png|jpg|webp|gif)$/.test(key))return new Response('Not found',{status:404});
 try{
  const server=serviceClient(),asset=checked(await server.from('media_assets').select('*').eq('object_path',key).eq('deleting',false).maybeSingle());
  if(!asset)return new Response('Not found',{status:404});
  const headers=new Headers();if(!asset.published){const session=requestClient(req);await staff(session.client,'content:read');session.headers.forEach((value,key)=>headers.append(key,value))}
  const blob=checked(await server.storage.from(asset.bucket).download(asset.object_path));
  headers.set('Content-Type',asset.mime);headers.set('X-Content-Type-Options','nosniff');headers.set('Content-Security-Policy',"default-src 'none'");
  headers.set('Cache-Control',asset.published?'public, max-age=60':'private, no-store');
  return new Response(blob,{headers});
 }catch{return new Response('Not found',{status:404,headers:{'Cache-Control':'no-store'}})}
}
