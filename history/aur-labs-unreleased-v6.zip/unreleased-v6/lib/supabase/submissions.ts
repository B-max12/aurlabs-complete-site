import {submissionSchema} from '../validation';
import {parseBody,sameOrigin,json,sha} from '../server';
import {serviceClient,checked,ServiceError} from './client';
export async function supabaseSubmission(req:Request){
 if(!sameOrigin(req))return json({error:'Please submit this form from our website.'},403);
 try{
  const parsed=submissionSchema.safeParse(await parseBody(req,30000));if(!parsed.success)return json({error:parsed.error.issues[0].message,fields:parsed.error.flatten().fieldErrors},400);
  const data=parsed.data,{idempotencyKey,website,...payload}=data;payload.email=payload.email.toLowerCase();
  const reference=checked(await serviceClient().rpc('submit_form',{p_id:idempotencyKey,p_kind:data.kind,p_payload:payload,p_hash:await sha(JSON.stringify(payload)),p_ip_key:await sha('form-ip:'+(req.headers.get('cf-connecting-ip')||'unknown')),p_email_key:await sha('form-email:'+payload.email)}));
  return json({ok:true,reference},201);
 }catch(error){return error instanceof ServiceError?json({error:error.message},error.status):json({error:'Your message could not be confirmed. Your answers are still here; please retry.'},503)}
}
