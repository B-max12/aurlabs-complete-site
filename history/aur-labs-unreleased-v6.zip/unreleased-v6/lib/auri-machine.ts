export type AuriState='DORMANT'|'AVAILABLE'|'TARGETING'|'MOVING'|'EXPLAINING'|'IDLE'|'ERROR_HELP'|'SUCCESS'|'DISMISSED'|'FALLBACK';
export type AuriEvent='ENABLE'|'TARGET'|'MOVE'|'EXPLAIN'|'REST'|'ERROR'|'SUCCESS'|'DISMISS'|'FALLBACK'|'DISABLE';
/** Deterministic UI state only. Never accepts field values or sends telemetry. */
export function auriTransition(state:AuriState,event:AuriEvent):AuriState{
 if(event==='DISABLE')return 'DORMANT';
 if(event==='ENABLE')return 'AVAILABLE';
 if(event==='DISMISS')return 'DISMISSED';
 if(event==='TARGET')return 'TARGETING';
 if(event==='ERROR')return 'ERROR_HELP';
 if(event==='SUCCESS')return 'SUCCESS';
 if(event==='FALLBACK')return 'FALLBACK';
 if(event==='MOVE'&&state==='TARGETING')return 'MOVING';
 if(event==='EXPLAIN'&&['TARGETING','MOVING','AVAILABLE','FALLBACK'].includes(state))return 'EXPLAINING';
 if(event==='REST'&&['EXPLAINING','SUCCESS','ERROR_HELP','FALLBACK'].includes(state))return 'IDLE';
 return state;
}
