import {imageMetadata} from './image-metadata';
export function fitImage(width:number,height:number,max=2400){if(width<=0||height<=0||!Number.isFinite(width+height)||max<1)throw new Error('Invalid image dimensions.');const scale=Math.min(1,max/Math.max(width,height));return {width:Math.max(1,Math.round(width*scale)),height:Math.max(1,Math.round(height*scale))}}
/** Optional client-side still-image optimization; immutable server validation still applies. */
export async function optimizeImage(file:File):Promise<File>{
 if(file.size>20*1024*1024)throw new Error('Choose an image smaller than 20 MiB before optimizing.');
 if(!['image/jpeg','image/png'].includes(file.type))return file;
 const bytes=new Uint8Array(await file.arrayBuffer()),meta=imageMetadata(bytes);
 // Preserve APNG animation. Chunk names occur after length words, never inside decoded pixel data.
 if(meta.mime==='image/png'){for(let p=8;p+12<=bytes.length;){const size=new DataView(bytes.buffer).getUint32(p);if(String.fromCharCode(...bytes.subarray(p+4,p+8))==='acTL')return file;p+=size+12;}}
 if(typeof createImageBitmap!=='function')throw new Error('Image optimization is unavailable in this browser. Turn it off to upload the original.');
 const bitmap=await createImageBitmap(file);
 try{
  const size=fitImage(bitmap.width,bitmap.height),canvas=document.createElement('canvas');canvas.width=size.width;canvas.height=size.height;
  const context=canvas.getContext('2d');if(!context)throw new Error('Image optimization is unavailable.');context.drawImage(bitmap,0,0,size.width,size.height);
  const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('Image encoding failed.')),'image/webp',0.86));
  if(blob.size>=file.size&&size.width===bitmap.width&&size.height===bitmap.height)return file;
  const extension=blob.type==='image/webp'?'webp':'png';
  if(blob.size>5*1024*1024)throw new Error('Optimized image is still over 5 MiB. Choose a smaller image.');
  return new File([blob],file.name.replace(/\.[^.]+$/,'')+'.'+extension,{type:blob.type});
 }finally{bitmap.close()}
}
