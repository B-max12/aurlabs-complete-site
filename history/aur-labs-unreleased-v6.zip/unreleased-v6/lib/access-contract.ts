/** Target Supabase policy contract. Current production still uses its existing owner gate. */
export type AdminRole='owner'|'admin'|'editor'|'inbox_reviewer';
export type Permission='content:read'|'content:write'|'inbox:read'|'inbox:update'|'inbox:delete'|'roles:manage'|'audit:read'|'settings:write';
export const permissions:Record<AdminRole,readonly Permission[]>={
 owner:['content:read','content:write','inbox:read','inbox:update','inbox:delete','roles:manage','audit:read','settings:write'],
 admin:['content:read','content:write','inbox:read','inbox:update','inbox:delete','audit:read'],
 editor:['content:read','content:write'],
 inbox_reviewer:['inbox:read','inbox:update'],
};
export function may(role:AdminRole|null,permission:Permission,enabled=true){return !!role&&enabled&&permissions[role]?.includes(permission)===true}
