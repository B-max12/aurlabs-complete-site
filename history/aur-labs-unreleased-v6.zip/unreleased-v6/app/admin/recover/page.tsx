import Recovery from '../../studio-recovery';
export const dynamic='force-dynamic';
export const metadata={title:'Account recovery · Aur Labs',robots:{index:false,follow:false},referrer:'no-referrer'};
export default function Page(){return <Recovery/>}
