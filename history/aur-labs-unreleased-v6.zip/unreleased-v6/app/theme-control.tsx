'use client';
import {useEffect,useState} from 'react';
export type Theme='system'|'light'|'dark';

export default function ThemeControl(){
 const [theme,setTheme]=useState<Theme|null>(null);
 useEffect(()=>{try{const p=localStorage.getItem('aur-theme');setTheme(p==='light'||p==='dark'?p:'system')}catch{setTheme('system')}},[]);
 useEffect(()=>{if(!theme)return;const media=matchMedia('(prefers-color-scheme: dark)');const apply=()=>{document.documentElement.dataset.theme=theme==='system'?(media.matches?'dark':'light'):theme};apply();media.addEventListener('change',apply);return()=>media.removeEventListener('change',apply)},[theme]);
 return <label className="theme-control"><span className="sr-only">Color theme</span><select aria-label="Color theme" value={theme||'system'} onChange={e=>{const next=e.target.value as Theme;setTheme(next);try{localStorage.setItem('aur-theme',next)}catch{}}}><option value="system">System</option><option value="light">Light</option><option value="dark">Dark</option></select></label>;
}
