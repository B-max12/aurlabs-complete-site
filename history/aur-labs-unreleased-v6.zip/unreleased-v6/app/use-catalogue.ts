'use client';
import {useEffect,useRef,useState} from 'react';
import {PLATFORMS,type Product} from '@/lib/content';
type Query={category:string;platform:string;search:string;sort:string;page:number};
const initial:Query={category:'all',platform:'All platforms',search:'',sort:'featured',page:1};
export function readCatalogue(search:string):Query{const q=new URLSearchParams(search),page=Number(q.get('page'));return {category:['software','app','cli'].includes(q.get('category')||'')?q.get('category')!:'all',platform:PLATFORMS.includes(q.get('platform') as typeof PLATFORMS[number])?q.get('platform')!:'All platforms',search:(q.get('q')||'').slice(0,160),sort:['az','available','newest'].includes(q.get('sort')||'')?q.get('sort')!:'featured',page:Number.isSafeInteger(page)&&page>0?page:1}}
export function catalogueProducts(products:Product[],q:Query){const latest=(p:Product)=>Math.max(0,...p.releases.map(r=>Date.parse(r.date)||0));return products.filter(p=>(q.category==='all'||p.category===q.category)&&(q.platform==='All platforms'||p.platforms.includes(q.platform))&&[p.name,p.tagline,p.category].join(' ').toLowerCase().includes(q.search.toLowerCase())).sort((a,b)=>(q.sort==='az'?a.name.localeCompare(b.name):q.sort==='newest'?latest(b)-latest(a):q.sort==='available'?Number(b.status==='released')-Number(a.status==='released'):Number(b.featured)-Number(a.featured))||a.name.localeCompare(b.name))}
export function useCatalogue(){
 const [query,setQuery]=useState<Query>(initial),[search,setSearch]=useState('');const ready=useRef(false),pop=useRef(false);
 useEffect(()=>{const read=()=>{pop.current=true;const q=readCatalogue(window.location.search);setQuery(q);setSearch(q.search);ready.current=true};read();window.addEventListener('popstate',read);return()=>window.removeEventListener('popstate',read)},[]);
 useEffect(()=>{if(!ready.current||search===query.search)return;const timer=setTimeout(()=>setQuery(q=>({...q,search,page:1})),250);return()=>clearTimeout(timer)},[search,query.search]);
 useEffect(()=>{if(!ready.current)return;if(pop.current){pop.current=false;return;}const url=new URL(window.location.href);for(const [key,value] of Object.entries({category:query.category,platform:query.platform,q:query.search,sort:query.sort,page:String(query.page)})){const fallback={category:'all',platform:'All platforms',q:'',sort:'featured',page:'1'}[key];if(value===fallback)url.searchParams.delete(key);else url.searchParams.set(key,value)}if(url.href!==window.location.href)window.history.pushState(null,'',url)},[query]);
 const set=(patch:Partial<Query>)=>setQuery(q=>({...q,...patch,page:patch.page??1}));
 return {...query,search,filterSearch:query.search,setSearch,setCategory:(category:string)=>set({category}),setPlatform:(platform:string)=>set({platform}),setSort:(sort:string)=>set({sort}),setPage:(page:number)=>set({page})};
}
