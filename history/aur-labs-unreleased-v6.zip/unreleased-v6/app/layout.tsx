import type { Metadata } from "next";
import "./globals.css";
import "./monochrome.css";
import {THEME_BOOT} from "@/lib/theme";

export const metadata: Metadata = {
  metadataBase: new URL("https://aurlabs.online"),
  title: "Aur Labs — Good software. For everyone.",
  description: "An independent, non-profit software lab building useful free tools for people everywhere. Explore our work, join the team, or share a problem worth solving.",
  openGraph: {title:"Aur Labs — Good software. For everyone.",description:"Useful tools. Thoughtful design. Zero price tags.",type:"website",images:[{url:"/assets/aur-monolith.svg",width:640,height:640,alt:"Aur Labs chrome sculpture"}]},
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head><link rel="preload" href="/fonts/geist-latin-wght-normal.woff2" as="font" type="font/woff2" crossOrigin="anonymous"/><script dangerouslySetInnerHTML={{__html:THEME_BOOT}}/></head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
