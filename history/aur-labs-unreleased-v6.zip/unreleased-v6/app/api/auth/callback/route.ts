import {parseCookieHeader} from '@supabase/ssr';
import {LINK_COOKIE,verifyLinkState,linkCookie} from '@/lib/supabase/link-state';
import {supabaseEnabled,runtime} from '@/lib/backend';
import {requestClient,staff} from '@/lib/supabase/client';
export async function GET(req:Request){
 if(!supabaseEnabled())return new Response('Not found',{status:404});
 const url=new URL(req.url),origin=runtime().AUR_PUBLIC_URL;
 if(!origin||url.origin!==origin)return new Response('Callback is not configured',{status:400});
 const session=requestClient(req);
 const link=parseCookieHeader(req.headers.get("cookie")||"").find(c=>c.name===LINK_COOKIE)?.value;
 session.headers.append("Set-Cookie",linkCookie());
 let success=false;
 try{
  const expected=link?await verifyLinkState(link):null;
  const code=url.searchParams.get('code');if(!code||code.length>2048||url.searchParams.has('error'))throw new Error('Missing code');
  const result=await session.client.auth.exchangeCodeForSession(code);if(result.error)throw new Error('Code exchange failed');
  const actor=await staff(session.client,undefined,true);if(expected&&actor.id!==expected)throw new Error("Linked identity mismatch");success=true;
 }catch{await session.client.auth.signOut({scope:'local'})}
 session.headers.set('Location',origin+(success?'/admin':'/admin?auth_error=provider'));
 session.headers.set('Referrer-Policy','no-referrer');
 return new Response(null,{status:303,headers:session.headers});
}
