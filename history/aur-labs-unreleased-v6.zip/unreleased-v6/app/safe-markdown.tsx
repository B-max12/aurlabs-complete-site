import type {ReactNode} from 'react';
/** Small supported Markdown subset; source HTML is always escaped by React. */
function inline(text:string):ReactNode[]{
 return text.split(/(\[[^\]\n]+\]\(https:\/\/[^\s)]+\)|\*\*[^*\n]+\*\*|`[^`\n]+`)/g).map((part,i)=>{
  const link=/^\[([^\]]+)\]\((https:\/\/[^\s)]+)\)$/.exec(part);
  if(link){try{const url=new URL(link[2]);if(url.protocol==='https:'&&!url.username&&!url.password)return <a key={i} href={url.href} target="_blank" rel="noopener noreferrer">{link[1]}</a>}catch{}}
  if(part.startsWith('**')&&part.endsWith('**'))return <strong key={i}>{part.slice(2,-2)}</strong>;
  if(part.startsWith('`')&&part.endsWith('`'))return <code key={i}>{part.slice(1,-1)}</code>;
  return part;
 });
}
export default function SafeMarkdown({text}:{text:string}){
 const lines=text.replace(/\r\n/g,'\n').split('\n'),blocks:ReactNode[]=[];
 for(let i=0;i<lines.length;){
  if(!lines[i].trim()){i++;continue}
  if(lines[i].startsWith('```')){const code=[];i++;while(i<lines.length&&!lines[i].startsWith('```'))code.push(lines[i++]);i++;blocks.push(<pre key={blocks.length}><code>{code.join('\n')}</code></pre>);continue}
  const heading=/^(#{2,3}) (.+)$/.exec(lines[i]);if(heading){blocks.push(heading[1].length===2?<h2 key={blocks.length}>{inline(heading[2])}</h2>:<h3 key={blocks.length}>{inline(heading[2])}</h3>);i++;continue}
  if(/^[-*] /.test(lines[i])){const items=[];while(i<lines.length&&/^[-*] /.test(lines[i]))items.push(<li key={i}>{inline(lines[i++].slice(2))}</li>);blocks.push(<ul key={blocks.length}>{items}</ul>);continue}
  if(/^\d+\. /.test(lines[i])){const items=[];while(i<lines.length&&/^\d+\. /.test(lines[i]))items.push(<li key={i}>{inline(lines[i++].replace(/^\d+\. /,''))}</li>);blocks.push(<ol key={blocks.length}>{items}</ol>);continue}
  const paragraph=[];while(i<lines.length&&lines[i].trim()&&!/^(#{2,3} |```|[-*] |\d+\. )/.test(lines[i]))paragraph.push(lines[i++]);blocks.push(<p key={blocks.length}>{inline(paragraph.join('\n'))}</p>);
 }
 return <>{blocks}</>;
}
