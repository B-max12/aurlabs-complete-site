# G2 — staging isolation and configuration

- Recorded at: `2026-10-16T03:55:43.166528+00:00` (UTC).
- Tested implementation source: `1714e82c1156a1c03ba9eac2aa808e56b8b57d7e` (saved version 5).
- Site: `appgprj_6acb04e29d2081918548275da19f51e4`. Production Supabase: `opbgjmoztvqjsmxexptv`; staging: **not provided**.
- Result: **BLOCKED**.
- Method: Read-only connected project, branch, Site and runtime inventories.
- Responsible operator: Codex (local/read-only audit); hosted execution owner not assigned.
- Evidence: relative paths below, within `release/`; no private backup, credentials, or applicant data are included.

| Setting | Current fact / required action |
| --- | --- |
| Connected organization | Aur Labs (`vraasivmacstdidninbe`); not yet selected by owner for a new project cost quote |
| Production project | `opbgjmoztvqjsmxexptv`; must never be used as staging |
| Staging ref and region | Not supplied or created |
| Protected staging origin | Not supplied; Site preview URL is null |
| Protection of page and API routes | Not tested |
| Staging indexing protection | Not configured or tested |
| Owner verified Auth UUID | Not supplied |
| Role test identities | Not supplied |
| Provider/SMTP configuration scope | Owner reports configuration; staging/production scope unknown |

The Supabase cost tool requires owner selection of the organization before a quote. Ask whether to use **Aur Labs** for the quote, repeat the actual cost for approval, and only then create an approved staging project/branch. This audit performs neither quote nor creation. A protected staging website must use a real separate hosting environment; do not repoint the live Site or call an invented preview hostname operational.

Source-verified runtime names: `AUR_BACKEND`, `AUR_PUBLIC_URL`, `AUR_REQUIRE_MFA`, `AUR_OAUTH_PROVIDERS`, `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `SUPABASE_SECRET_KEY`. `lib/backend.ts` defaults to D1 and MFA enabled. Staging requires the isolated project, exact origin, MFA enabled, and server-only secret configuration. Keep the provider list empty until real round trips pass. Source accepts public URL/key aliases, but no privileged secret may use a public variable prefix.

Website callback: `/api/auth/callback`. Recovery page: `/admin/recover`. Provider callback must be the one issued for the **staging** Supabase project. Record exact allowed origins only after an actual staging origin exists. Do not modify production Auth URLs based on this report.

Acceptance requires authenticated protection on pages and API routes, an unauthenticated denial test, no production credentials/configuration, actual owner and test-role identities, and a clean browser bundle. Only the local bundle marker scan has passed.

Evidence: `evidence/service-inventory.json`, `evidence/client-bundle.log`; source: `../lib/backend.ts`, `../app/api/auth/callback/route.ts`; setup: `../docs/authentication-setup.md`.
