# Aur Labs 3.0 release evidence

Recorded `2026-10-16T03:55:43.166528+00:00`. **NO-GO for production.** Start with [the release decision](release-go-no-go.md). All reports distinguish completed local checks from unexecuted hosted work. This folder contains no credentials, private backups or applicant records and is not placed in `public/` or the deployment assets.

Tested implementation: saved v5 `1714e82c1156a1c03ba9eac2aa808e56b8b57d7e`. Production remains v2 `4847db8e2e23a9acb1083b4c60b3d272514265d4`. This documentation continuation must preserve the application source digest in [candidate.json](evidence/candidate.json); the save receipt identifies its final documentation commit.

## Runbook reports

- [auth-provider-test-matrix.md](auth-provider-test-matrix.md)
- [backup-manifest.private-location.txt](backup-manifest.private-location.txt)
- [backup-restore-report.md](backup-restore-report.md)
- [baseline-audit.md](baseline-audit.md)
- [browser-device-accessibility-report.md](browser-device-accessibility-report.md)
- [hosted-rls-storage-security-results.md](hosted-rls-storage-security-results.md)
- [interaction-registry-results.md](interaction-registry-results.md)
- [migration-manifest.md](migration-manifest.md)
- [owner-content-legal-signoff.md](owner-content-legal-signoff.md)
- [performance-report.md](performance-report.md)
- [post-launch-monitoring.md](post-launch-monitoring.md)
- [reconciliation-report.md](reconciliation-report.md)
- [release-go-no-go.md](release-go-no-go.md)
- [rollback-rehearsal.md](rollback-rehearsal.md)
- [staging-environment-record.md](staging-environment-record.md)

## Evidence and open work

- [Service inventory](evidence/service-inventory.json) — read-only baseline, without credentials or private records.
- [Candidate and source digest](evidence/candidate.json), [test command results](evidence/results.json), [build results](evidence/build-results.json), with adjacent logs.
- [Exact migration checksums](evidence/migrations.json).
- [Source control inventory](evidence/source-controls.json) — source occurrences, not passed browser tests.
- [Production HTTP attempt](evidence/production-http.json) — blocked by Cloudflare; no application-health conclusion.
- [Open release issues](issues.json) — owner roles required; no invented assigned people.

The immutable Git version is the evidence checkpoint. Complete or supersede reports only with measured results and a new source version. Never replace a blocked result with a pass based solely on local fixture success.
