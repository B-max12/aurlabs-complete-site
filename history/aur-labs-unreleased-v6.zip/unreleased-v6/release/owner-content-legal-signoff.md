# G8 — owner content, legal and feature decisions

- Recorded at: `2026-10-16T03:55:43.166528+00:00` (UTC).
- Tested implementation source: `1714e82c1156a1c03ba9eac2aa808e56b8b57d7e` (saved version 5).
- Site: `appgprj_6acb04e29d2081918548275da19f51e4`. Production Supabase: `opbgjmoztvqjsmxexptv`; staging: **not provided**.
- Result: **NOT APPROVED**.
- Method: Compared current implementation limits and owner runbook; no owner signoff inferred.
- Responsible operator: Codex (local/read-only audit); hosted execution owner not assigned.
- Evidence: relative paths below, within `release/`; no private backup, credentials, or applicant data are included.

| Decision | Current fact | Required owner action |
| --- | --- | --- |
| Privacy/terms and retention | Editable source; not legally approved | Review Supabase, email/Storage/logs, applicant data, rights and retention |
| Releases and compatibility | Concepts remain honest; only verified release links shown | Approve real products/versions/licenses/platforms/download URLs |
| Contact/team/consent | Implemented copy/fields | Approve published identity, addresses, team and consent wording |
| Support/donations | No inferred tax status or payment completion | Verify recipients, links, currency/recurrence and legal wording |
| Design and Auri | Source implemented; browser acceptance missing | Review actual staged desktop/mobile/AT experience |
| Responsive image variants | Delivery not enabled | Complete before release or explicitly accept deferral |
| Scheduled publication | No active scheduler; UI says unavailable | Provision and test or explicitly accept deferral |
| Install commands | No reviewed real commands; absent | Supply reviewed commands/releases or explicitly accept absence |
| Image optimization | Optional still-image encoder; fidelity unverified | Complete real-browser QA before accepting |

Approver name: NOT ASSIGNED. Review timestamp: NOT PROVIDED. Approved source/version: NOT PROVIDED. Approved legal revisions and feature decisions: NOT PROVIDED. A general instruction to continue does not supply the runbook's exact launch authorization.

Do not populate approvals on behalf of the owner. Record dated decisions and the exact staged candidate after review; unresolved items remain release blockers, not an accepted backlog.

Evidence: `../docs/completion-status.md`, `../docs/deployment-readiness.md`, `issues.json`.
