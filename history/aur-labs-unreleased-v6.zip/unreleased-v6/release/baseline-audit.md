# G0 — baseline and source audit

- Recorded at: `2026-10-16T03:55:43.166528+00:00` (UTC).
- Tested implementation source: `1714e82c1156a1c03ba9eac2aa808e56b8b57d7e` (saved version 5).
- Site: `appgprj_6acb04e29d2081918548275da19f51e4`. Production Supabase: `opbgjmoztvqjsmxexptv`; staging: **not provided**.
- Result: **BLOCKED overall; source identification and local checks PASS**.
- Method: Read-only native Sites/Supabase inventory, Git/source inspection, six isolated suites, TypeScript, build, HTTP GET.
- Responsible operator: Codex (local/read-only audit); hosted execution owner not assigned.
- Evidence: relative paths below, within `release/`; no private backup, credentials, or applicant data are included.

## Exact candidate and live baseline

The runbook refers to version 4 in several historical sections. The latest saved source is **version 5**, not version 4. This audit uses that exact source and all five migrations. This continuation changes release evidence/documentation only. The final saved evidence version has a new commit; its application source must match the digest in `evidence/candidate.json`. The new version number is a save, not a deployment.

| Item | Observed value |
| --- | --- |
| Saved candidate | v5, `1714e82c1156a1c03ba9eac2aa808e56b8b57d7e` |
| Saved candidate version ID | `appgprj_6acb04e29d2081918548275da19f51e4~appgver_88f08e5ace40819184c03891d5af9266` |
| Production | v2, `4847db8e2e23a9acb1083b4c60b3d272514265d4` |
| Production deployment | `appgdep_6acea96d67088191876531ff4a31405d`, succeeded |
| Production runtime revision | 2; no configured variable entries |
| Production domains | `aurlabs.online`, `www.aurlabs.online`; both active with active TLS |
| Site access | Public; current connector user is owner |
| Candidate preview | No preview URL returned |
| D1 binding | `DB`; physical database ID not exposed by available inventory |
| R2 binding | `BUCKET`; physical bucket ID and object inventory unavailable |
| Supabase production | `opbgjmoztvqjsmxexptv`, Singapore `ap-southeast-1`, ACTIVE_HEALTHY |
| Supabase aggregate inventory | 0 Auth users; 0 public base tables; 0 migrations |
| Accessible staging | No separate project or branch returned |
| Source delta versus v2 | 82 files, 2,813 insertions, 168 deletions before evidence changes |

The seven D1 tables returned without truncation are `admin_unlocks`, `administrators`, `audit_log`, `content`, `media`, `rate_limits`, `submissions`. A table inventory is not a full export. No D1 table row counts or R2 object counts are asserted by this audit.

The owner has confirmed privileged-key rotation. Independent key-ID/revocation inspection is unavailable through the current connector. The client bundle scan checks two known credential markers; it is not a complete secret or revocation audit. No live login credentials, provider secrets, or private records were retrieved or stored.

## Reproducible local checks

Use Node `v24.19.0` and `pnpm@11.25.0` with the committed lockfile. The Sites installer is `node /root/.codex/plugins/cache/openai-curated-remote/sites/1.0.0/scripts/install-dependencies.mjs` when installation is needed; dependencies were already present and unchanged here. There is no invented `npm test` command.

```sh
node tests/integration.mjs
node tests/client.mjs
node tests/supabase-schema.mjs
node tests/supabase-http.mjs
node tests/migration.mjs
node tests/editorial.mjs
node node_modules/typescript/bin/tsc --noEmit
node /root/.codex/plugins/cache/openai-curated-remote/sites/1.0.0/scripts/build-site.mjs
node scripts/verify-client-bundle.mjs
```

The six suites passed 94 + 273 + 89 + 53 + 10 + 29 = **548 assertions**. TypeScript, build, and the marker scan passed. Exact command times, exit codes, durations, and output are in `evidence/results.json`, `evidence/build-results.json`, and adjacent logs. Lockfile SHA-256: `589b4e8496514f59030899e6ef3a0c791ff98fdf834261b61a5ace2161053187`. Dependency ranges remain resolved by the committed lockfile; no dependency upgrade was performed.

## Live smoke limit and G0 stop

Unauthenticated GETs for `/`, `/products`, `/about`, `/join`, `/contact`, `/admin`, `/api/admin?view=status`, and `/api/content` each returned HTTP 403. A follow-up `/` returned Cloudflare error 1010. This demonstrates blocking of requests from this execution environment, **not a verified application outage and not a passed production journey**. No access-control bypass was attempted.

G0 cannot pass until pre-change behavior is observed in an allowed browser, independent key-revocation evidence is supplied, and backup/QA/cutover/rollback operators are named. The runbook requires stopping at a failed gate. No staging or production mutation, Auth change, migration, backend switch, deployment, or deletion follows this audit.

Evidence: `evidence/service-inventory.json`, `evidence/production-http.json`, `evidence/candidate.json`, `migration-manifest.md`, `issues.json`.
