# G3 — hosted RLS, Storage and security

- Recorded at: `2026-10-16T03:55:43.166528+00:00` (UTC).
- Tested implementation source: `1714e82c1156a1c03ba9eac2aa808e56b8b57d7e` (saved version 5).
- Site: `appgprj_6acb04e29d2081918548275da19f51e4`. Production Supabase: `opbgjmoztvqjsmxexptv`; staging: **not provided**.
- Result: **BLOCKED / NOT RUN**.
- Method: Local PostgreSQL and actual-SDK fixtures only; no hosted test writes.
- Responsible operator: Codex (local/read-only audit); hosted execution owner not assigned.
- Evidence: relative paths below, within `release/`; no private backup, credentials, or applicant data are included.

| Actor / area | Required hosted evidence | Result |
| --- | --- | --- |
| Anonymous | Published content only; no drafts, inbox, staff or private object access | NOT RUN |
| Authenticated without active role | Admin denied; no privilege through provider or editable metadata | NOT RUN |
| Inbox reviewer | Inbox permitted; content/settings/roles denied | NOT RUN |
| Editor | Allowed content and media edits; inbox/settings/role restrictions enforced | NOT RUN |
| Admin | Content/inbox permissions; owner-only role and settings restrictions | NOT RUN |
| Owner | Verified identity, explicit active role, required MFA, safe role administration | NOT RUN |
| Revoked/disabled identity | Existing tokens denied promptly on protected operations | NOT RUN |
| Storage | Private bucket direct-read denial; allowed publication path; MIME/size/signature validation; upload/read/hash/delete | NOT RUN |
| Referenced media | Delete blocked by content/revision references; partial deletion safe to retry | NOT RUN |
| Concurrency/pagination | Real rows and stale-write conflicts, stable cursor pages, no private row leaks | NOT RUN |
| Advisors/types | Hosted security/performance findings resolved; types generated and compared | NOT RUN |

Local evidence: 89 PostgreSQL/RLS and 53 SDK/HTTP assertions; server authorization reads current roles, validates user/session claims and revocation, and enforces MFA. Explicit provider linking binds a signed short-lived cookie to the current account. The source bundle marker scan passed for 12 client chunks. These are useful local checks, not a hosted security certification.

G3 requires actual staging sessions for every actor and direct Data API/Storage requests, including denied paths. No role sessions or staging project are available. Store sanitized result codes and request identifiers; never capture auth cookies, MFA setup material or applicant records in these reports.

Evidence: `evidence/supabase-schema.log`, `evidence/supabase-http.log`, `evidence/client-bundle.log`; access contract: `../lib/access-contract.ts`.
