# G5 — interaction registry and acceptance results

- Recorded at: `2026-10-16T03:55:43.166528+00:00` (UTC).
- Tested implementation source: `1714e82c1156a1c03ba9eac2aa808e56b8b57d7e` (saved version 5).
- Site: `appgprj_6acb04e29d2081918548275da19f51e4`. Production Supabase: `opbgjmoztvqjsmxexptv`; staging: **not provided**.
- Result: **LOCAL SUITES PASS; HOSTED ACCEPTANCE BLOCKED**.
- Method: TypeScript AST control inventory plus existing DOM/SSR/SDK suites; no native-browser execution.
- Responsible operator: Codex (local/read-only audit); hosted execution owner not assigned.
- Evidence: relative paths below, within `release/`; no private backup, credentials, or applicant data are included.

The static inventory contains **300 native/wrapper control occurrences** across 23 TSX files. Each entry records a stable report ID, source path/line, tag, attributes/handler text and hosted status. A dynamic list may render many controls from one occurrence; hidden branches and runtime accessible names must be expanded during browser testing. This is a source inventory, not a claim that every click path passed.

Every row below is assigned to the **browser/hosted QA operator (not yet named)**. Test keyboard paths with Tab/Shift-Tab and Enter/Space; dialogs also require Escape and focus return. Repeat on mobile with touch, portrait/landscape and virtual keyboard where relevant. For server actions test successful response, denial/validation, network loss, retry and session expiry. Hosted result for **every row is NOT RUN**.

| Case | Route / selector or accessible control | Expected state and request | Related local evidence |
| --- | --- | --- | --- |
| UI-01 | Shared header/footer links, `a[href]` | Correct route/external destination; no unexpected write | integration, client |
| UI-02 | Open navigation / Close menu | Native dialog, scroll lock, Escape and focus return | client; native behavior pending |
| UI-03 | `select[aria-label="Color theme"]` | System/light/dark preference, refresh persistence | client |
| UI-04 | Home hero links/cards | Published destinations and empty/concept states | integration, client |
| UI-05 | `/products` category/platform/query/sort | URL-backed filtering, back/forward, debounced query | client |
| UI-06 | `/products` pagination/reset | Page changes, zero results and reset; no stale URL state | client |
| UI-07 | Product screenshots/gallery | Open/select/close, meaningful alt text, focus return | client; native visual QA pending |
| UI-08 | Product release selectors/download/source | Verified HTTPS release only; correct platform/version; no false install action | integration, client |
| UI-09 | Journal/research cards and Markdown links | Published routes; escaped HTML and safe external references | integration, client |
| UI-10 | `/join` labeled fields, next/back/edit | Four steps, inline validation, error summary anchors, review | client |
| UI-11 | Join draft opt-in/restore/clear | Tab-local 24h expiry; restored consent not reused | client |
| UI-12 | Join submit/retry | POST `/api/submissions`; confirmed reference only; idempotent retry | integration, client, supabase-http |
| UI-13 | `/contact` topic/product/problem fields | Preserve input on error; POST `/api/submissions`; confirmed success | integration, client |
| UI-14 | `/support` links/form | Reviewed payment destination or mail inquiry; no charge/donation success claim | integration; hosted review pending |
| UI-15 | Auri launcher/search/help/dismiss/minimize/reset | Explicit opt-in, local preferences, no private field-value request | client, editorial |
| UI-16 | Auri animation choice and field hints | Optional 3D; reduced-motion/WebGL fallback; modal suppression and inline placement | client geometry; native QA pending |
| UI-17 | `/admin` sign-in/retry/check again | GET `/api/admin?view=status`, POST action unlock; no-role denial | integration, supabase-http |
| UI-18 | Continue with provider | POST `/api/admin` oauth, provider round trip, fixed callback | supabase-http; hosted pending |
| UI-19 | MFA sign-in/setup/verify/remove | Corresponding protected admin actions; deny unsafe last-factor removal | supabase-http, supabase-schema |
| UI-20 | `/admin/recover` request/confirm/verify/reset | Recovery actions, single-use authorization, MFA, revocation | supabase-http, supabase-schema |
| UI-21 | Admin navigation/menu/refresh/error dismiss | Role-filtered sections, unsaved-edit handling, current server data | client, integration |
| UI-22 | Lock studio | POST `/api/admin` lock; remove local state and revoke appropriate session | integration, supabase-http |
| UI-23 | Content Add/Edit/Remove release/reference/image | Draft editing, bounded validated fields; image removal from record not bucket deletion | client, integration |
| UI-24 | `[data-auri-id="admin-save"]`, publish toggle | POST admin save; expected revision; private draft or public publish; conflict preserves edits | integration, supabase-schema |
| UI-25 | Content Preview / discard / autosave | Unsaved local preview; confirmed discard; opt-in draft autosave only | client, integration |
| UI-26 | Show revision history / Restore | GET revisions; confirmed POST restore creates new revision | supabase-schema, supabase-http |
| UI-27 | Inbox search/type/status/Previous/Next | GET admin inbox with cursor/filter; 25-row pages | client, supabase-http |
| UI-28 | Inbox detail/status/delete/export/reply | Role-scoped POST submission; confirmed deletion; page-only export; mailto reply opens email client | client, supabase-schema |
| UI-29 | Media Upload image / optimization option | POST `/api/media`; validated file; confirmed URL; encode failure visible | integration, supabase-http, editorial sizing |
| UI-30 | Media Previous/Next/Reload media | GET admin media, 24-row cursor pages and explicit retry | client, integration, supabase-http |
| UI-31 | Copy URL / Save description / Check references / Delete image | Clipboard; media-alt; media-references; protected media-delete and retry | supabase-http, supabase-schema; clipboard pending |
| UI-32 | Auri Studio rules/FAQ/order/publish/preview | Validated draft; deterministic preview; POST auri-save; public/private isolation | client, editorial, supabase-schema |
| UI-33 | Settings navigation/hero/legal/payment fields | Owner-only validated POST settings; links restricted as specified | editorial, supabase-http |
| UI-34 | Preview settings / preview pages / Back to settings | Private unsaved native dialog; links suppressed; focus restored | client; native QA pending |
| UI-35 | Security Link provider / password / roles | Explicit MFA link; password revokes; owner-only verified UUID role mutation | supabase-http, supabase-schema |
| UI-36 | Design system categories/validation/reset/dialog | Local examples, errors/status announcements, native focus | client, editorial |

The suite names reference `tests/<name>.mjs`. These are related contract tests, not proof that every row is fully automated. Native focus, Safari, screen readers, clipboard, real image encoding and live Auth/Storage remain unverified. Expand `SRC-*` occurrences into per-state browser cases before marking G5 complete.

Evidence: `evidence/source-controls.json`, `evidence/results.json`, `../docs/interaction-registry.md` and adjacent test logs. No screenshots or recordings were produced.
