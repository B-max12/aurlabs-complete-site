# G6 — rollback rehearsal

- Recorded at: `2026-10-16T03:55:43.166528+00:00` (UTC).
- Tested implementation source: `1714e82c1156a1c03ba9eac2aa808e56b8b57d7e` (saved version 5).
- Site: `appgprj_6acb04e29d2081918548275da19f51e4`. Production Supabase: `opbgjmoztvqjsmxexptv`; staging: **not provided**.
- Result: **BLOCKED / NOT RUN**.
- Method: Confirmed known production source/deployment and reviewed rollback procedure; no runtime rollback performed.
- Responsible operator: Codex (local/read-only audit); hosted execution owner not assigned.
- Evidence: relative paths below, within `release/`; no private backup, credentials, or applicant data are included.

Known baseline: version 2, source `4847db8e2e23a9acb1083b4c60b3d272514265d4`, deployment `appgdep_6acea96d67088191876531ff4a31405d`, runtime revision 2 with no configured entries, D1 binding `DB`, R2 binding `BUCKET`. No production rollback is necessary because this candidate has not been deployed.

No named rollback operator, acceptance window, verified backup, staging target, or successful rehearsal exists. No elapsed recovery time or recovery-point guarantee is claimed.

Required isolated rehearsal:

1. Freeze staging writes and record cutover/snapshot boundaries.
2. Export every simulated post-cutover Supabase write and object; retain UUIDs/references and protected records.
3. Reconcile those changes into the isolated D1/R2 restore, including submissions, edits and media. Record conflicts and decisions.
4. Restore the exact v2 application/runtime on isolated hosting and verify login, published content, forms, role boundaries and asset URLs before reopening writes.
5. Record operator, start/end, data-loss check, failures, commands and restricted evidence. Rehearse again after material migration changes.

Source-only rollback is insufficient: it would discard accepted post-cutover submissions. The current importer intentionally has no production override. A separate reviewed production migration and reverse-reconciliation operation remains required; do not bypass its staging guard.

Immediate stop/rollback criteria must include any private-data exposure or privilege escalation, unreconciled accepted data, persistent database connection failure, and broken critical login/submission flows. Exact thresholds and decision authority remain owner decisions. Retain D1/R2 and both backups throughout an owner-approved acceptance/retention window.

Evidence: `evidence/service-inventory.json`, `../docs/migration-runbook.md`; actual rehearsal artifacts: NONE.
