# G7 — performance and bundle evidence

- Recorded at: `2026-10-16T03:55:43.166528+00:00` (UTC).
- Tested implementation source: `1714e82c1156a1c03ba9eac2aa808e56b8b57d7e` (saved version 5).
- Site: `appgprj_6acb04e29d2081918548275da19f51e4`. Production Supabase: `opbgjmoztvqjsmxexptv`; staging: **not provided**.
- Result: **BUILD/SIZE MEASUREMENT PASS; USER PERFORMANCE NOT MEASURED**.
- Method: Production build and gzip byte measurement of built JavaScript; no Lighthouse/field data.
- Responsible operator: Codex (local/read-only audit); hosted execution owner not assigned.
- Evidence: relative paths below, within `release/`; no private backup, credentials, or applicant data are included.

| Built chunk | Raw bytes | Gzip bytes |
| --- | --- | --- |
| `AuriScene-CF4y4bBe.js` | 535,325 | 132,694 |
| `index-B9He0ECC.js` | 196,615 | 56,319 |
| `framework-D_rUT4EX.js` | 190,152 | 59,092 |
| `site-I5TStRiX.js` | 174,636 | 49,667 |
| `admin-CrZXMn26.js` | 71,420 | 20,235 |

12 browser chunks were scanned. The optional `AuriScene` chunk exceeds the bundler's 500 kB raw-size warning and remains opt-in. The build also reported proxy environment detection. Neither warning caused build failure. Framework and entry chunks are additional to the public/admin chunks; these are not total page transfer budgets. The report does not assert byte-for-byte identical builds across times.

| User metric | Target in owner runbook | Measured result |
| --- | --- | --- |
| LCP | <=2.5 s | NOT MEASURED |
| INP | <=200 ms | NOT MEASURED |
| CLS | <=0.1 | NOT MEASURED |
| Lighthouse | Owner-agreed budget | NOT RUN; budget not agreed |
| Field p75 / network waterfall | Real environment and representative users | NO DATA |

Local bundle sizes cannot establish these targets. After staging, measure authenticated and public journeys on representative desktop/mobile/network conditions, both before and after Auri opt-in. Include image layout stability and navigation/form responsiveness. Record throttling, browser version, trace location and device. Field percentiles require sufficient real data after launch; do not fabricate them from a lab run.

Evidence: `evidence/build.log`, `evidence/build-results.json`, `evidence/client-bundle.log`.
