# G1 — complete backup and restore

- Recorded at: `2026-10-16T03:55:43.166528+00:00` (UTC).
- Tested implementation source: `1714e82c1156a1c03ba9eac2aa808e56b8b57d7e` (saved version 5).
- Site: `appgprj_6acb04e29d2081918548275da19f51e4`. Production Supabase: `opbgjmoztvqjsmxexptv`; staging: **not provided**.
- Result: **BLOCKED; fixture tooling PASS**.
- Method: Inspected seven-table inventory and backup verifier; ran synthetic migration/restore suite.
- Responsible operator: Codex (local/read-only audit); hosted execution owner not assigned.
- Evidence: relative paths below, within `release/`; no private backup, credentials, or applicant data are included.

No production D1 SQL export, R2 bucket-wide object listing, object bytes, encrypted backup destination, second copy, or backup operator is available. The available Sites table reader cannot export the complete database/schema and cannot enumerate all R2 objects. Empty content tables would not prove an empty database or bucket.

`evidence/migration.log` records 10 passing fixture assertions. Those exercise isolated SQLite restore, counts, safe paths, checksums, incomplete inventories, stable mappings and production-target rejection. They do not restore the actual production database.

The assigned operator must export all seven tables with schema/indexes/migration history, enumerate every R2 key including orphans, copy bytes and metadata, compute SHA-256 hashes, and retain two restricted encrypted copies. Record actual row/object counts and timestamps; do not fill missing counts with zero.

After the actual backup is supplied privately, inspect its manifest and run the existing commands from the repository:

```sh
node scripts/operations/migrate.mjs verify /secure/aur-backup
node scripts/operations/migrate.mjs plan /secure/aur-backup
```

`/secure/aur-backup` is an example private path, not an existing backup. The verifier restores SQL into isolated SQLite and verifies files/counts. A separate operator must also prove restoration of all R2 objects into isolated private storage, compare all hashes, and record duration/errors and public/private samples without exposing their contents.

Acceptance evidence required: original provider export/inventory, measured manifest, verifier output, independent counts/hashes, second-copy reference, successful restore record, and named owner. None exists yet. G1 cannot pass.

Evidence: `backup-manifest.private-location.txt`, `evidence/service-inventory.json`, `evidence/migration.log`; procedure: `../docs/migration-runbook.md`.
