# G6 — data and object reconciliation

- Recorded at: `2026-10-16T03:55:43.166528+00:00` (UTC).
- Tested implementation source: `1714e82c1156a1c03ba9eac2aa808e56b8b57d7e` (saved version 5).
- Site: `appgprj_6acb04e29d2081918548275da19f51e4`. Production Supabase: `opbgjmoztvqjsmxexptv`; staging: **not provided**.
- Result: **BLOCKED / NOT RUN**.
- Method: Reviewed staging-only importer and ran fixture checks; no actual production snapshot imported.
- Responsible operator: Codex (local/read-only audit); hosted execution owner not assigned.
- Evidence: relative paths below, within `release/`; no private backup, credentials, or applicant data are included.

No complete production snapshot or isolated target exists, so there are no actual source/target entity counts, object totals, byte totals, snapshot time, or successful reconciliation report. Zero differences cannot be asserted.

The existing importer uses stable IDs, preserves historical consent/tombstones, verifies remote object bytes and hashes, detects changed-target conflicts, and reconstructs protected normalized Auri rules/FAQs for logical settings comparisons. It is not one global transaction across SQL and Storage. Repeatable partial import handling must still be exercised against actual staging.

After G1–G4 and the staging target record are complete, run the inspected commands using the real private backup and target configuration:

```sh
node scripts/operations/migrate.mjs apply-staging /secure/aur-backup /secure/target.json
node scripts/operations/migrate.mjs reconcile /secure/aur-backup /secure/target.json
```

These example paths are not supplied files. Both commands reject the known production reference. The secret key belongs in the operator's secure environment, not arguments or target JSON. An independently reviewed seed/source snapshot and verified owner UUID are required.

Acceptance requires exact entity counts/child fields, publication/deletion semantics, slug/author/media references, all object hashes, reviewed exceptions, repeat-run idempotency, interruption/resumption, stale-target conflict handling and a recorded delta/write-freeze procedure. Successful reconciliation emits a mode-0600 private report; link only a restricted reference here. No success report exists yet.

Evidence: `evidence/migration.log`; procedure: `../docs/migration-runbook.md`; tooling: `../scripts/operations/migrate.mjs`.
