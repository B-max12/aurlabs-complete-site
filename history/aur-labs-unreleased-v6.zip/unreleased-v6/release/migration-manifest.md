# G3 — immutable migration manifest

- Recorded at: `2026-10-16T03:55:43.166528+00:00` (UTC).
- Tested implementation source: `1714e82c1156a1c03ba9eac2aa808e56b8b57d7e` (saved version 5).
- Site: `appgprj_6acb04e29d2081918548275da19f51e4`. Production Supabase: `opbgjmoztvqjsmxexptv`; staging: **not provided**.
- Result: **LOCAL CHECK PASS; HOSTED APPLICATION BLOCKED**.
- Method: Sorted exact SQL files, SHA-256 checksums, local PostgreSQL fixtures; read-only hosted migration inventory.
- Responsible operator: Codex (local/read-only audit); hosted execution owner not assigned.
- Evidence: relative paths below, within `release/`; no private backup, credentials, or applicant data are included.

Apply these **five** files in this exact order only after the earlier gates pass and the staging ref is recorded. None has been applied to a remote project by this work.

| Order | Migration | Bytes | SHA-256 |
| --- | --- | --- | --- |
| 1 | `20261013231204_aur_v3_foundation.sql` | 24987 | `420fbb0371af546ad389176167c887a56bc99224e316e2c31a8e4605586b355e` |
| 2 | `20261014221338_aur_v3_operations.sql` | 23519 | `ee907ccc3e8d06fbe08068eb1063b2aa259595e3f93d7392b1512574e3def025` |
| 3 | `20261014222654_aur_v3_storage_and_recovery.sql` | 4036 | `20b2f93e76a0f74ba3ab85cef7720b356c780f5667d2f21bb09fccfb854e28ec` |
| 4 | `20261014223006_aur_v3_migration_operations.sql` | 7043 | `0de205bc1c894d00a4669a318f56f255511bee1ecd1005c84e60bf095256d104` |
| 5 | `20261015220741_aur_v3_editorial_rules.sql` | 5104 | `28ff33b6c75713438a47410c09badda5b18f4310cb9bcd2a2b62250dacab0a9f` |

The fifth migration creates protected `auri_rules`, extracts rules and draft FAQ data from public settings JSON, extends audited Auri save behavior, and adds the media cursor index. Omitting it would lose current privacy and editorial behavior. Do not concatenate an older four-migration instruction with a different candidate.

The source declares 19 public base tables plus private operational tables. Actual hosted tables, grants, triggers, indexes, RLS policies and the private `aur-assets-v3` bucket must be inventoried after staging application. Source declarations and local PGlite execution are not a hosted inventory.

89 local schema/RLS assertions pass. Production's native migration inventory is empty. Hosted types have not been generated, and hosted security/performance advisors have not run for this candidate. Do not use production advisors on an empty schema as candidate acceptance.

Evidence: `evidence/migrations.json`, `evidence/supabase-schema.log`, `evidence/service-inventory.json`. Recheck checksums immediately before any authorized application and stop on drift.
