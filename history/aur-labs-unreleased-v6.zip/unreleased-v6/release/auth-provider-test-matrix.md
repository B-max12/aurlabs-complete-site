# G4 — Auth, providers, MFA and SMTP

- Recorded at: `2026-10-16T03:55:43.166528+00:00` (UTC).
- Tested implementation source: `1714e82c1156a1c03ba9eac2aa808e56b8b57d7e` (saved version 5).
- Site: `appgprj_6acb04e29d2081918548275da19f51e4`. Production Supabase: `opbgjmoztvqjsmxexptv`; staging: **not provided**.
- Result: **BLOCKED / NOT RUN**.
- Method: Source-route/SDK review and owner-reported configuration; no real sign-in or email transmission.
- Responsible operator: Codex (local/read-only audit); hosted execution owner not assigned.
- Evidence: relative paths below, within `release/`; no private backup, credentials, or applicant data are included.

| Method | Configuration scope | Fresh login / callback | Cancel / failure | No-role denial | MFA / expiry / revocation | Explicit identity link |
| --- | --- | --- | --- | --- | --- | --- |
| Google | Unknown | NOT RUN | NOT RUN | NOT RUN | NOT RUN | NOT RUN |
| GitHub | Unknown | NOT RUN | NOT RUN | NOT RUN | NOT RUN | NOT RUN |
| Microsoft Azure | Unknown | NOT RUN | NOT RUN | NOT RUN | NOT RUN | NOT RUN |
| Email/password | Unknown | NOT RUN | NOT RUN | NOT RUN | NOT RUN | N/A |
| Email/SMTP recovery | Unknown | NOT RUN | NOT RUN | NOT RUN | NOT RUN | N/A |

The owner reported Google/GitHub/Azure/email/SMTP configured. That does not identify the environment or prove a login. Production has 0 Auth users. There is no designated verified staging owner UUID. The owner-enrollment tool must be used only on the separate staging project after verification, and does not create a first-signup owner or reuse the legacy admin password.

For every enabled provider, use designated test identities to verify successful fixed callback, denial/cancel, invalid PKCE/callback, unassigned-user denial, all staff roles, explicit linking and account mismatch, session refresh/expiry/revocation and logout. Keep untested provider buttons disabled through the provider allowlist. Apple/GitLab/custom Vercel are not approved rollout methods.

For SMTP, record actual delivery and rendered mail on designated addresses, verified enrollment, unused/expired/reused recovery link handling, device behavior, MFA requirement, password reset and old-session revocation. No real test mail was sent in this audit. Never use applicant addresses for this QA.

Source routes: website callback `/api/auth/callback`, recovery `/admin/recover`; provider-to-Supabase callback belongs to the selected staging project. These are two different redirect steps. The configured production URL must remain unchanged until the approved cutover.

Evidence: `evidence/supabase-http.log`, `evidence/service-inventory.json`; procedure: `../docs/authentication-setup.md`. Tester identity, provider settings scope and sanitized hosted evidence remain unassigned/missing.
